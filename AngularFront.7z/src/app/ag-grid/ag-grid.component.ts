import { Component, Input } from '@angular/core';
import { GridOptions, GridReadyEvent } from 'ag-grid-community';

@Component({
  selector: 'app-ag-grid',
  templateUrl: './ag-grid.component.html',
  styleUrls: ['./ag-grid.component.css']
})
export class AgGridComponent  {
  @Input() ColumnDefs: any;
  @Input() RowData: any;
  @Input() IsColumnsToFit: boolean | undefined;
  
  gridApi: any;
  rowHeight: any;
  gridColumnApi: any;
  gridOptions: any;
  columnDefinitions: never[];
  rowSelection: string;
  // grid compnent

  //ColumnDefs: any;
  //RowData: any;
  AgLoad: boolean | undefined;
  // end grid component
  constructor() {
    this.gridOptions = <GridOptions>{};
    this.columnDefinitions = [

    ]; 
    this.gridOptions = {
      columnDefs: this.columnDefinitions,
      enableFilter: true,
      enableSorting: true,
      pagination: true
       ,
      // EVENTS
      // Add event handlers
      onRowClicked: (event: any) => console.log('A row was clicked'),
      onColumnResized: (event: any) => console.log('A column was resized'),
      onGridReady: (event: any) => console.log('The grid is now ready'),

      // CALLBACKS
      isScrollLag: () => false
    };

    this.rowHeight = 40;
    this.rowSelection = 'single';
  }
  onGridReady(params: GridReadyEvent) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  }

   
}
