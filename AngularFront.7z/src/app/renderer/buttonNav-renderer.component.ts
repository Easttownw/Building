// Author: T4professor

import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';  
 
 
@Component({
  selector: 'app-Deletebutton-renderer',
  template: `
    <button type="button"  class="btn btn-danger"  (click)="onClick($event )" >{{label}}</button>
    `
})

export class ButtonNavRendererComponent implements ICellRendererAngularComp {
//  this.params.node.data.getSelectedRows
 
  params: { pk_Name: string, tablename: string | undefined; onClick: (arg0: { event: any; rowData: any; }) => void; node: { data: any; };  title: string} | undefined;
  label: string | undefined='';
  getSelectedRows: string | undefined;
  agInit(params: any): void {

    this.params = params;
    if (params.title == '' || params.title == null)
      this.label = 'الذهاب الى';
    else
      this.label = params.title;
  //  this.label = this.params.label || null;
   // alert(this.params?.eGridCell.nodeValue);
   // this.label = this.params.==. || null;
  }

  refresh(params?: any): boolean {
    return true;
  }

  onClick($event: any ) {
    //alert(this.params?.data.keys())
    if (this.params?.onClick instanceof Function) {
       
     // alert(this.params.node.data[this.params.pk_Name]);
     // alert(this.params.node.data);
      // put anything into params u want pass into parents component
      const params = {
        event: $event,
        rowData: this.params.node.data, pk_value:this.params.node.data[this.params.pk_Name],tablename:this.params.tablename
      }

      //let selectedData = this.params.node.data.getSelectedRows();
      //this.params.node.data.updateRowData({ remove: selectedData })
      this.params.onClick(params);

      }
       

    }
  }
 
