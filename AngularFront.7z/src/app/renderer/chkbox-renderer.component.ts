// Author: T4professor

import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular'; 
import { ICellRendererParams, IAfterGuiAttachedParams } from 'ag-grid-community';
import { param } from 'jquery';
 
 
@Component({
  selector: 'app-chkbox-renderer',
  template: `
    <input type="checkbox" id="chk_{{pk_value}}" class="btn btn-success" (click)="onClick($event)"  />
    `
})

export class chkBoxRendererComponent implements ICellRendererAngularComp {

 
  params: { pk_Name: string; onClick: (arg0: { event: any; rowData: any; }) => void; node: { data: any; };title:string } | undefined;
  label: string | undefined='تعديل';
  public pk_value: string = '';
  agInit(params: any): void { 
    this.params = params;
    if (params.title == '' || params.title == null)
      this.label = 'تعديل';
    else
      this.label = params.title;
    this.pk_value = params.node.data[params.pk_Name]
  //  this.label = this.params.label || null;
   // alert(this.params?.eGridCell.nodeValue);
   // this.label = this.params.==. || null;
  }

  refresh(params?: any): boolean {
    return true;
  }

  onClick($event: any) {
    //alert(this.params?.data.keys())
  
    if (this.params?.onClick instanceof Function) {
      
     // alert(this.params.node.data['IS_Approve']);
   /*   alert(this.params.node.data[this.params.pk_Name]);*/
      // put anything into params u want pass into parents component
      const params = {
        event: $event,
        rowData: this.params.node.data,
        label:this.label
   
      }
       
      this.params.onClick(params);

      }
       

    }
  }
 
