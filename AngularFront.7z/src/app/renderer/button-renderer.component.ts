// Author: T4professor

import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular'; 
import { ICellRendererParams, IAfterGuiAttachedParams } from 'ag-grid-community';
 
 
@Component({
  selector: 'app-button-renderer',
  template: `
    <button type="button"  class="btn btn-success" (click)="onClick($event)">Test</button>
    `
})

export class ButtonRendererComponent implements ICellRendererAngularComp {

  params:  { lablel: string; onClick: (arg0: { event: any; rowData: any; }) => void; node: { data: any; };}|undefined;
   
  agInit(params: any): void {

    this.params = params;
  //  this.label = this.params.label || null;
   // alert(this.params?.eGridCell.nodeValue);
   // this.label = this.params.==. || null;
  }

  refresh(params?: any): boolean {
    return true;
  }

  onClick($event: any) {
    //alert(this.params?.data.keys())
  
    if (this.params?.onClick instanceof Function) {
     
      alert('in');
      // put anything into params u want pass into parents component
      const params = {
        event: $event,
        rowData: this.params.node.data
      //  rowData: this.params.label..data
        // ...something
      }
      //alert(params.rowData[0]);
      for (let key in params.rowData) {
        if (params?.rowData.hasOwnProperty(key)) {
          //alert(this.params.node.data[key]);
          //return;
        }
      }
      this.params.onClick(params);
       

    }
  }
}
