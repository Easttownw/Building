import { Component, OnInit } from "@angular/core";
import {
  GridOptions,
  ColDef,
  GridReadyEvent,
  ColumnApi,
  GridApi
} from "ag-grid-community";
//import "ag-grid-enterprise";
//import { ApiService } from '../shared/api.service'
import { fetchData } from "../api";

@Component({
  selector: 'app-gridtransg',
  templateUrl: './gridtransg.component.html',
  styleUrls: ['./gridtransg.component.css']
})
export class GridtransgComponent implements OnInit {
  title = "AgGrid Example";

  private getColumnDefs(): ColDef[] {
    return [
      {
        headerName: "ID",
        field: "id",
        width: 90
      },
      {
        headerName: "Athlete",
        field: "athlete",
        width: 150,
        editable: true
      },
      {
        headerName: "Age",
        field: "age",
        width: 90,
        minWidth: 50,
        maxWidth: 100,
        editable: true
      },
      {
        headerName: "Country",
        field: "country",
        width: 120
      },
      {
        headerName: "Year",
        field: "year",
        width: 90
      },
      {
        headerName: "Date",
        field: "date",
        width: 110
      },
      {
        headerName: "Sport",
        field: "sport",
        width: 110
      }
      // {
      //   headerName: "Gold",
      //   field: "gold",
      //   width: 100
      // },
      // {
      //   headerName: "Silver",
      //   field: "silver",
      //   width: 100
      // },
      // {
      //   headerName: "Bronze",
      //   field: "bronze",
      //   width: 100
      // },
      // {
      //   headerName: "Total",
      //   field: "total",
      //   width: 100
      // }
    ];
  }

  gridOptions: GridOptions ;
  rowData: any;
  private gridApi: GridApi | any ;
  private gridColumnApi: ColumnApi | undefined;
  constructor() {
    this.gridOptions = {
      columnDefs: this.getColumnDefs(),
      rowData: []
    };
  }

  ngOnInit(): void {
    fetchData().then((data) => {
      this.gridOptions.rowData = data.slice(0, 8);
    });
  }

  onGridReady(params: GridReadyEvent) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  }

  onReset() {
    fetchData().then((data) => {
      const itemToRemove: any[] = [];

      this.gridApi.forEachNode((rowNode: { data: any; }) => {
        itemToRemove.push(rowNode.data);
      });
      this.gridApi.applyTransaction({ remove: itemToRemove });
      this.gridApi.applyTransaction({ add: data.slice(0, 8) });
    });
  }

  onAdd3() {
    const newItems = [
      createNewRowData(),
      createNewRowData(),
      createNewRowData()
    ];
    this.gridApi.applyTransaction({ add: newItems });
  }

  onDuplicate() {
    const itemsToAdd: any[] = [];

    this.gridApi.forEachNodeAfterFilterAndSort((rowNode: { data: any; }) => {
      itemsToAdd.push({ ...rowNode.data });
    });
    this.gridApi.applyTransaction({ add: itemsToAdd });
  }

  onUpdate() {
    const itemsToUpdate: any[] = [];

    this.gridApi.forEachNodeAfterFilterAndSort((rowNode: { data: any; }) => {
      const { data } = rowNode;
      data.age = randomBetween(15, 35);
      data.year = randomBetween(2000, 2020);
      itemsToUpdate.push(data);
    });
    this.gridApi.applyTransaction({ update: itemsToUpdate });
  }

  onRemoveFirst() {
    const firstRow = this.gridApi.getRenderedNodes()[0].data;

    if (!firstRow) return;
    this.gridApi.applyTransaction({ remove: [firstRow] });
  }

  onRemoveSelected() {
    const selectedData = this.gridApi.getSelectedRows();
    this.gridApi.applyTransaction({ remove: selectedData });
  }

  onThanos() {
    const itemsToRemove: any[] = [];

    this.gridApi.forEachNodeAfterFilterAndSort((rowNode: { data: any; }) => {
      const shouldThanos = randomBetween(1, 100) <= 50;

      if (shouldThanos) {
        itemsToRemove.push(rowNode.data);
      }
    });
    this.gridApi.applyTransaction({ remove: itemsToRemove });
  }
}

function randomBetween(min: number, max: number) {
  return Math.floor(Math.random() * (max - min + 1) + min);
}

let id = 999;
function createNewRowData() {
  return {
    id: ++id,
    athlete: "Michael Phelps",
    age: 23,
    country: "United States",
    year: 2008,
    date: "24/08/2008",
    sport: "Swimming",
    gold: 8,
    silver: 0,
    bronze: 0,
    total: 8
  };
}
