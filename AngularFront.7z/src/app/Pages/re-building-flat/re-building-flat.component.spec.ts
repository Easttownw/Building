import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReBuildingFlatComponent } from './re-building-flat.component';

describe('ReBuildingFlatComponent', () => {
  let component: ReBuildingFlatComponent;
  let fixture: ComponentFixture<ReBuildingFlatComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReBuildingFlatComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReBuildingFlatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
