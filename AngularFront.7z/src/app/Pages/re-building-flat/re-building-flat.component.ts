import { Component, OnInit, Inject, ViewChild, Input, SimpleChanges } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms'
import { ApiService_ReBuildingFlat } from '../../shared/ReBuildingFlat.api.service'
import { Router } from '@angular/router'
import { ReBuildingFlatModel } from './ReBuildingFlat.model';
import { HttpClient } from '@angular/common/http'
import { ButtonEditRendererComponent } from '../../renderer/buttonEdit-renderer.component';
import { ButtonDeleteRendererComponent } from '../../renderer/buttonDelete-renderer.component';
import { TranslateService } from '@ngx-translate/core';
import { GlobalConstants } from '../../common/global-constants';

import {
  GridOptions,
  ColDef,
  GridReadyEvent,
  ColumnApi,
  GridApi,
  GetRowNodeIdFunc
} from "ag-grid-community";

@Component({
  selector: 'app-re-building-flat',
  templateUrl: './re-building-flat.component.html',
  styleUrls: ['./re-building-flat.component.css']
})
export class ReBuildingFlatComponent implements OnInit {

  // model 
  ReBuildingFlatModelobj:
    ReBuildingFlatModel = new ReBuildingFlatModel();
  formvalue!: FormGroup;
  ReBuildingFlatdataRow: any;
  // from parent
  @Input() BuildingID: number = 0;
  // button
  Show_BtnInsert!: boolean;
  show_btn_Edit!: boolean;
  // for grid ag
  gridOptions: GridOptions;
  ColumnDefs: any;
  RowData: any;
  gridApi: any
  gridColumnApi: any
  rowNode: any = [];
  constructor(public translate: TranslateService, private formbuilder: FormBuilder, private router: Router, private apiServ: ApiService_ReBuildingFlat) {
    translate.addLangs(['en', 'ar']);
    translate.setDefaultLang(this.translate.instant(GlobalConstants.setDefaultLang));
    this.gridOptions = {
      columnDefs: this.GetAgColumns(),
      rowData: []
    };

  }

  ngOnInit(): void {

    this.switch_btn(true);
    this.formvalue = this.formbuilder.group({
      BuildingID: [''], FlatNo: [''], FlatContent: [''], AccountElectric: [''], AccountWater: [''], NotesFlat: [''], IS_Available:['']
    })
    //this.formvalue  = new FormGroup({
    //  name: new FormControl('', [Validators.required, Validators.minLength(3)]),
    //  email: new FormControl('', [Validators.required, Validators.email]),
    //  body: new FormControl('', Validators.required)
    //});
    // for validation
    this.formvalue = new FormGroup({
      BuildingID: new FormControl(''), FlatNo: new FormControl(''), FlatContent: new FormControl(''), AccountElectric: new FormControl(''),
      AccountWater: new FormControl(''), NotesFlat: new FormControl(''), IS_Available: new FormControl(''), 
    });

    //fill ag grid

    this.getallReBuildingFlat();
  }
  get f() {
    return this.formvalue.controls;
  }
  public getRowNodeId: GetRowNodeIdFunc = function (data) {
    return data.FlatID;
  };
  ngOnChanges(changes: SimpleChanges) {
    // only run when property "data" changed

    this.getallReBuildingFlat();
  }
  postReBuildingFlat() {
    this.ReBuildingFlatModelobj.BuildingID = this.BuildingID;
    this.ReBuildingFlatModelobj.FlatNo = this.formvalue.value.FlatNo;
    this.ReBuildingFlatModelobj.FlatContent = this.formvalue.value.FlatContent;
    this.ReBuildingFlatModelobj.AccountElectric = this.formvalue.value.AccountElectric;
    this.ReBuildingFlatModelobj.AccountWater = this.formvalue.value.AccountWater;
    this.ReBuildingFlatModelobj.NotesFlat = this.formvalue.value.NotesFlat;
    this.apiServ.postReBuildingFlat(this.ReBuildingFlatModelobj).subscribe(e => {

      alert(this.translate.instant('SuccessMessage'))

      this.gridApi.applyTransaction({ add: [e[0]] });

      this.formvalue.reset();

    }, er => { alert(this.translate.instant('WrongMessage')); });
  }


  getallReBuildingFlat() {
    this.apiServ.getReBuildingFlat(this.BuildingID).subscribe(

      ReBuildingFlatdataRow => {
        this.gridOptions.rowData = ReBuildingFlatdataRow;
      })
  }


  //switch between button add and edit
  switch_btn(Is_add: boolean) {
    if (Is_add) {
      this.Show_BtnInsert = true;
      this.show_btn_Edit = false;
    }
    else {

      this.Show_BtnInsert = false;
      this.show_btn_Edit = true;
    }

  }
  click_btnInsert() {
    this.switch_btn(true);
    // open pop modal
    ($('#exampleModal') as any).modal('show');
    this.formvalue.reset();
  }
  closeModule() {

    ($('#exampleModal') as any).modal('hide');
  }
  OnEdit(row: any) {

    this.ReBuildingFlatModelobj.FlatID = row.FlatID;
    //this.formvalue.controls['BuildingID'].setValue(row.BuildingID);
    this.BuildingID = row.BuildingID;
    this.formvalue.controls['FlatNo'].setValue(row.FlatNo);
    this.formvalue.controls['FlatContent'].setValue(row.FlatContent);
    this.formvalue.controls['AccountElectric'].setValue(row.AccountElectric);
    this.formvalue.controls['AccountWater'].setValue(row.AccountWater);
    this.formvalue.controls['NotesFlat'].setValue(row.NotesFlat);


    // open pop modal
    ($('#exampleModal') as any).modal('show');
    // swtch buttons
    this.switch_btn(false);

  }
  updateReBuildingFlat() {
    this.ReBuildingFlatModelobj.BuildingID = this.BuildingID;
    this.ReBuildingFlatModelobj.FlatNo = this.formvalue.value.FlatNo;
    this.ReBuildingFlatModelobj.FlatContent = this.formvalue.value.FlatContent;
    this.ReBuildingFlatModelobj.AccountElectric = this.formvalue.value.AccountElectric;
    this.ReBuildingFlatModelobj.AccountWater = this.formvalue.value.AccountWater;
    this.ReBuildingFlatModelobj.NotesFlat = this.formvalue.value.NotesFlat;
    this.apiServ.updateReBuildingFlat(this.ReBuildingFlatModelobj, this.ReBuildingFlatModelobj.FlatID).subscribe(res => {
      alert(this.translate.instant('UpdateMessage'));

      this.rowNode = this.gridApi.getRowNode(this.ReBuildingFlatModelobj.FlatID)!;
      this.rowNode.setData(res[0]);
      // this.formvalue.reset();
    });
  }

  // for ag grid

  onGridReady(params: GridReadyEvent) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  }
  // create column of Ag grid
  private GetAgColumns(): ColDef[] {

    return [
      {
        headerName: this.translate.instant('btnlblDelete'),
        cellRendererFramework: ButtonDeleteRendererComponent,
        cellRendererParams: {
          onClick: this.onBtnDelet_Click.bind(this),
          pk_Name: 'FlatID'
        }
      },
      { headerName: this.translate.instant('NotesFlat'), field: 'NotesFlat', sortable: true, filter: true },
      { headerName: this.translate.instant('AccountWater'), field: 'AccountWater', sortable: true, filter: true },
      { headerName: this.translate.instant('AccountElectric'), field: 'AccountElectric', sortable: true, filter: true },
      { headerName: this.translate.instant('FlatNo'), field: 'FlatNo', sortable: true, filter: true },
      //{
      //  headerName: this.translate.instant('btnlblEdit'),
      //  cellRendererFramework: ButtonEditRendererComponent,
      //  cellRendererParams: {
      //    onClick: this.onBtnEdit_Click.bind(this),
      //    pk_Name: 'FlatID'
      //  }
      //},
    
    
 
   
 
   

    ];


  }
  // event for button in Ag Grid

  onBtnEdit_Click(e: { rowData: {}; }) {

    this.OnEdit(e.rowData);
  }
  onBtnDelet_Click(e: {
    event: Event,
    rowData: any, pk_value: number
  }) {
    // alert(JSON.stringify(e.rowData));
    // delete from dataBase 
    if (confirm(this.translate.instant('DeleteConfirm'))) {
      this.apiServ.deleteReBuildingFlat(e.pk_value).subscribe((res: any) => {
        alert(this.translate.instant('DeleteMessage'));
        let deletedRow = e.rowData;
        this.gridApi.updateRowData({ remove: [deletedRow] });
      });

    }
  }
}

