export class ReBuildingFlatModel {
      FlatID: number = 0;
 BuildingID: number = 0;
 FlatNo: string = '';
 FlatContent: string = '';
 AccountElectric: string = '';
 AccountWater: string = '';
 NotesFlat: string = '';


}
