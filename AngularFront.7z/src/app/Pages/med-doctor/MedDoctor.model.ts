export class MedDoctorModel {
      DoctorID: number = 0;
 DoctorName_A: string = '';
 DoctorName_E: string = '';
 DoctorName_I: string = '';
 ClinicID: string = '';
 HospitalID: number = 0;


}
