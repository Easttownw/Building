import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MedDoctorComponent } from './med-doctor.component';

describe('MedDoctorComponent', () => {
  let component: MedDoctorComponent;
  let fixture: ComponentFixture<MedDoctorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MedDoctorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MedDoctorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
