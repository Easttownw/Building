export class ReContractCancellationModel {
      ContractCancelID: number = 0;
  ContractID: number = 0;
 DateCancelation: Date = new Date;
 Reason: string = '';
 Attachment: string = '';


}
