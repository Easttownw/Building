import { Component, OnInit, Inject, ViewChild, Input } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms'
import { ApiService_ReContractCancellation } from '../../shared/ReContractCancellation.api.service'
import { Router } from '@angular/router'
import { ReContractCancellationModel } from './ReContractCancellation.model';
import { HttpClient } from '@angular/common/http'
import { ButtonEditRendererComponent } from '../../renderer/buttonEdit-renderer.component';
import { ButtonDeleteRendererComponent } from '../../renderer/buttonDelete-renderer.component';
import { TranslateService } from '@ngx-translate/core';
import { GlobalConstants } from '../../common/global-constants';

import {
  GridOptions,
  ColDef,
  GridReadyEvent,
  ColumnApi,
  GridApi,
  GetRowNodeIdFunc
} from "ag-grid-community";

@Component({
  selector: 'app-cancel-contract',
  templateUrl: './cancel-contract.component.html',
  styleUrls: ['./cancel-contract.component.css']
})
export class CancelContractComponent implements OnInit {

  // model 
  ReContractCancellationModelobj:
    ReContractCancellationModel = new ReContractCancellationModel();
  formvalue!: FormGroup;
  ReContractCancellationdataRow: any;
  // from parent
  @Input() ContractID: number = 0;
  NewPath: string = ''
  // button
  Show_BtnInsert!: boolean;
  show_btn_Edit!: boolean;
 
  constructor(public translate: TranslateService, private formbuilder: FormBuilder, private router: Router, private apiServ: ApiService_ReContractCancellation) {
    translate.addLangs(['en', 'ar']);
    translate.setDefaultLang(this.translate.instant(GlobalConstants.setDefaultLang));
   

  }

  ngOnInit(): void {

    this.switch_btn(true);
    this.formvalue = this.formbuilder.group({
      ContractID: [''], DateCancelation: [''], Reason: [''], Attachment: ['']
    })
    //this.formvalue  = new FormGroup({
    //  name: new FormControl('', [Validators.required, Validators.minLength(3)]),
    //  email: new FormControl('', [Validators.required, Validators.email]),
    //  body: new FormControl('', Validators.required)
    //});
    // for validation
    this.formvalue = new FormGroup({
      ContractID: new FormControl(''), DateCancelation: new FormControl(''), Reason: new FormControl(''), Attachment: new FormControl(''),
    });

    
  }
  get f() {
    return this.formvalue.controls;
  }
  public getRowNodeId: GetRowNodeIdFunc = function (data) {
    return data.ContractCancelID;
  };

  postReContractCancellation() {
    this.ReContractCancellationModelobj.ContractID = this.ContractID;
    this.ReContractCancellationModelobj.DateCancelation = this.formvalue.value.DateCancelation;
    this.ReContractCancellationModelobj.Reason = this.formvalue.value.Reason;
    this.ReContractCancellationModelobj.Attachment = this.formvalue.value.Attachment;
    this.apiServ.postReContractCancellation(this.ReContractCancellationModelobj).subscribe(e => {

      alert(this.translate.instant('SuccessMessage'))
 

      this.formvalue.reset();

    }, er => { alert(this.translate.instant('WrongMessage')); });
  }

 


  //switch between button add and edit
  switch_btn(Is_add: boolean) {
    if (Is_add) {
      this.Show_BtnInsert = true;
      this.show_btn_Edit = false;
    }
    else {

      this.Show_BtnInsert = false;
      this.show_btn_Edit = true;
    }

  }
  click_btnInsert() {
    this.switch_btn(true);
    // open pop modal
    ($('#exampleModal') as any).modal('show');
    this.formvalue.reset();
  }
  closeModule() {

    ($('#exampleModal') as any).modal('hide');
  }
  OnEdit(row: any) {

    this.ReContractCancellationModelobj.ContractCancelID = row.ContractCancelID;
    this.ContractID = row.ContractCancelID;
    this.formvalue.controls['ContractID'].setValue(row.ContractID);
    this.formvalue.controls['DateCancelation'].setValue(row.DateCancelation);
    this.formvalue.controls['Reason'].setValue(row.Reason);
    this.formvalue.controls['Attachment'].setValue(row.Attachment);



    // open pop modal
    ($('#exampleModal') as any).modal('show');
    // swtch buttons
    this.switch_btn(false);

  }
  updateReContractCancellation() {
    this.ReContractCancellationModelobj.ContractID = this.ContractID;
    this.ReContractCancellationModelobj.DateCancelation = this.formvalue.value.DateCancelation;
    this.ReContractCancellationModelobj.Reason = this.formvalue.value.Reason;
    this.ReContractCancellationModelobj.Attachment = this.formvalue.value.Attachment;
    this.apiServ.updateReContractCancellation(this.ReContractCancellationModelobj, this.ReContractCancellationModelobj.ContractCancelID).subscribe(res => {
      alert(this.translate.instant('UpdateMessage'));
 
      // this.formvalue.reset();
    });
  }

  uploadFile = (files: any = []) => {
    if (files.length === 0) {
      return;
    }
    let fileToUpload = <File>files[0];
    const formData = new FormData();
    formData.append('file', fileToUpload, fileToUpload.name);

    this.apiServ.uploadFile(formData).subscribe(

      Row => {

        this.NewPath = Row.fileName;

      })
  }
}
