import { Component, OnInit, Inject, ViewChild, SimpleChanges, Input } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms' 
import { Router } from '@angular/router'
import { RentDatePaymentModel } from './RentDatePayment.model';
import { HttpClient } from '@angular/common/http'
import { ButtonEditRendererComponent } from '../../renderer/buttonEdit-renderer.component';
import { ButtonDeleteRendererComponent } from '../../renderer/buttonDelete-renderer.component';
import { TranslateService } from '@ngx-translate/core';
import { GlobalConstants } from '../../common/global-constants';

import {
  GridOptions,
  ColDef,
  GridReadyEvent,
  ColumnApi,
  GridApi,
  GetRowNodeIdFunc
} from "ag-grid-community";
import { ApiService_RentDatePayment } from '../../shared/RentDatePayment.api.service';

@Component({
  selector: 'app-rent-date-payment',
  templateUrl: './rent-date-payment.component.html',
  styleUrls: ['./rent-date-payment.component.css']
})
export class RentDatePaymentComponent implements OnInit {

  // model 
  RentDatePaymentModelobj:
    RentDatePaymentModel = new RentDatePaymentModel();
  formvalue!: FormGroup;
  RentDatePaymentdataRow: any;
  // from parent
  @Input() ContractID: number = 0;
  RentDateID:number=0
  // button
  Show_BtnInsert!: boolean;
  show_btn_Edit!: boolean;
  // for grid ag
  gridOptions: GridOptions;
  ColumnDefs: any;
  RowData: any;
  gridApi: any
  gridColumnApi: any
  getRowStyle: any; 
  rowNode: any = [];
  constructor(public translate: TranslateService, private formbuilder: FormBuilder, private router: Router, private apiServ: ApiService_RentDatePayment) {
    translate.addLangs(['en', 'ar']);
    translate.setDefaultLang(this.translate.instant(GlobalConstants.setDefaultLang));
    this.gridOptions = {
      columnDefs: this.GetAgColumns(),
      rowData: []
    };
    this.getRowStyle = (params: any) => {
      //  alert(params.data.IS_ApproveSuperVisor);
      if (params.data.IS_payed == false) {
        if (params.data.delayInPayment < 0 && params.data.delayInPayment > -30) {
          return { background: '#ef95c3' };
        }
        else if (params.data.delayInPayment < -31 && params.data.delayInPayment > -60)
          return { background: '#ef00c0' };
        else {
          return { background: 'white' };
        }
      }
      else {
        return { background: 'white' };
      }
    };
  }

  ngOnInit(): void {

    this.switch_btn(true);
    this.formvalue = this.formbuilder.group({
      Date: [''],  Value: [''], IS_payed: ['']
    })
    //this.formvalue  = new FormGroup({
    //  name: new FormControl('', [Validators.required, Validators.minLength(3)]),
    //  email: new FormControl('', [Validators.required, Validators.email]),
    //  body: new FormControl('', Validators.required)
    //});
    // for validation
    this.formvalue = new FormGroup({
      Date: new FormControl(''), ContractID: new FormControl(''), Value: new FormControl(''), IS_payed: new FormControl(''),
    });

    //fill ag grid

    this.getallRentDatePayment();
  }
  get f() {
    return this.formvalue.controls;
  }
  public getRowNodeId: GetRowNodeIdFunc = function (data) {
    return data.RentDateID;
  };
  ngOnChanges(changes: SimpleChanges) {
    // only run when property "data" changed

    this.getallRentDatePayment();
  }
  postRentDatePayment() {
    this.RentDatePaymentModelobj.Date = this.formvalue.value.Date;
    this.RentDatePaymentModelobj.ContractID = this.ContractID;
    this.RentDatePaymentModelobj.Value = this.formvalue.value.Value;
    this.RentDatePaymentModelobj.IS_payed = this.formvalue.value.IS_payed;
    this.apiServ.postRentDatePayment(this.RentDatePaymentModelobj).subscribe(e => {

      alert(this.translate.instant('SuccessMessage'))
      this.RentDateID = e[0].RentDateID
      this.gridApi.applyTransaction({ add: [e[0]] });

      this.formvalue.reset();

    }, er => { alert(this.translate.instant('WrongMessage')); });
  }


  getallRentDatePayment() {
    this.apiServ.getRentDatePayment(this.ContractID).subscribe(

      RentDatePaymentdataRow => {
        this.gridOptions.rowData = RentDatePaymentdataRow;
      })
  }


  //switch between button add and edit
  switch_btn(Is_add: boolean) {
    if (Is_add) {
      this.Show_BtnInsert = true;
      this.show_btn_Edit = false;
    }
    else {

      this.Show_BtnInsert = false;
      this.show_btn_Edit = true;
    }

  }
  switch_Div(Is_add: boolean) {
    if (Is_add) {
      $("#div_Details").show();
      $("#div_search").hide();
    }
    else {

      $("#div_search").show();
      $("#div_Details").hide();
    }

  }
  click_btnInsert() {
    this.switch_btn(true);
    //switch to add
    this.switch_Div(true);
    this.RentDateID=0;
 
    this.formvalue.reset();
  }
  closeModule() {

    ($('#exampleModal') as any).modal('hide');
  }
  OnEdit(row: any) {

    this.RentDatePaymentModelobj.RentDateID = row.RentDateID;
    this.RentDateID = row.RentDateID;
    this.formvalue.controls['Date'].setValue(row.Date);
 //   this.formvalue.controls['ContractID'].setValue(row.ContractID);
    this.ContractID = row.ContractID;
    this.formvalue.controls['Value'].setValue(row.Value);
    this.formvalue.controls['IS_payed'].setValue(row.IS_payed);


    // open pop modal
    this.switch_Div(true);
    // swtch buttons
    this.switch_btn(false);

  }
  updateRentDatePayment() {
    this.RentDatePaymentModelobj.Date = this.formvalue.value.Date;
    this.RentDatePaymentModelobj.ContractID = this.ContractID;// this.formvalue.value.ContractID;
    this.RentDatePaymentModelobj.Value = this.formvalue.value.Value;
    this.RentDatePaymentModelobj.IS_payed = this.formvalue.value.IS_payed;
    this.apiServ.updateRentDatePayment(this.RentDatePaymentModelobj, this.RentDatePaymentModelobj.RentDateID).subscribe(res => {
      alert(this.translate.instant('UpdateMessage'));

      this.rowNode = this.gridApi.getRowNode(this.RentDatePaymentModelobj.RentDateID)!;
      this.rowNode.setData(res[0]);
      // this.formvalue.reset();
    });
  }

  // for ag grid

  onGridReady(params: GridReadyEvent) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  }
  // create column of Ag grid
  private GetAgColumns(): ColDef[] {

    return [
      { headerName: this.translate.instant('Date'), field: 'Date', sortable: true, filter: true },
      { headerName: this.translate.instant('Value'), field: 'Value', sortable: true, filter: true },
      { headerName: this.translate.instant('delayInPayment'), field: 'delayInPayment', sortable: true, filter: true },
      
      {
        headerName: 'تحصيل',
        cellRendererFramework: ButtonEditRendererComponent,
        cellRendererParams: {
          onClick: this.onBtnEdit_Click.bind(this),
          pk_Name: 'RentDateID', title: 'تحصيل'
        }
      },
      //{
      //  headerName: this.translate.instant('btnlblDelete'),
      //  cellRendererFramework: ButtonDeleteRendererComponent,
      //  cellRendererParams: {
      //    onClick: this.onBtnDelet_Click.bind(this),
      //    pk_Name: 'RentDateID'
      //  }
      //},

    ];


  }
  // event for button in Ag Grid

  onBtnEdit_Click(e: { rowData: {}; }) {

    this.OnEdit(e.rowData);
  }
  onBtnDelet_Click(e: {
    event: Event,
    rowData: any, pk_value: number
  }) {
    // alert(JSON.stringify(e.rowData));
    // delete from dataBase 
    if (confirm(this.translate.instant('DeleteConfirm'))) {
      this.apiServ.deleteRentDatePayment(e.pk_value).subscribe((res: any) => {
        alert(this.translate.instant('DeleteMessage'));
        let deletedRow = e.rowData;
        this.gridApi.updateRowData({ remove: [deletedRow] });
      });

    }
  }
}

