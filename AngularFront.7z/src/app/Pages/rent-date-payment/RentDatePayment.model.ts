export class RentDatePaymentModel {
      RentDateID: number = 0;
 Date: Date = new  Date();
  ContractID: number = 0;
 Value: string = '';
 IS_payed: string = '';


}
