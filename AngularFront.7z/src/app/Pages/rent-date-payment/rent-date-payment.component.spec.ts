import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RentDatePaymentComponent } from './rent-date-payment.component';

describe('RentDatePaymentComponent', () => {
  let component: RentDatePaymentComponent;
  let fixture: ComponentFixture<RentDatePaymentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RentDatePaymentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RentDatePaymentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
