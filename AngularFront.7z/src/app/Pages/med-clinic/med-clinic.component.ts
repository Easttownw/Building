import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms'
import { ApiService_MedClinic } from '../../shared/MedClinic.api.service'
import { Router } from '@angular/router'
import { MedClinicModel } from './MedClinic.model';
import { HttpClient } from '@angular/common/http' 
import { ButtonEditRendererComponent } from '../../renderer/buttonEdit-renderer.component';
import { ButtonDeleteRendererComponent } from '../../renderer/buttonDelete-renderer.component';
import { TranslateService } from '@ngx-translate/core';
import { GlobalConstants } from '../../common/global-constants';
 
import {
  GridOptions,
  ColDef,
  GridReadyEvent,
  ColumnApi,
    GridApi,
    GetRowNodeIdFunc
} from "ag-grid-community";
@Component({
  selector: 'app-med-clinic',
  templateUrl: './med-clinic.component.html',
  styleUrls: ['./med-clinic.component.css']
})
export class MedClinicComponent implements OnInit {

  // model 
      MedClinicModelobj:
MedClinicModel = new MedClinicModel(); 
  formvalue!: FormGroup;
  MedClinicdataRow: any;

  // button
  Show_BtnInsert!: boolean;
  show_btn_Edit!: boolean;
  // for grid ag
  gridOptions: GridOptions; 
  ColumnDefs: any;
  RowData: any;
  gridApi: any
    gridColumnApi: any
    rowNode: any = [];
    constructor(public translate: TranslateService, private formbuilder: FormBuilder, private router: Router, private apiServ: ApiService_MedClinic ) {
        translate.addLangs(['en', 'ar']);
        translate.setDefaultLang(this.translate.instant(GlobalConstants.setDefaultLang));
    this.gridOptions = {
      columnDefs: this.GetAgColumns(),
      rowData: [] 
    };

  }

    ngOnInit(): void {

        this.switch_btn(true);
     this.formvalue = this.formbuilder.group({
          ClinicName_A: [''], ClinicName_E: [''], ClinicName_I: [''], IS_Show: ['']
     })
    //this.formvalue  = new FormGroup({
    //  name: new FormControl('', [Validators.required, Validators.minLength(3)]),
    //  email: new FormControl('', [Validators.required, Validators.email]),
    //  body: new FormControl('', Validators.required)
    //});
    // for validation
    this.formvalue = new FormGroup({
        ClinicName_A: new FormControl(''),ClinicName_E: new FormControl(''),ClinicName_I: new FormControl(''),IS_Show: new FormControl(''),
    });
   
    //fill ag grid

      this.getallMedClinic();
  }
  get f() {
    return this.formvalue.controls;
    }
    public getRowNodeId: GetRowNodeIdFunc = function (data) {
        return data.ClinicID;
    };

    postMedClinic() { 
  this.MedClinicModelobj.ClinicName_A = this.formvalue.value.ClinicName_A;
  this.MedClinicModelobj.ClinicName_E = this.formvalue.value.ClinicName_E;
  this.MedClinicModelobj.ClinicName_I = this.formvalue.value.ClinicName_I;
      this.MedClinicModelobj.IS_Show = $("#InputIS_Show").prop('checked');//; this.formvalue.value.IS_Show;
 this.apiServ.postMedClinic(this.MedClinicModelobj).subscribe(e => {
      
      alert(this.translate.instant('SuccessMessage')) 
 
      this.gridApi.applyTransaction({ add:  [e[0]] }); 
      
        this.formvalue.reset();

    }, er => { alert(this.translate.instant('WrongMessage')); });
  }


    getallMedClinic() {
    this.apiServ.getMedClinic().subscribe(

      MedClinicdataRow => { 
        this.gridOptions.rowData = MedClinicdataRow;
      }) 
  }


    //switch between button add and edit
    switch_btn(Is_add: boolean) {
        if (Is_add) {
            this.Show_BtnInsert = true;
            this.show_btn_Edit = false;
        }
        else {

            this.Show_BtnInsert = false;
            this.show_btn_Edit = true;
        }

    }
  click_btnInsert() {
    this.switch_btn(true);
        // open pop modal
        ($('#exampleModal') as any).modal('show');
      this.formvalue.reset();
    }
    closeModule() {

        ($('#exampleModal') as any).modal('hide');
    }
  OnEdit(row: any) {
 
      this.MedClinicModelobj.ClinicID = row.ClinicID;
this.formvalue.controls['ClinicName_A'].setValue(row.ClinicName_A);
this.formvalue.controls['ClinicName_E'].setValue(row.ClinicName_E);
this.formvalue.controls['ClinicName_I'].setValue(row.ClinicName_I);
this.formvalue.controls['IS_Show'].setValue(row.IS_Show);


          // open pop modal
          ($('#exampleModal') as any).modal('show');
      // swtch buttons
      this.switch_btn(false);

  }
    updateMedClinic() {
this.MedClinicModelobj.ClinicName_A = this.formvalue.value.ClinicName_A;
this.MedClinicModelobj.ClinicName_E = this.formvalue.value.ClinicName_E;
this.MedClinicModelobj.ClinicName_I = this.formvalue.value.ClinicName_I;
      this.MedClinicModelobj.IS_Show = $("#InputIS_Show").prop('checked');//this.formvalue.value.IS_Show;
this.apiServ.updateMedClinic(this.MedClinicModelobj, this.MedClinicModelobj.ClinicID).subscribe(res => {
        alert(this.translate.instant('UpdateMessage'));

            this.rowNode = this.gridApi.getRowNode(this.MedClinicModelobj.ClinicID)!;    
      this.rowNode.setData(res[0]);
     // this.formvalue.reset();
    });
  }

  // for ag grid
  
  onGridReady(params: GridReadyEvent) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    }
    // create column of Ag grid
  private GetAgColumns(): ColDef[] {

    return [
        {
        headerName: this.translate.instant('BtnEdit'),
        cellRendererFramework: ButtonEditRendererComponent,
        cellRendererParams: {
          onClick: this.onBtnEdit_Click.bind(this),
          pk_Name: 'ClinicID'
       }
      },
{
        headerName: this.translate.instant('btnlblDelete'),
        cellRendererFramework: ButtonDeleteRendererComponent,
        cellRendererParams: {
          onClick: this.onBtnDelet_Click.bind(this),
          pk_Name: 'ClinicID'
        }
      },
      { headerName: this.translate.instant('ClinicName_A'), field:'ClinicName_A',sortable:true,filter:true}
    ];
  

  }
  // event for button in Ag Grid

  onBtnEdit_Click(e: { rowData: {}; }) {
   
    this.OnEdit(e.rowData); 
  }
  onBtnDelet_Click(e: {
    event: Event,
    rowData: any, pk_value:number
  })
  {
   // alert(JSON.stringify(e.rowData));
    // delete from dataBase 
      if (confirm(this.translate.instant('DeleteConfirm'))) {
        this.apiServ.deleteMedClinic(e.pk_value).subscribe((res: any) => {
            alert(this.translate.instant('DeleteMessage'));  
            let deletedRow = e.rowData;
        this.gridApi.updateRowData({ remove: [deletedRow] }) ; });
       
    }
  }
}
 
