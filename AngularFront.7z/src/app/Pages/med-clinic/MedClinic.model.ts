export class MedClinicModel {
      ClinicID: number = 0;
 ClinicName_A: string = '';
 ClinicName_E: string = '';
 ClinicName_I: string = '';
 IS_Show: string = '';


}
