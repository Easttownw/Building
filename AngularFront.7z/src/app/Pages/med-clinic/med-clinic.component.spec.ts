import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MedClinicComponent } from './med-clinic.component';

describe('MedClinicComponent', () => {
  let component: MedClinicComponent;
  let fixture: ComponentFixture<MedClinicComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MedClinicComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MedClinicComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
