import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DelayPaymentComponent } from './delay-payment.component';

describe('DelayPaymentComponent', () => {
  let component: DelayPaymentComponent;
  let fixture: ComponentFixture<DelayPaymentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DelayPaymentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DelayPaymentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
