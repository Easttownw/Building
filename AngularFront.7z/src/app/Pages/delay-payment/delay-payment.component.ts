import { Component, OnInit, Inject, ViewChild, Input, SimpleChanges } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms'
import { ApiService_ReTenantI } from '../../shared/ReTenantI.api.service'
import { Router } from '@angular/router' 
import { ButtonEditRendererComponent } from '../../renderer/buttonEdit-renderer.component';
import { ButtonDeleteRendererComponent } from '../../renderer/buttonDelete-renderer.component';
import { TranslateService } from '@ngx-translate/core';
import { GlobalConstants } from '../../common/global-constants';

import {
  GridOptions,
  ColDef,
  GridReadyEvent,
  ColumnApi,
  GridApi,
  GetRowNodeIdFunc
} from "ag-grid-community";
import { jsDocComment } from '@angular/compiler';
import { _global } from '@angular/localize/src/localize';
import { ApiService_Rebuilding } from '../../shared/Rebuilding.api.service';
import { ApiService_RentDatePayment } from '../../shared/RentDatePayment.api.service';
@Component({
  selector: 'app-delay-payment',
  templateUrl: './delay-payment.component.html',
  styleUrls: ['./delay-payment.component.css']
})
export class DelayPaymentComponent implements OnInit {
  // for grid ag
  gridOptions: GridOptions;
  ColumnDefs: any;
  RowData: any;
  gridApi: any
  gridColumnApi: any
  getRowStyle: any; 
  rowNode: any = [];
  constructor(public translate: TranslateService, private formbuilder: FormBuilder, private router: Router, private apiServ: ApiService_RentDatePayment) {
    translate.addLangs(['en', 'ar']);
    translate.setDefaultLang(this.translate.instant(GlobalConstants.setDefaultLang));
    this.gridOptions = {
      columnDefs: this.GetAgColumns(),
      rowData: []
    };
    this.getRowStyle = (params: any) => {
      //  alert(params.data.IS_ApproveSuperVisor);
      if (params.data.IS_payed == false) {
        if (params.data.delayInPayment < 0 && params.data.delayInPayment > -30) {
          return { background: '#ef95c3' };
        }
        else if (params.data.delayInPayment < -31 && params.data.delayInPayment > -60)
          return { background: '#ef00c0' };
        else if (params.data.delayInPayment < -61 && params.data.delayInPayment > -90)
          return { background: '#ef0000' };
        else if (params.data.delayInPayment < -91 && params.data.delayInPayment > -120)
          return { background: '#ec0000' };
        else if (params.data.delayInPayment < -121 && params.data.delayInPayment > -10550)
          return { background: '#e00000' };
        else {
          return { background: 'white' };
        }
      }
      else {
        return { background: 'white' };
      }
    };
}

  ngOnInit(): void {
    this.getallDelayPayment();
  }
  getallDelayPayment() {
    this.apiServ.geDelayPayment( ).subscribe(

      RentDatePaymentdataRow => {
        this.gridOptions.rowData = RentDatePaymentdataRow;
      })
  }

  // for ag grid

  onGridReady(params: GridReadyEvent) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  }
  // create column of Ag grid
  private GetAgColumns(): ColDef[] {

    return [
      


  
    
    

   
    

      { headerName: 'اسم البناية', field: 'BuildingName', sortable: true, filter: true },
      { headerName: 'رقم البناية', field: 'BuildingNo', sortable: true, filter: true },
      { headerName: 'رقم الوحده', field: 'FlatNo', sortable: true, filter: true },
      { headerName: 'عدد ايام التاخير', field: 'delayInPayment', sortable: true, filter: true },
      { headerName:'قيمة الايجار', field: 'Value', sortable: true, filter: true },
      { headerName: 'الجوال', field: 'Mobile', sortable: true, filter: true },
      { headerName:'اسم المستاجر', field: 'TenantName', sortable: true, filter: true },
      { headerName:'التاريخ', field: 'Date', sortable: true, filter: true },

    ];


  }
}
