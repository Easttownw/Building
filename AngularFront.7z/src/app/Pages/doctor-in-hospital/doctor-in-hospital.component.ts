import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms'
import { ApiService_MedDoctor } from '../../shared/MedDoctor.api.service'
import { Router } from '@angular/router'  
import { ButtonEditRendererComponent } from '../../renderer/buttonEdit-renderer.component';
import { ButtonDeleteRendererComponent } from '../../renderer/buttonDelete-renderer.component';
import { TranslateService } from '@ngx-translate/core';
import { GlobalConstants } from '../../common/global-constants';

import {
  GridOptions,
  ColDef,
  GridReadyEvent,
  ColumnApi,
  GridApi,
  GetRowNodeIdFunc
} from "ag-grid-community";
import { ApiService_MedClinic } from '../../shared/MedClinic.api.service';
import { MedDoctorModel } from '../med-doctor/MedDoctor.model';
import { ApiService_MedHospital } from '../../shared/MedHospital.api.service';
@Component({
  selector: 'app-doctor-in-hospital',
  templateUrl: './doctor-in-hospital.component.html',
  styleUrls: ['./doctor-in-hospital.component.css']
})
export class DoctorInHospitalComponent implements OnInit {

  // model 
  MedDoctorModelobj:
    MedDoctorModel = new MedDoctorModel();
  formvalue!: FormGroup;
  MedDoctordataRow: any;
  ClinicList: any = []
  HospitalList:any=[]
  // button
  Show_BtnInsert!: boolean;
  show_btn_Edit!: boolean;
  // for grid ag
  gridOptions: GridOptions;
  ColumnDefs: any;
  RowData: any;
  gridApi: any
  gridColumnApi: any
  rowNode: any = [];
  constructor(public translate: TranslateService, private formbuilder: FormBuilder,
    private router: Router, private apiServ: ApiService_MedDoctor
    , private apiServ_Clinics: ApiService_MedClinic, private apiServ_Hospital: ApiService_MedHospital) {
    translate.addLangs(['en', 'ar']);
    translate.setDefaultLang(this.translate.instant(GlobalConstants.setDefaultLang));
    this.gridOptions = {
      columnDefs: this.GetAgColumns(),
      rowData: []
    };

  }

  ngOnInit(): void {

    this.switch_btn(true);
    this.formvalue = this.formbuilder.group({
      DoctorName_A: [''], DoctorName_E: [''], DoctorName_I: [''], ClinicID: [''], HospitalID: ['']
    })
    //this.formvalue  = new FormGroup({
    //  name: new FormControl('', [Validators.required, Validators.minLength(3)]),
    //  email: new FormControl('', [Validators.required, Validators.email]),
    //  body: new FormControl('', Validators.required)
    //});
    // for validation
    this.formvalue = new FormGroup({
      DoctorName_A: new FormControl('', Validators.required), DoctorName_E: new FormControl(''),
      DoctorName_I: new FormControl(''), ClinicID: new FormControl('', Validators.required),
      HospitalID: new FormControl('',Validators.required),
    });

    //fill ag grid

    this.getallMedDoctor();
    //ddlist
    this.Fill_ddlistClinic();
    this.Fill_ddlistHospital();
  }
  get f() {
    return this.formvalue.controls;
  }
  public getRowNodeId: GetRowNodeIdFunc = function (data) {
    return data.DoctorID;
  };

  postMedDoctor() {
    this.MedDoctorModelobj.DoctorName_A = this.formvalue.value.DoctorName_A;
    this.MedDoctorModelobj.DoctorName_E = this.formvalue.value.DoctorName_E;
    this.MedDoctorModelobj.DoctorName_I = this.formvalue.value.DoctorName_I;
    this.MedDoctorModelobj.ClinicID = this.formvalue.value.ClinicID;
      this.MedDoctorModelobj.HospitalID = this.formvalue.value.HospitalID;
    this.apiServ.postMedDoctor(this.MedDoctorModelobj).subscribe(e => {

      alert(this.translate.instant('SuccessMessage'))

      this.gridApi.applyTransaction({ add: [e[0]] });

      this.formvalue.reset();

    }, er => { alert(this.translate.instant('WrongMessage')); });
  }


  getallMedDoctor() {
    this.apiServ.getMedDoctorInHospit().subscribe(

      MedDoctordataRow => {
        this.gridOptions.rowData = MedDoctordataRow;
      })
  }

  Fill_ddlistClinic() {
    this.apiServ_Clinics.getMedClinic().subscribe(

      Row => {
        this.ClinicList = Row;
      })
  }

  Fill_ddlistHospital() {
    
    this.apiServ_Hospital.getMedHospital().subscribe(

      Row => {
        this.HospitalList = Row;
      })
  }
  //switch between button add and edit
  switch_btn(Is_add: boolean) {
    if (Is_add) {
      this.Show_BtnInsert = true;
      this.show_btn_Edit = false;
    }
    else {

      this.Show_BtnInsert = false;
      this.show_btn_Edit = true;
    }

  }
  click_btnInsert() {
    this.switch_btn(true);
    // open pop modal
    ($('#exampleModal') as any).modal('show');
    this.formvalue.reset();
  }
  closeModule() {

    ($('#exampleModal') as any).modal('hide');
  }
  OnEdit(row: any) {

    this.MedDoctorModelobj.DoctorID = row.DoctorID;
    this.formvalue.controls['DoctorName_A'].setValue(row.DoctorName_A);
    this.formvalue.controls['DoctorName_E'].setValue(row.DoctorName_E);
    this.formvalue.controls['DoctorName_I'].setValue(row.DoctorName_I);
    this.formvalue.controls['ClinicID'].setValue(row.ClinicID);
    this.formvalue.controls['HospitalID'].setValue(row.HospitalID);


    // open pop modal
    ($('#exampleModal') as any).modal('show');
    // swtch buttons
    this.switch_btn(false);

  }
  updateMedDoctor() {
    this.MedDoctorModelobj.DoctorName_A = this.formvalue.value.DoctorName_A;
    this.MedDoctorModelobj.DoctorName_E = this.formvalue.value.DoctorName_E;
    this.MedDoctorModelobj.DoctorName_I = this.formvalue.value.DoctorName_I;
    this.MedDoctorModelobj.ClinicID = this.formvalue.value.ClinicID;
    this.MedDoctorModelobj.HospitalID = this.formvalue.value.HospitalID;
    this.apiServ.updateMedDoctor(this.MedDoctorModelobj, this.MedDoctorModelobj.DoctorID).subscribe(res => {
      alert(this.translate.instant('UpdateMessage'));

      this.rowNode = this.gridApi.getRowNode(this.MedDoctorModelobj.DoctorID)!;
      this.rowNode.setData(res[0]);
      // this.formvalue.reset();
    });
  }

  // for ag grid

  onGridReady(params: GridReadyEvent) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  }
  // create column of Ag grid
  private GetAgColumns(): ColDef[] {

    return [
      {
        headerName: this.translate.instant('btnlblEdit'),
        cellRendererFramework: ButtonEditRendererComponent,
        cellRendererParams: {
          onClick: this.onBtnEdit_Click.bind(this),
          pk_Name: 'DoctorID'
        }
      },
      {
        headerName: this.translate.instant('btnlblDelete'),
        cellRendererFramework: ButtonDeleteRendererComponent,
        cellRendererParams: {
          onClick: this.onBtnDelet_Click.bind(this),
          pk_Name: 'DoctorID'
        }
      },
      { headerName: this.translate.instant('ClinicName_A'), field: 'ClinicName_A', sortable: true, filter: true },
      { headerName: this.translate.instant('DoctorName_A'), field: 'DoctorName_A', sortable: true, filter: true },
      { headerName: this.translate.instant('HospitalName_A'), field: 'HospitalName_A', sortable: true, filter: true },
    ];


  }
  // event for button in Ag Grid

  onBtnEdit_Click(e: { rowData: {}; }) {

    this.OnEdit(e.rowData);
  }
  onBtnDelet_Click(e: {
    event: Event,
    rowData: any, pk_value: number
  }) {
    // alert(JSON.stringify(e.rowData));
    // delete from dataBase 
    if (confirm(this.translate.instant('DeleteConfirm'))) {
      this.apiServ.deleteMedDoctor(e.pk_value).subscribe((res: any) => {
        alert(this.translate.instant('DeleteMessage'));
        let deletedRow = e.rowData;
        this.gridApi.updateRowData({ remove: [deletedRow] });
      });

    }
  }
}

