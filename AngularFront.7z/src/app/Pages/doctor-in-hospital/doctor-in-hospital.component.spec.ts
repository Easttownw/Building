import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DoctorInHospitalComponent } from './doctor-in-hospital.component';

describe('DoctorInHospitalComponent', () => {
  let component: DoctorInHospitalComponent;
  let fixture: ComponentFixture<DoctorInHospitalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DoctorInHospitalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DoctorInHospitalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
