import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms'
import { ApiService_Rebuilding } from '../../shared/Rebuilding.api.service'
import { Router } from '@angular/router'
import { RebuildingModel } from './Rebuilding.model';
import { HttpClient } from '@angular/common/http' 
import { ButtonEditRendererComponent } from '../../renderer/buttonEdit-renderer.component';
import { ButtonDeleteRendererComponent } from '../../renderer/buttonDelete-renderer.component';
import { TranslateService } from '@ngx-translate/core';
import { GlobalConstants } from '../../common/global-constants';
 
import {
  GridOptions,
  ColDef,
  GridReadyEvent,
  ColumnApi,
    GridApi,
    GetRowNodeIdFunc
} from "ag-grid-community";
import { ApiService_City } from '../../shared/City.api.service';
import { ApiService_Location } from '../../shared/Location.api.service';
import { TabDirective } from 'ngx-bootstrap/tabs';

@Component({
  selector: 'app-rebuilding',
  templateUrl: './rebuilding.component.html',
  styleUrls: ['./rebuilding.component.css']
})
export class RebuildingComponent implements OnInit {

  // model 
  RebuildingModelobj:
    RebuildingModel = new RebuildingModel();
  formvalue!: FormGroup;
  RebuildingdataRow: any;
  BuildingID: number = 0;
  LocationList: any = [];
  CityList: any = [];
  // button
  Show_BtnInsert!: boolean;
  show_btn_Edit!: boolean;
  // for grid ag
  gridOptions: GridOptions;
  ColumnDefs: any;
  RowData: any;
  gridApi: any
  gridColumnApi: any
  rowNode: any = [];
  constructor(public translate: TranslateService, private formbuilder: FormBuilder, private router: Router, private apiServ: ApiService_Rebuilding,
    private api_city: ApiService_City, private  api_location:ApiService_Location) {
    translate.addLangs(['en', 'ar']);
    translate.setDefaultLang(this.translate.instant(GlobalConstants.setDefaultLang));
    this.gridOptions = {
      columnDefs: this.GetAgColumns(),
      rowData: []
    };

  }

  ngOnInit(): void {

    this.switch_btn(true);
    this.formvalue = this.formbuilder.group({
      BuildingName: [''], BuildingNo: [''],  UnitPlace: [''], Type: [''], LocationID: [''], CityID: [''],  Notes: [''] 
    })
    //this.formvalue  = new FormGroup({
    //  name: new FormControl('', [Validators.required, Validators.minLength(3)]),
    //  email: new FormControl('', [Validators.required, Validators.email]),
    //  body: new FormControl('', Validators.required)
    //});
    // for validation
    this.formvalue = new FormGroup({
      BuildingName: new FormControl('', Validators.required), BuildingNo: new FormControl('', Validators.required) , UnitPlace: new FormControl('', Validators.required), Type: new FormControl(''), LocationID: new FormControl(''), CityID: new FormControl(''),
       Notes: new FormControl(''),  
    });

    //fill ag grid

    this.getallRebuilding();
    //fill ddlist
    this.Fill_ddlistLoctaion();
    this.Fill_ddlistCity();
  }
  get f() {
    return this.formvalue.controls;
  }
  public getRowNodeId: GetRowNodeIdFunc = function (data) {
    return data.BuildingID;
  };

  postRebuilding() {
    this.RebuildingModelobj.BuildingName = this.formvalue.value.BuildingName;
    this.RebuildingModelobj.BuildingNo = this.formvalue.value.BuildingNo;
   
    //this.RebuildingModelobj.UnitPlace = this.formvalue.value.UnitPlace;
    this.RebuildingModelobj.Type = this.formvalue.value.Type;
    this.RebuildingModelobj.LocationID = this.formvalue.value.LocationID;
    this.RebuildingModelobj.CityID = this.formvalue.value.CityID;
   // this.RebuildingModelobj.OwnerID = this.formvalue.value.OwnerID;
   // this.RebuildingModelobj.CreatedBy = this.formvalue.value.CreatedBy;
    this.RebuildingModelobj.Notes = this.formvalue.value.Notes;
  //  this.RebuildingModelobj.IS_Available = $("#chk_IS_Available").prop("checked");// this.formvalue.value.IS_Available;
    console.log(JSON.stringify(this.RebuildingModelobj))
    this.apiServ.postRebuilding(this.RebuildingModelobj).subscribe(e => {

      alert(this.translate.instant('SuccessMessage'))

      this.gridApi.applyTransaction({ add: [e[0]] });

      this.RebuildingModelobj.BuildingID = e[0].BuildingID;
      this.BuildingID = e[0].BuildingID;
      this.formvalue.controls['BuildingName'].setValue(e[0].BuildingName);
      this.formvalue.controls['BuildingNo'].setValue(e[0].BuildingNo);
     
      this.formvalue.controls['UnitPlace'].setValue(e[0].UnitPlace);
      this.formvalue.controls['Type'].setValue(e[0].Type);
      this.formvalue.controls['LocationID'].setValue(e[0].LocationID);
      this.formvalue.controls['CityID'].setValue(e[0].CityID);
      //this.formvalue.controls['OwnerID'].setValue(row.OwnerID);
      /* this.formvalue.controls['CreatedBy'].setValue(row.CreatedBy);*/
      this.formvalue.controls['Notes'].setValue(e[0].Notes);
     // this.formvalue.reset();

    }, er => { alert(this.translate.instant('WrongMessage')); });
  }


  getallRebuilding() {
    this.apiServ.getRebuilding().subscribe(

      RebuildingdataRow => {
        this.gridOptions.rowData = RebuildingdataRow;
      })
  }
  //fill ddlist

  Fill_ddlistLoctaion() {
    this.api_location.getLocation().subscribe(

      Row => {
        this.LocationList = Row;
      })
  }
  Fill_ddlistCity() {
    this.api_city.getCity().subscribe(

       Row => {
        this.CityList = Row;
      })
  }


  //switch between button add and edit
  switch_btn(Is_add: boolean) {
    if (Is_add) {
      this.Show_BtnInsert = true;
      this.show_btn_Edit = false;
    }
    else {

      this.Show_BtnInsert = false;
      this.show_btn_Edit = true;
    }

  }
  click_btnInsert() {
    this.switch_btn(true);

    // open pop modal
    ($('#exampleModal') as any).modal('show');
    this.BuildingID = 0;
    this.formvalue.reset();
  }
  closeModule() {

    ($('#exampleModal') as any).modal('hide');
  }
  OnEdit(row: any) {

    this.RebuildingModelobj.BuildingID = row.BuildingID;
    this.BuildingID = row.BuildingID;

    this.formvalue.controls['BuildingName'].setValue(row.BuildingName);
    this.formvalue.controls['BuildingNo'].setValue(row.BuildingNo);
    //this.formvalue.controls['FlatNo'].setValue(row.FlatNo);
    //this.formvalue.controls['FlatContent'].setValue(row.FlatContent);
    //this.formvalue.controls['UnitNo'].setValue(row.UnitNo);
    //this.formvalue.controls['UnitPlace'].setValue(row.UnitPlace);
    this.formvalue.controls['Type'].setValue(row.Type);
    this.formvalue.controls['LocationID'].setValue(row.LocationID);
    this.formvalue.controls['CityID'].setValue(row.CityID);
    //this.formvalue.controls['OwnerID'].setValue(row.OwnerID);
   /* this.formvalue.controls['CreatedBy'].setValue(row.CreatedBy);*/
    this.formvalue.controls['Notes'].setValue(row.Notes);
    //this.formvalue.controls['IS_Available'].setValue(row.IS_Available);


    // open pop modal
    ($('#exampleModal') as any).modal('show');
    // swtch buttons
    this.switch_btn(false);

  }
  updateRebuilding() {
    this.RebuildingModelobj.BuildingName = this.formvalue.value.BuildingName;
    this.RebuildingModelobj.BuildingNo = this.formvalue.value.BuildingNo;
    //this.RebuildingModelobj.FlatNo = this.formvalue.value.FlatNo;
    //this.RebuildingModelobj.FlatContent = this.formvalue.value.FlatContent;
    //this.RebuildingModelobj.UnitNo = this.formvalue.value.UnitNo;
    //this.RebuildingModelobj.UnitPlace = this.formvalue.value.UnitPlace;
    this.RebuildingModelobj.Type = this.formvalue.value.Type;
    this.RebuildingModelobj.LocationID = this.formvalue.value.LocationID;
    this.RebuildingModelobj.CityID = this.formvalue.value.CityID;
 //   this.RebuildingModelobj.OwnerID = this.formvalue.value.OwnerID;
    this.RebuildingModelobj.CreatedBy = this.formvalue.value.CreatedBy;
    this.RebuildingModelobj.CreateDate = this.formvalue.value.CreateDate;
    this.RebuildingModelobj.Notes = this.formvalue.value.Notes;
   // this.RebuildingModelobj.IS_Available = $("#chk_IS_Available").prop("checked");
    this.apiServ.updateRebuilding(this.RebuildingModelobj, this.RebuildingModelobj.BuildingID).subscribe(res => {
      alert(this.translate.instant('UpdateMessage'));

      this.rowNode = this.gridApi.getRowNode(this.RebuildingModelobj.BuildingID)!;
      this.rowNode.setData(res[0]);
      // this.formvalue.reset();
    });
  }

  // for ag grid

  onGridReady(params: GridReadyEvent) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  }
  // create column of Ag grid
  private GetAgColumns(): ColDef[] {

    return [
      { headerName: this.translate.instant('BuildingName'), field: 'BuildingName', sortable: true, filter: true },
      { headerName: this.translate.instant('BuildingNo'), field: 'BuildingNo', sortable: true, filter: true },
      //{ headerName: this.translate.instant('FlatNo'), field: 'FlatNo', sortable: true, filter: true },
      //{ headerName: this.translate.instant('FlatContent'), field: 'FlatContent', sortable: true, filter: true },
      //{ headerName: this.translate.instant('UnitNo'), field: 'UnitNo', sortable: true, filter: true },
      //{ headerName: this.translate.instant('UnitPlace'), field: 'UnitPlace', sortable: true, filter: true },
      { headerName: this.translate.instant('OwnerID'), field: 'OwnerID', sortable: true, filter: true },
      {
        headerName: this.translate.instant('Details'),
        cellRendererFramework: ButtonEditRendererComponent,
        cellRendererParams: {
          onClick: this.onBtnEdit_Click.bind(this), title: this.translate.instant('Details'),
          pk_Name: 'BuildingID'
        }
      },
      {
        headerName: this.translate.instant('btnlblDelete'),
        cellRendererFramework: ButtonDeleteRendererComponent,
        cellRendererParams: {
          onClick: this.onBtnDelet_Click.bind(this),
          pk_Name: 'BuildingID'
        }
      },

    ];


  }
  // event for button in Ag Grid

  onBtnEdit_Click(e: { rowData: {}; }) {

    this.OnEdit(e.rowData);
  }
  onBtnDelet_Click(e: {
    event: Event,
    rowData: any, pk_value: number
  }) {
    // alert(JSON.stringify(e.rowData));
    // delete from dataBase 
    if (confirm(this.translate.instant('DeleteConfirm'))) {
      this.apiServ.deleteRebuilding(e.pk_value).subscribe((res: any) => {
        alert(this.translate.instant('DeleteMessage'));
        let deletedRow = e.rowData;
        this.gridApi.updateRowData({ remove: [deletedRow] });
      });

    }
  } 
  @ViewChild('tab_Building') tab_Building: TabDirective | any;
  @ViewChild('tab_owner') tab_owner: TabDirective | any;
  @ViewChild('tab_tenant') tab_tenant: TabDirective | any;
  TabBasic_index: number = 70;
  Select_BasicTab($event: any) {
   // this.tab_tenant.getallReTenantI();
    //if (this.tab_owner.active && this.TabBasic_index != 0) {
    //  this.TabBasic_index = 0
    //  alert('here')
    //  this.tab_owner.getOwnerByBuilding();
    //}
  }
  OwnerID:number=0
  ReceiveOwnerID($event: string) { 
    // assign studentID from Childe control to this variable
    this.OwnerID =Number( $event);
 

  }
}

