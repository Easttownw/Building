import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RebuildingComponent } from './rebuilding.component';

describe('RebuildingComponent', () => {
  let component: RebuildingComponent;
  let fixture: ComponentFixture<RebuildingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RebuildingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RebuildingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
