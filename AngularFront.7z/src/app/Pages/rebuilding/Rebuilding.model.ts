export class RebuildingModel {
      BuildingID: number = 0;
 BuildingName: string = '';
 BuildingNo: string = '';
 //FlatNo: string = '';
 //FlatContent: string = '';
 //UnitNo: string = '';
 //UnitPlace: string = '';
 Type: string = '';
 LocationID: string = '';
 CityID: string = '';
 OwnerID: string|null =null;
 CreatedBy: string = '1';
 CreateDate:  Date = new Date;
 Notes: string = '';
 /*IS_Available: string = '';*/


}
