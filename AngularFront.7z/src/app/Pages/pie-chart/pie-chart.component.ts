//import { Component, OnInit } from '@angular/core';

//import { ChartTooltipsStaticConfiguration,ChartDataSets, ChartOptions, ChartType, ChartColor } from 'chart.js';
 import { SingleLineLabel, NgChartsModule, Label, SingleDataSet } from 'ng2-charts';
import { Component, OnInit } from '@angular/core';
import { ChartDataSets, ChartOptions, ChartType, ChartColor } from 'chart.js'; 
@Component({
  selector: 'app-pie-chart',
  templateUrl: './pie-chart.component.html',
  styleUrls: ['./pie-chart.component.css']
})
export class PieChartComponent implements OnInit {

  public pieChartOptions: ChartOptions = {
    responsive: true,
  };

  public pieChartLabels: Label[] = ['PHP', '.Net', 'Java'];
  public pieChartData: SingleDataSet = [50, 30, 20];
  public pieChartType: ChartType = 'pie';
  public pieChartLegend = true;
  public pieChartPlugins = [];

  constructor() {
    //monkeyPatchChartJsTooltip();
    //monkeyPatchChartJsLegend();
  }
  ngOnInit(): void {
  }

}
