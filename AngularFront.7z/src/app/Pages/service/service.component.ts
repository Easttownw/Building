import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms'
import { ApiService_Service } from '../../shared/Service.api.service'
import { Router } from '@angular/router'
import { ServiceModel } from './Service.model';
import { HttpClient } from '@angular/common/http'
import { ButtonEditRendererComponent } from '../../renderer/buttonEdit-renderer.component';
import { ButtonDeleteRendererComponent } from '../../renderer/buttonDelete-renderer.component';
import { TranslateService } from '@ngx-translate/core';
import { GlobalConstants } from '../../common/global-constants';

import {
  GridOptions,
  ColDef,
  GridReadyEvent,
  ColumnApi,
  GridApi,
  GetRowNodeIdFunc
} from "ag-grid-community";
import { ApiService_GroupService } from '../../shared/GroupService.api.service';

@Component({
  selector: 'app-service',
  templateUrl: './service.component.html',
  styleUrls: ['./service.component.css']
})
export class ServiceComponent implements OnInit {

  // model 
  ServiceModelobj:
    ServiceModel = new ServiceModel();
  formvalue!: FormGroup;
  ServicedataRow: any;
  GroupServiceList: any = []
  ParentServiceList: any = []

  newpath: string = ''
  imageSrc: string = ''

  // button
  Show_BtnInsert!: boolean;
  show_btn_Edit!: boolean;
  // for grid ag
  gridOptions: GridOptions;
  ColumnDefs: any;
  RowData: any;
  gridApi: any
  gridColumnApi: any
  rowNode: any = [];
  constructor(public translate: TranslateService, private formbuilder: FormBuilder, private router: Router
    , private apiServ: ApiService_Service, private apiServ_Group: ApiService_GroupService) {
    translate.addLangs(['en', 'ar']);
    translate.setDefaultLang(this.translate.instant(GlobalConstants.setDefaultLang));
    this.gridOptions = {
      columnDefs: this.GetAgColumns(),
      rowData: []
    };

  }

  ngOnInit(): void {

    this.switch_btn(true);
    this.formvalue = this.formbuilder.group({
      GroupServiceID: [''], ParentID: [''], ServiceName_A: [''], ServiceName_E: [''],
      ServiceName_I: [''], Price:[''], IS_Show: [''], Notes_A: [''], Notes_E: [''], Notes_I: ['']
    })
    // for validation
    this.formvalue = new FormGroup({
      GroupServiceID: new FormControl('',Validators.required), ParentID: new FormControl(''),
      ServiceName_A: new FormControl('',Validators.required), ServiceName_E: new FormControl(''), ServiceName_I: new FormControl(''),
      Price: new FormControl('', Validators.required), IS_Show: new FormControl(''), Notes_A: new FormControl(''), Notes_E: new FormControl(''),
      Notes_I: new FormControl(''), Photo: new FormControl('')
    });

    //fill ag grid

    this.getallService();
    //fill ddlist
    this.Fill_ddlistGroupService()
    this.Fill_ddlistParentService()
  }
  get f() {
    return this.formvalue.controls;
  }
  public getRowNodeId: GetRowNodeIdFunc = function (data) {
    return data.ServiceID;
  };

  postService() {
    this.ServiceModelobj.GroupServiceID = this.formvalue.value.GroupServiceID;
    this.ServiceModelobj.ParentID = this.formvalue.value.ParentID;
    this.ServiceModelobj.ServiceName_A = this.formvalue.value.ServiceName_A;
    this.ServiceModelobj.ServiceName_E = this.formvalue.value.ServiceName_E;
    this.ServiceModelobj.ServiceName_I = this.formvalue.value.ServiceName_I;
    this.ServiceModelobj.Price = this.formvalue.value.Price;
    this.ServiceModelobj.Photo = this.newpath;
    this.ServiceModelobj.IS_Show = $("#InputIS_Show").prop('checked');// this.formvalue.value.IS_Show;
    this.ServiceModelobj.Notes_A = this.formvalue.value.Notes_A;
    this.ServiceModelobj.Notes_E = this.formvalue.value.Notes_E;
    this.ServiceModelobj.Notes_I = this.formvalue.value.Notes_I;
    //console.log(JSON.stringify(this.ServiceModelobj))
    this.apiServ.postService(this.ServiceModelobj).subscribe(e => {

      alert(this.translate.instant('SuccessMessage'))

      this.gridApi.applyTransaction({ add: [e[0]] });

      this.formvalue.reset();
      this.Fill_ddlistParentService()
    }, er => { alert(this.translate.instant('WrongMessage')); });
  }


  getallService() {
    this.apiServ.getService().subscribe(

      ServicedataRow => { 
        this.gridOptions.rowData = ServicedataRow;
      })
  }
  Fill_ddlistGroupService() {
    this.apiServ_Group.getGroupService().subscribe(

      Row => {
        this.GroupServiceList =  Row;
      })
  }
  Fill_ddlistParentService() {
    this.apiServ.getParentService().subscribe(

      ServicedataRow => {
        this.ParentServiceList = ServicedataRow;
      })
  }
  uploadFile(files: any) {

    // let fileToUpload = <File>files[0];
    const fileToUpload = files.target.files[0];
    const formData = new FormData();
    formData.append('file', fileToUpload, fileToUpload.name);

    this.apiServ.UploadPhoto(formData).subscribe(

      Row => {
        this.newpath = Row;

        this.imageSrc = GlobalConstants.apiURL + 'Photo/' + Row
        //this.gridOptions.rowData = MedHospitaldataRow;
      })
  }
  //switch between button add and edit
  switch_btn(Is_add: boolean) {
    if (Is_add) {
      this.Show_BtnInsert = true;
      this.show_btn_Edit = false;
    }
    else {

      this.Show_BtnInsert = false;
      this.show_btn_Edit = true;
    }

  }
  click_btnInsert() {
    this.switch_btn(true);
    // open pop modal
    ($('#exampleModal') as any).modal('show');
    this.formvalue.reset();
  }
  closeModule() {

    ($('#exampleModal') as any).modal('hide');
  }
  OnEdit(row: any) {

    this.ServiceModelobj.ServiceID = row.ServiceID;
    this.formvalue.controls['GroupServiceID'].setValue(row.GroupServiceID);
    this.formvalue.controls['ParentID'].setValue(row.ParentID);
    this.formvalue.controls['ServiceName_A'].setValue(row.ServiceName_A);
    this.formvalue.controls['ServiceName_E'].setValue(row.ServiceName_E);
    this.formvalue.controls['ServiceName_I'].setValue(row.ServiceName_I);
    this.formvalue.controls['Price'].setValue(row.Price);
    this.imageSrc = GlobalConstants.apiURL + "Photo/" + row.Photo
    this.newpath = row.Photo;
    this.formvalue.controls['IS_Show'].setValue(row.IS_Show);
    this.formvalue.controls['Notes_A'].setValue(row.Notes_A);
    this.formvalue.controls['Notes_E'].setValue(row.Notes_E);
    this.formvalue.controls['Notes_I'].setValue(row.Notes_I);


    // open pop modal
    ($('#exampleModal') as any).modal('show');
    // swtch buttons
    this.switch_btn(false);

  }
  updateService() {
    this.ServiceModelobj.GroupServiceID = this.formvalue.value.GroupServiceID;
    this.ServiceModelobj.ParentID = this.formvalue.value.ParentID;
    this.ServiceModelobj.ServiceName_A = this.formvalue.value.ServiceName_A;
    this.ServiceModelobj.ServiceName_E = this.formvalue.value.ServiceName_E;
    this.ServiceModelobj.ServiceName_I = this.formvalue.value.ServiceName_I;
    this.ServiceModelobj.Price = this.formvalue.value.Price;
    this.ServiceModelobj.Photo = this.newpath;
  
    this.ServiceModelobj.IS_Show = $("#InputIS_Show").prop('checked');// this.formvalue.value.IS_Show;
    this.ServiceModelobj.Notes_A = this.formvalue.value.Notes_A;
    this.ServiceModelobj.Notes_E = this.formvalue.value.Notes_E;
    this.ServiceModelobj.Notes_I = this.formvalue.value.Notes_I;
    console.log(JSON.stringify(this.ServiceModelobj))
    this.apiServ.updateService(this.ServiceModelobj, this.ServiceModelobj.ServiceID).subscribe(res => {
      alert(this.translate.instant('UpdateMessage'));

      this.rowNode = this.gridApi.getRowNode(this.ServiceModelobj.ServiceID)!;
      this.rowNode.setData(res[0]);
      // this.formvalue.reset();
    });
  }

  // for ag grid

  onGridReady(params: GridReadyEvent) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  }
  // create column of Ag grid
  private GetAgColumns(): ColDef[] {

    return [
      {
        headerName: this.translate.instant('BtnEdit'),
        cellRendererFramework: ButtonEditRendererComponent,
        cellRendererParams: {
          onClick: this.onBtnEdit_Click.bind(this),
          pk_Name: 'ServiceID'
        }
      },
      {
        headerName: this.translate.instant('btnlblDelete'),
        cellRendererFramework: ButtonDeleteRendererComponent,
        cellRendererParams: {
          onClick: this.onBtnDelet_Click.bind(this),
          pk_Name: 'ServiceID'
        }
      },
      { headerName: this.translate.instant('ServiceName_A'), field: 'ServiceName_A', sortable: true, filter: true },
      { headerName: this.translate.instant('ParentID'), field: 'parent', sortable: true, filter: true },
      { headerName: this.translate.instant('GroupName_A'), field: 'GroupName_A', sortable: true, filter: true },
    ];


  }
  // event for button in Ag Grid

  onBtnEdit_Click(e: { rowData: {}; }) {

    this.OnEdit(e.rowData);
  }
  onBtnDelet_Click(e: {
    event: Event,
    rowData: any, pk_value: number
  }) {
    // alert(JSON.stringify(e.rowData));
    // delete from dataBase 
    if (confirm(this.translate.instant('DeleteConfirm'))) {
      this.apiServ.deleteService(e.pk_value).subscribe((res: any) => {
        alert(this.translate.instant('DeleteMessage'));
        let deletedRow = e.rowData;
        this.gridApi.updateRowData({ remove: [deletedRow] });
      });

    }
  }
}
