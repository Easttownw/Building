export class ServiceModel {
      ServiceID: number = 0;
 GroupServiceID: string = '';
 ParentID: string|null = null;
 ServiceName_A: string = '';
 ServiceName_E: string = '';
  ServiceName_I: string = '';
  Price: number = 0;
  Photo: string = '';
 IS_Show: string = '';
 Notes_A: string = '';
 Notes_E: string = '';
 Notes_I: string = '';


}
