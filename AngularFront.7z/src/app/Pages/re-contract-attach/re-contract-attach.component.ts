import { Component, OnInit, Inject, ViewChild, Input, SimpleChanges } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms'
import { ApiService_RebuildingAttach } from '../../shared/RebuildingAttach.api.service'
import { Router } from '@angular/router' 
import { HttpClient } from '@angular/common/http'
import { ButtonEditRendererComponent } from '../../renderer/buttonEdit-renderer.component';
import { ButtonDeleteRendererComponent } from '../../renderer/buttonDelete-renderer.component';
import { TranslateService } from '@ngx-translate/core';
import { GlobalConstants } from '../../common/global-constants';

import {
  GridOptions,
  ColDef,
  GridReadyEvent,
  ColumnApi,
  GridApi,
  GetRowNodeIdFunc
} from "ag-grid-community";
import { ReContractAttachModel } from './ReContractAttach.model';
import { ApiService_ReContractAttach } from '../../shared/ReContractAttach.api.service';

@Component({
  selector: 'app-re-contract-attach',
  templateUrl: './re-contract-attach.component.html',
  styleUrls: ['./re-contract-attach.component.css']
})
export class ReContractAttachComponent implements OnInit {

  // model 
  RebuildingAttachModelobj:
    ReContractAttachModel = new ReContractAttachModel();
  formvalue!: FormGroup;
  RebuildingAttachdataRow: any;
  // from parent
  @Input() ContractID: number = 0;

  NewPath: string = ''
  // button
  Show_BtnInsert!: boolean;
  show_btn_Edit!: boolean;
  // for grid ag
  gridOptions: GridOptions;
  ColumnDefs: any;
  RowData: any;
  gridApi: any
  gridColumnApi: any
  rowNode: any = [];
  constructor(public translate: TranslateService, private formbuilder: FormBuilder, private router: Router, private apiServ: ApiService_ReContractAttach) {
    translate.addLangs(['en', 'ar']);
    translate.setDefaultLang(this.translate.instant(GlobalConstants.setDefaultLang));
    this.gridOptions = {
      columnDefs: this.GetAgColumns(),
      rowData: []
    };

  }

  ngOnInit(): void {

    this.switch_btn(true);
    this.formvalue = this.formbuilder.group({
      BuildingAttachID: [''], FileName: ['']
    })
    //this.formvalue  = new FormGroup({
    //  name: new FormControl('', [Validators.required, Validators.minLength(3)]),
    //  email: new FormControl('', [Validators.required, Validators.email]),
    //  body: new FormControl('', Validators.required)
    //});
    // for validation
    this.formvalue = new FormGroup({
      FileName: new FormControl(''), //Path: new FormControl(''),
    });

    //fill ag grid

    this.getallRebuildingAttach();
  }

  uploadFile = (files: any = []) => {
    if (files.length === 0) {
      return;
    }
    let fileToUpload = <File>files[0];
    const formData = new FormData();
    formData.append('file', fileToUpload, fileToUpload.name);

    this.apiServ.uploadFile(formData).subscribe(

      Row => {

        this.NewPath = Row.fileName;

      })
  }
  get f() {
    return this.formvalue.controls;
  }
  public getRowNodeId: GetRowNodeIdFunc = function (data) {
    return data.BuildingAttachID;
  };
  ngOnChanges(changes: SimpleChanges) {
    // only run when property "data" changed

    this.getallRebuildingAttach();
  }
  postRebuildingAttach() { 
    this.RebuildingAttachModelobj.ContractID = this.ContractID;
    this.RebuildingAttachModelobj.FileName = this.formvalue.value.FileName;
    this.RebuildingAttachModelobj.Path = this.NewPath;
    console.log(JSON.stringify(this.RebuildingAttachModelobj))
    this.apiServ.postReContractAttach(this.RebuildingAttachModelobj).subscribe(e => {

      alert(this.translate.instant('SuccessMessage'))

      this.gridApi.applyTransaction({ add: [e[0]] });

      this.formvalue.reset();

    }, er => { alert(this.translate.instant('WrongMessage')); });
  }


  getallRebuildingAttach() {
    this.apiServ.getReContractAttach(this.ContractID).subscribe(

      RebuildingAttachdataRow => {
        this.gridOptions.rowData = RebuildingAttachdataRow;
      })
  }


  //switch between button add and edit
  switch_btn(Is_add: boolean) {
    if (Is_add) {
      this.Show_BtnInsert = true;
      this.show_btn_Edit = false;
    }
    else {

      this.Show_BtnInsert = false;
      this.show_btn_Edit = true;
    }

  }
  Switch_Div(Is_add: boolean) {
    if (Is_add) {
      $("#div_search").hide();
      $("#Div_attachDetails").show();
    }
    else {

      $("#div_search").show();
      $("#Div_attachDetails").hide();
    }
  }
  click_btnInsert() {
    this.switch_btn(true);
    // open pop modal
    this.Switch_Div(true)
    this.formvalue.reset();
  }
  click_ShowAll() {
    this.Switch_Div(false)
  }
  closeModule() {

    ($('#exampleModal') as any).modal('hide');
  }
  OnEdit(row: any) {

    this.RebuildingAttachModelobj.ContractAttachID = row.BuildingAttachID;
    //this.formvalue.controls['BuildingAttachID'].setValue(row.BuildingAttachID);

    this.formvalue.controls['FileName'].setValue(row.FileName);


    // open pop modal
    //  ($('#exampleModal') as any).modal('show');
    // swtch buttons
    this.switch_btn(false);
    this.Switch_Div(true)

  }
  updateRebuildingAttach() {
    this.RebuildingAttachModelobj.ContractAttachID = this.formvalue.value.ContractAttachID;
    this.RebuildingAttachModelobj.ContractID = this.ContractID;
    this.RebuildingAttachModelobj.FileName = this.formvalue.value.FileName;
    this.RebuildingAttachModelobj.Path = this.NewPath;
    console.log(JSON.stringify(this.RebuildingAttachModelobj))
    this.apiServ.updateReContractAttach(this.RebuildingAttachModelobj, this.RebuildingAttachModelobj.ContractAttachID).subscribe(res => {
      alert(this.translate.instant('UpdateMessage'));

      this.rowNode = this.gridApi.getRowNode(this.RebuildingAttachModelobj.ContractAttachID)!;
      this.rowNode.setData(res[0]);
      // this.formvalue.reset();
    });
  }

  // for ag grid

  onGridReady(params: GridReadyEvent) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  }
  // create column of Ag grid
  private GetAgColumns(): ColDef[] {

    return [
      { headerName: this.translate.instant('FileName'), field: 'FileName', sortable: true, filter: true },
      {
        headerName: this.translate.instant('btnlblEdit'),
        cellRendererFramework: ButtonEditRendererComponent,
        cellRendererParams: {
          onClick: this.onBtnEdit_Click.bind(this),
          pk_Name: 'BuildingAttachID'
        }
      },
      {
        headerName: this.translate.instant('btnlblDelete'),
        cellRendererFramework: ButtonDeleteRendererComponent,
        cellRendererParams: {
          onClick: this.onBtnDelet_Click.bind(this),
          pk_Name: 'BuildingAttachID'
        }
      },

    ];


  }
  // event for button in Ag Grid

  onBtnEdit_Click(e: { rowData: {}; }) {

    this.OnEdit(e.rowData);
  }
  onBtnDelet_Click(e: {
    event: Event,
    rowData: any, pk_value: number
  }) {
    // alert(JSON.stringify(e.rowData));
    // delete from dataBase 
    if (confirm(this.translate.instant('DeleteConfirm'))) {
      this.apiServ.deleteReContractAttach(e.pk_value).subscribe((res: any) => {
        alert(this.translate.instant('DeleteMessage'));
        let deletedRow = e.rowData;
        this.gridApi.updateRowData({ remove: [deletedRow] });
      });

    }
  }
}
