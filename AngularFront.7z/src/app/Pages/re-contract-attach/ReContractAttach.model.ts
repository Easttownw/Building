export class ReContractAttachModel {
  ContractAttachID: number = 0;

  ContractID: number = 0;

 FileName: string = '';
 Path: string = '';


}
