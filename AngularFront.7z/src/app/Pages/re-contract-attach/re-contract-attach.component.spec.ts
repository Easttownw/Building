import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReContractAttachComponent } from './re-contract-attach.component';

describe('ReContractAttachComponent', () => {
  let component: ReContractAttachComponent;
  let fixture: ComponentFixture<ReContractAttachComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReContractAttachComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReContractAttachComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
