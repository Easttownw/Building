import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { ApiService_Company } from '../../shared/Company.api.service';
import { Router } from '@angular/router';
import { CompanyModel } from './Company.model';
import { ButtonEditRendererComponent } from '../../renderer/buttonEdit-renderer.component';
import { ButtonDeleteRendererComponent } from '../../renderer/buttonDelete-renderer.component';
import { TranslateService } from '@ngx-translate/core';
import { GlobalConstants } from '../../common/global-constants';
import {
  GridOptions,
  ColDef,
  GridReadyEvent, GetRowNodeIdFunc
} from "ag-grid-community";
import { Validators } from 'ngx-editor';



@Component({
  selector: 'app-company',
  templateUrl: './company.component.html',
  styleUrls: ['./company.component.css']
})
export class companycomponent implements OnInit {

  // model 
  CompanyModelobj: CompanyModel = new CompanyModel();
  formvalue!: FormGroup;
  CompanydataRow: any;
 
  // button
  Show_BtnInsert!: boolean;
  show_btn_Edit!: boolean;
  // for grid ag
  gridOptions: GridOptions;
  ColumnDefs: any;
  RowData: any;
  gridApi: any;
  gridColumnApi: any;
  rowNode: any = [];
  constructor(public translate: TranslateService, private formbuilder: FormBuilder, private router: Router, private apiServ: ApiService_Company) {
    translate.addLangs(['en', 'ar']);
    translate.setDefaultLang(this.translate.instant(GlobalConstants.setDefaultLang));
    this.gridOptions = {
      columnDefs: this.GetAgColumns(),
      rowData: []
    };

  }

  ngOnInit(): void {

    this.switch_btn(true);
    this.formvalue = this.formbuilder.group({
      CompanyName: [''], CompanyName_E: [''], CompanyName_I:[''], Tel: [''], Mobile: [''], Address: [''], Notes: ['']
    });
    //this.formvalue  = new FormGroup({
    //  name: new FormControl('', [Validators.required, Validators.minLength(3)]),
    //  email: new FormControl('', [Validators.required, Validators.email]),
    //  body: new FormControl('', Validators.required)
    //});
    // for validation
    this.formvalue = new FormGroup({
      CompanyName: new FormControl('', Validators.required()),
      CompanyName_E: new FormControl(''),
      CompanyName_I: new FormControl(''), 
      Tel: new FormControl(''), Mobile: new FormControl('', Validators.required()), Address: new FormControl(''), Notes: new FormControl(''),
    });

    //fill ag grid
    this.getallCompany();
  }
  get f() {
    return this.formvalue.controls;
  }
  public getRowNodeId: GetRowNodeIdFunc = function (data) {
    return data.CompanyID;
  };

  postCompany() {
    this.CompanyModelobj.CompanyName = this.formvalue.value.CompanyName;

    this.CompanyModelobj.CompanyName_E = this.formvalue.value.CompanyName_E;
    this.CompanyModelobj.CompanyName_I = this.formvalue.value.CompanyName_I;

    this.CompanyModelobj.Tel = this.formvalue.value.Tel;
    this.CompanyModelobj.Mobile = this.formvalue.value.Mobile;
    this.CompanyModelobj.Address = this.formvalue.value.Address;
    this.CompanyModelobj.Notes = this.formvalue.value.Notes;
    console.log(JSON.stringify(this.CompanyModelobj))
    this.apiServ.postCompany(this.CompanyModelobj).subscribe(e => {

      alert(this.translate.instant('SuccessMessage'));

      this.gridApi.applyTransaction({ add: [e[0]] });

      this.formvalue.reset();

    }, er => { alert(this.translate.instant('WrongMessage')); });
  }


  getallCompany() {
    this.apiServ.getCompany().subscribe(

      CompanydataRow => { 
   console.log(JSON.stringify(CompanydataRow));
        this.gridOptions.rowData = CompanydataRow;
      });
  }


  //switch between button add and edit
  switch_btn(Is_add: boolean) {
    if (Is_add) {
      this.Show_BtnInsert = true;
      this.show_btn_Edit = false;
    }
    else {

      this.Show_BtnInsert = false;
      this.show_btn_Edit = true;
    }

  }
  click_btnInsert() {
    this.switch_btn(true);
    // open pop modal
    ($('#exampleModal') as any).modal('show');
    this.formvalue.reset();
  }
  closeModule() {

    ($('#exampleModal') as any).modal('hide');
  }
 
  OnEdit(row: any) { 
    this.CompanyModelobj.CompanyID = row.CompanyID;
    this.formvalue.controls['CompanyName'].setValue(row.CompanyName);
    this.formvalue.controls['CompanyName_E'].setValue(row.CompanyName_E);
    this.formvalue.controls['CompanyName_I'].setValue(row.CompanyName_I);
    this.formvalue.controls['Tel'].setValue(row.Tel);
    this.formvalue.controls['Mobile'].setValue(row.Mobile);
    this.formvalue.controls['Address'].setValue(row.Address);
    this.formvalue.controls['Notes'].setValue(row.Notes);

    // open pop modal
    ($('#exampleModal') as any).modal('show');
    // swtch buttons
    this.switch_btn(false);

  }
  updateCompany() { 
   // this.CompanyModelobj.CompanyID = this.companyId;
    this.CompanyModelobj.CompanyName = this.formvalue.value.CompanyName;
    this.CompanyModelobj.CompanyName_E = this.formvalue.value.CompanyName_E;
    this.CompanyModelobj.CompanyName_I = this.formvalue.value.CompanyName_I;
    this.CompanyModelobj.Tel = this.formvalue.value.Tel;
    this.CompanyModelobj.Mobile = this.formvalue.value.Mobile;
    this.CompanyModelobj.Address = this.formvalue.value.Address;
    this.CompanyModelobj.Notes = this.formvalue.value.Notes;
  
    this.apiServ.updateCompany(this.CompanyModelobj, this.CompanyModelobj.CompanyID).subscribe(res => {
      alert(this.translate.instant('UpdateMessage'));

      this.rowNode = this.gridApi.getRowNode(this.CompanyModelobj.CompanyID)!;
      this.rowNode.setData(res[0]);
      // this.formvalue.reset();
    });
  }

  // for ag grid
  onGridReady(params: GridReadyEvent) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  }
  // create column of Ag grid
  private GetAgColumns(): ColDef[] {

    return [
      {
        headerName: this.translate.instant('BtnEdit'),
        cellRendererFramework: ButtonEditRendererComponent,
        cellRendererParams: {
          onClick: this.onBtnEdit_Click.bind(this),
          pk_Name: 'CompanyID'
        }
      },
      {
        headerName: this.translate.instant('btnlblDelete'),
        cellRendererFramework: ButtonDeleteRendererComponent,
        cellRendererParams: {
          onClick: this.onBtnDelet_Click.bind(this),
          pk_Name: 'CompanyID'
        }
      },
      { headerName: this.translate.instant('Company'), field:'CompanyName' ,sortable:true,filter:true }
    ];


  }
  // event for button in Ag Grid
  onBtnEdit_Click(e: { rowData: {}; }) {

    this.OnEdit(e.rowData);
  }
  onBtnDelet_Click(e: {
    event: Event;
    rowData: any; pk_value: number;
  }) {
    // alert(JSON.stringify(e.rowData));
    // delete from dataBase 
    if (confirm(this.translate.instant('DeleteConfirm'))) {
      this.apiServ.deleteCompany(e.pk_value).subscribe((res: any) => {
        alert(this.translate.instant('DeleteMessage'));
        let deletedRow = e.rowData;
        this.gridApi.updateRowData({ remove: [deletedRow] });
      });

    }
  }
}
