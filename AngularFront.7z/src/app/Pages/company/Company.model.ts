export class CompanyModel {
 
  CompanyID: number = 0;
  CompanyName: string  = '';
  CompanyName_E: string | null = null;
  CompanyName_I: string | null = null;
  Tel: string | null = null;
  Mobile: string | null = null;
  Address: string | null = null;
  Notes: string | null = null;
}
