 
export class ReTenantIModel {
  TenantID: number = 0;
  TenantName: string = '';
  Tel: string = '';
  Mobile: string = '';
  Nationality: string = '';
  IDNumber: string = '';
  TenantType: string = '';
  ZipCode: string = '';
  MailBox: string = '';
  Email: string = '';
  Address: string = '';
  Notes: string = '';

  ContractID: number = 0;

  BuildingID: number = 0;
  FlatID: number = 0;
  DateContract: Date = new Date;
  ContractNo: string = '';
  ExpireContract: Date = new Date;
  Rent: string = '';
  PeriodPayed: string = '';
  NotificationBy: string = '';
  CreatedBy: string = '1';
  CreateDate: Date = new Date;
  IS_End: string = '';
}
