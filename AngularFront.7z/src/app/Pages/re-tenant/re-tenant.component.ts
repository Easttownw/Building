import { Component, OnInit, Inject, ViewChild, Input, SimpleChanges } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms'
import { ApiService_ReTenantI } from '../../shared/ReTenantI.api.service'
import { Router } from '@angular/router'
import { ReTenantIModel } from './ReTenantI.model'; 
import { ButtonEditRendererComponent } from '../../renderer/buttonEdit-renderer.component';
import { ButtonDeleteRendererComponent } from '../../renderer/buttonDelete-renderer.component';
import { TranslateService } from '@ngx-translate/core';
import { GlobalConstants } from '../../common/global-constants';

import {
  GridOptions,
  ColDef,
  GridReadyEvent,
  ColumnApi,
  GridApi,
  GetRowNodeIdFunc
} from "ag-grid-community";
import { jsDocComment } from '@angular/compiler';
import { _global } from '@angular/localize/src/localize';
import { ApiService_Rebuilding } from '../../shared/Rebuilding.api.service';
import { ApiService_ReBuildingFlat } from '../../shared/ReBuildingFlat.api.service';

@Component({
  selector: 'app-re-tenant',
  templateUrl: './re-tenant.component.html',
  styleUrls: ['./re-tenant.component.css']
})
export class ReTenantComponent implements OnInit {

  // model 
  ReTenantIModelobj:
    ReTenantIModel = new ReTenantIModel();
  formvalue!: FormGroup;
  ReTenantIdataRow: any;
  @Input() OwnerID: number = 0;
  @Input() BuildingID: number = 0;
  ContractID:number=0
  // button
  Show_BtnInsert!: boolean;
  show_btn_Edit!: boolean;
  // for grid ag
  gridOptions: GridOptions;
  ColumnDefs: any;
  RowData: any;
  gridApi: any
  gridColumnApi: any
  rowNode: any = [];
  BuildingList: any = [];
  BuildingNumberList: any = [];
  FlatNumberList:any=[]
  constructor(public translate: TranslateService, private formbuilder: FormBuilder, private router: Router, private apiServ: ApiService_ReTenantI, private apiServ_Building: ApiService_Rebuilding
    , private apiServ_Flat: ApiService_ReBuildingFlat  ) {
    translate.addLangs(['en', 'ar']);
    translate.setDefaultLang(this.translate.instant(GlobalConstants.setDefaultLang));
    this.gridOptions = {
      columnDefs: this.GetAgColumns(),
      rowData: []
    };

  }

  ngOnInit(): void {

    this.switch_btn(true);
    this.formvalue = this.formbuilder.group({
      TenantName: [''], Tel: [''], Mobile: [''], Nationality: [''], IDNumber: [''], DateContract: [''], ContractNo: [''], ExpireContract: [''], Rent: [''], PeriodPayed: [''], NotificationBy: [''], IS_End: ['']
      , TenantType: [''], ZipCode: [''], MailBox: [''], Email: [''], Address: [''], Notes: [''], FlatID:['']
    })
    //this.formvalue  = new FormGroup({
    //  name: new FormControl('', [Validators.required, Validators.minLength(3)]),
    //  email: new FormControl('', [Validators.required, Validators.email]),
    //  body: new FormControl('', Validators.required)
    //});

    // for validation
    this.formvalue = new FormGroup({
      TenantName: new FormControl('', Validators.required), Tel: new FormControl(''), Mobile: new FormControl(''), Nationality: new FormControl(''), IDNumber: new FormControl('', Validators.required),
      DateContract: new FormControl('', Validators.required), ContractNo: new FormControl('', Validators.required), ExpireContract: new FormControl('', Validators.required),
      Rent: new FormControl('', Validators.required), PeriodPayed: new FormControl('', Validators.required)
      , NotificationBy: new FormControl(''), IS_End: new FormControl(''), BuildingID: new FormControl('', Validators.required), FlatID: new FormControl('', Validators.required)
      , TenantType: new FormControl(''), ZipCode: new FormControl(''), MailBox: new FormControl(''), Email: new FormControl(''), Address: new FormControl(''), Notes: new FormControl(''),
    });

  
    this.getallReTenantI();
    //fill ag grid
  this.FillBuildingAvaible();
  }
  ngOnChanges(changes: SimpleChanges) {
    this.getallReTenantI()
    //console.log(changes)
  }
  get f() {
    return this.formvalue.controls;
  }
  public getRowNodeId: GetRowNodeIdFunc = function (data) {
    return data.TenantID;
  };

  postReTenantI() {
    this.ReTenantIModelobj.TenantName = this.formvalue.value.TenantName;
    this.ReTenantIModelobj.Tel = this.formvalue.value.Tel;
    this.ReTenantIModelobj.Mobile = this.formvalue.value.Mobile;
    this.ReTenantIModelobj.Nationality = this.formvalue.value.Nationality;
    this.ReTenantIModelobj.IDNumber = this.formvalue.value.IDNumber;
    //
 
    this.ReTenantIModelobj.FlatID = this.formvalue.value.FlatID;
    this.ReTenantIModelobj.DateContract = this.formvalue.value.DateContract;
    this.ReTenantIModelobj.ContractNo = this.formvalue.value.ContractNo;
    this.ReTenantIModelobj.ExpireContract = this.formvalue.value.ExpireContract;
    this.ReTenantIModelobj.Rent = this.formvalue.value.Rent;
    this.ReTenantIModelobj.PeriodPayed = this.formvalue.value.PeriodPayed;
    this.ReTenantIModelobj.NotificationBy = this.formvalue.value.NotificationBy;
    //this.ReTenantIModelobj.CreatedBy = this.formvalue.value.CreatedBy;
    this.ReTenantIModelobj.IS_End = $("#chk_IS_End").prop("checked");// this.formvalue.value.IS_End;

    this.apiServ.postReTenantI(this.ReTenantIModelobj).subscribe(e => {

      alert(this.translate.instant('SuccessMessage'))

      this.gridApi.applyTransaction({ add: [e[0]] });

      /*    this.formvalue.reset();*/

      this.ReTenantIModelobj.TenantID = e[0].TenantID;
      this.ContractID = e[0].ContractID;
      this.formvalue.controls['TenantName'].setValue(e[0].TenantName);
      this.formvalue.controls['Tel'].setValue(e[0].Tel);
      this.formvalue.controls['Mobile'].setValue(e[0].Mobile);
      this.formvalue.controls['Nationality'].setValue(e[0].Nationality);
      this.formvalue.controls['IDNumber'].setValue(e[0].IDNumber);

      this.switch_btn(false)
    }, er => { alert(this.translate.instant('WrongMessage')); });
  }


  getallReTenantI() {
    
    this.apiServ.getAllReTenant().subscribe(

        ReTenantIdataRow => {
          //console.log(JSON.stringify(ReTenantIdataRow))
          //this.OnEdit(ReTenantIdataRow);
           this.gridOptions.rowData = ReTenantIdataRow;
        })
   
  }
  FillBuildingAvaible() {
    
    this.apiServ_Building.Get_Available_building( ).subscribe(

      ReTenantIdataRow => {
         
        this.BuildingList = ReTenantIdataRow;
        this.BuildingNumberList = ReTenantIdataRow;
      })
  }
  FillBuildingAll() {

    this.apiServ_Building.getRebuilding().subscribe(

      ReTenantIdataRow => {

        this.BuildingList = ReTenantIdataRow;
      })
  }
  FillFlats(buildingID:string) {
 
    this.apiServ_Flat.getReBuildingFlat(Number(buildingID)).subscribe(

      ReTenantIdataRow => {

        this.FlatNumberList = ReTenantIdataRow;
      })
  }
  //switch between button add and edit
  switch_btn(Is_add: boolean) {
    if (Is_add) {
      this.Show_BtnInsert = true;
      this.show_btn_Edit = false;
    }
    else {

      this.Show_BtnInsert = false;
      this.show_btn_Edit = true;
    }

  }
  click_btnInsert() {
    this.switch_btn(true);
    // open pop modal
    ($('#exampleModal') as any).modal('show');
    this.formvalue.reset();
  }
  closeModule() {

    ($('#exampleModal') as any).modal('hide');
  }
  OnEdit(row: any) {
    this.FillBuildingAll()
    this.ReTenantIModelobj.TenantID = row.TenantID;
    this.ReTenantIModelobj.ContractID = row.ContractID;
    this.ContractID = row.ContractID;
    this.formvalue.controls['TenantName'].setValue(row.TenantName);
    this.formvalue.controls['Tel'].setValue(row.Tel);
    this.formvalue.controls['Mobile'].setValue(row.Mobile);
    this.formvalue.controls['Nationality'].setValue(row.Nationality);
    this.formvalue.controls['IDNumber'].setValue(row.IDNumber);

    this.formvalue.controls['BuildingID'].setValue(row.BuildingID);
    this.formvalue.controls['FlatID'].setValue(row.FlatID);
    
    this.formvalue.controls['DateContract'].setValue(row.DateContract);
    this.formvalue.controls['ContractNo'].setValue(row.ContractNo);
    this.formvalue.controls['ExpireContract'].setValue(row.ExpireContract);
    this.formvalue.controls['Rent'].setValue(row.Rent);
    this.formvalue.controls['PeriodPayed'].setValue(row.PeriodPayed);
    this.formvalue.controls['NotificationBy'].setValue(row.NotificationBy);
    //this.formvalue.controls['CreatedBy'].setValue(row.CreatedBy);
    this.formvalue.controls['IS_End'].setValue(row.IS_End);

    ($('#exampleModal') as any).modal('show');
    // swtch buttons
    this.switch_btn(false);

  }
  updateReTenantI() {
    this.ReTenantIModelobj.TenantName = this.formvalue.value.TenantName;
    this.ReTenantIModelobj.Tel = this.formvalue.value.Tel;
    this.ReTenantIModelobj.Mobile = this.formvalue.value.Mobile;
    this.ReTenantIModelobj.Nationality = this.formvalue.value.Nationality;
    this.ReTenantIModelobj.IDNumber = this.formvalue.value.IDNumber;

    this.ReTenantIModelobj.FlatID = this.formvalue.value.FlatID;// this.BuildingID;
  // this.ReTenantIModelobj.DateContract =Date( GlobalConstants.convertdate(this.formvalue.value.DateContract).toString()) ;
    this.ReTenantIModelobj.ContractNo = this.formvalue.value.ContractNo;
   // this.ReTenantIModelobj.ExpireContract = GlobalConstants.convertdate(this.formvalue.value.ExpireContract) ;
    this.ReTenantIModelobj.Rent = this.formvalue.value.Rent;
    this.ReTenantIModelobj.PeriodPayed = this.formvalue.value.PeriodPayed;
    this.ReTenantIModelobj.NotificationBy = this.formvalue.value.NotificationBy;
    //this.ReTenantIModelobj.CreatedBy = this.formvalue.value.CreatedBy;
    this.ReTenantIModelobj.IS_End = $("#chk_IS_End").prop("checked");// this.formvalue.value.IS_End;
    console.log(JSON.stringify(this.ReTenantIModelobj));
    this.apiServ.updateReTenantI(this.ReTenantIModelobj, this.ReTenantIModelobj.TenantID).subscribe(res => {
      alert(this.translate.instant('UpdateMessage'));

      this.rowNode = this.gridApi.getRowNode(this.ReTenantIModelobj.TenantID)!;
      this.rowNode.setData(res[0]);
      // this.formvalue.reset();
    });
  }

  // for ag grid

  onGridReady(params: GridReadyEvent) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  }
  // create column of Ag grid
  private GetAgColumns(): ColDef[] {

    return [
      { headerName: this.translate.instant('TenantName'), field: 'TenantName', sortable: true, filter: true },
      { headerName: this.translate.instant('Mobile'), field: 'Mobile', sortable: true, filter: true },
      { headerName: this.translate.instant('Rent'), field: 'Rent', sortable: true, filter: true },
      {
        headerName: this.translate.instant('Details'),
        cellRendererFramework: ButtonEditRendererComponent,
        cellRendererParams: {
          onClick: this.onBtnEdit_Click.bind(this),title:'تفاصيل',
          pk_Name: 'TenantID'
        }
      },
      {
        headerName: this.translate.instant('btnlblDelete'),
        cellRendererFramework: ButtonDeleteRendererComponent,
        cellRendererParams: {
          onClick: this.onBtnDelet_Click.bind(this),
          pk_Name: 'TenantID'
        }
      },

    ];


  }
  // event for button in Ag Grid

  onBtnEdit_Click(e: { rowData: {}; }) {

    this.OnEdit(e.rowData);
  }
  onBtnDelet_Click(e: {
    event: Event,
    rowData: any, pk_value: number
  }) {
    // alert(JSON.stringify(e.rowData));
    // delete from dataBase 
    if (confirm(this.translate.instant('DeleteConfirm'))) {
      this.apiServ.deleteReTenantI(e.pk_value).subscribe((res: any) => {
        alert(this.translate.instant('DeleteMessage'));
        let deletedRow = e.rowData;
        this.gridApi.updateRowData({ remove: [deletedRow] });
      });

    }
  }
}

