import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms'
import { ApiService_Technician } from '../../shared/Technician.api.service'
import { Router } from '@angular/router'
import { TechnicianModel } from './Technician.model';
import { HttpClient } from '@angular/common/http' 
import { ButtonEditRendererComponent } from '../../renderer/buttonEdit-renderer.component';
import { ButtonDeleteRendererComponent } from '../../renderer/buttonDelete-renderer.component';
import { TranslateService } from '@ngx-translate/core';
import { GlobalConstants } from '../../common/global-constants';
 
import {
  GridOptions,
  ColDef,
  GridReadyEvent,
  ColumnApi,
    GridApi,
    GetRowNodeIdFunc
} from "ag-grid-community";
import { ApiService_Company } from '../../shared/Company.api.service';

@Component({
  selector: 'app-technician',
  templateUrl: './technician.component.html',
  styleUrls: ['./technician.component.css']
})
export class TechnicianComponent implements  OnInit {

  // model 
      TechnicianModelobj:
TechnicianModel = new TechnicianModel(); 
  formvalue!: FormGroup;
  TechniciandataRow: any;
  CompanyList:any=[]

  // button
  Show_BtnInsert!: boolean;
  show_btn_Edit!: boolean;
  // for grid ag
  gridOptions: GridOptions; 
  ColumnDefs: any;
  RowData: any;
  gridApi: any
    gridColumnApi: any
    rowNode: any = [];
  constructor(public translate: TranslateService, private formbuilder: FormBuilder, private router: Router
    , private apiServ: ApiService_Technician, private apiServ_company: ApiService_Company) {
        translate.addLangs(['en', 'ar']);
        translate.setDefaultLang(this.translate.instant(GlobalConstants.setDefaultLang));
    this.gridOptions = {
      columnDefs: this.GetAgColumns(),
      rowData: [] 
    };

  }

    ngOnInit(): void {

        this.switch_btn(true);
     this.formvalue = this.formbuilder.group({
          Name_A: [''], Name_E: [''], Name_I: [''], Tel: [''], Mobile: [''], Photo: [''], CompanyID: [''] 
     })
    //this.formvalue  = new FormGroup({
    //  name: new FormControl('', [Validators.required, Validators.minLength(3)]),
    //  email: new FormControl('', [Validators.required, Validators.email]),
    //  body: new FormControl('', Validators.required)
    //});
    // for validation
    this.formvalue = new FormGroup({
      Name_A: new FormControl('', Validators.required), Name_E: new FormControl('', Validators.required),
      Name_I: new FormControl('', Validators.required), Tel: new FormControl(''), Mobile: new FormControl(''), Photo: new FormControl('')
      , CompanyID: new FormControl('') 
    });
   
    //fill ag grid

      this.getallTechnician();
      //dlist
      this.Fill_ddlist_company()
  }
  get f() {
    return this.formvalue.controls;
    }
    public getRowNodeId: GetRowNodeIdFunc = function (data) {
      return data.TechnicianID;
    };

    postTechnician() { 
      this.TechnicianModelobj.Name_A = this.formvalue.value.Name_A;
      this.TechnicianModelobj.Name_E = this.formvalue.value.Name_E;
      this.TechnicianModelobj.Name_I = this.formvalue.value.Name_I;
      this.TechnicianModelobj.Tel = this.formvalue.value.Tel;
      this.TechnicianModelobj.Mobile = this.formvalue.value.Mobile;
     // this.TechnicianModelobj.Photo = this.formvalue.value.Photo;
      this.TechnicianModelobj.Photo = this.newpath;
      alert(this.formvalue.value.CompanyID)
      this.TechnicianModelobj.CompanyID = this.formvalue.value.CompaniesID;
      this.TechnicianModelobj.CreateBy = String(localStorage.getItem('UserID')); ;
  //this.TechnicianModelobj.CreatedDate = this.formvalue.value.CreatedDate;
      this.TechnicianModelobj.Lang = '1';
      console .log(JSON.stringify(this.TechnicianModelobj))
 this.apiServ.postTechnician(this.TechnicianModelobj).subscribe(e => {
      
      alert(this.translate.instant('SuccessMessage')) 
 
      this.gridApi.applyTransaction({ add:  [e[0]] }); 
      
        this.formvalue.reset();

    }, er => { alert(this.translate.instant('WrongMessage')); });
  }


    getallTechnician() {
    this.apiServ.getTechnician().subscribe(

      TechniciandataRow => { 
        this.gridOptions.rowData = TechniciandataRow;
      }) 
  }
  //fill ddlist company

  Fill_ddlist_company() {
    this.apiServ_company.getCompany().subscribe(

     Row => { 
        this.CompanyList = Row;
      })
  }

    //switch between button add and edit
    switch_btn(Is_add: boolean) {
        if (Is_add) {
            this.Show_BtnInsert = true;
            this.show_btn_Edit = false;
        }
        else {

            this.Show_BtnInsert = false;
            this.show_btn_Edit = true;
        }

    }
  click_btnInsert() {
    this.switch_btn(true);
        // open pop modal
        ($('#exampleModal') as any).modal('show');
      this.formvalue.reset();
    }
    closeModule() {

        ($('#exampleModal') as any).modal('hide');
    }
  OnEdit(row: any) {
 
    this.TechnicianModelobj.TechnicianID = row.TechnicianID;
this.formvalue.controls['Name_A'].setValue(row.Name_A);
this.formvalue.controls['Name_E'].setValue(row.Name_E);
this.formvalue.controls['Name_I'].setValue(row.Name_I);
this.formvalue.controls['Tel'].setValue(row.Tel);
this.formvalue.controls['Mobile'].setValue(row.Mobile);
//this.formvalue.controls['Photo'].setValue(row.Photo);
    this.imageSrc = GlobalConstants.apiURL + "Photo/" + row.Photo
this.formvalue.controls['CompanyID'].setValue(row.CompanyID);
 


          // open pop modal
          ($('#exampleModal') as any).modal('show');
      // swtch buttons
      this.switch_btn(false);

  }
  newpath: string = '';
  imageSrc:string =''
  uploadFile(files: any) {

    // let fileToUpload = <File>files[0];
    const fileToUpload = files.target.files[0];
    const formData = new FormData();
    formData.append('file', fileToUpload, fileToUpload.name);
 
    this.apiServ.uploadPhoto(formData).subscribe(

      Row => {
        this.newpath = Row;

        this.imageSrc = GlobalConstants.apiURL + 'Photo/' + Row
  
      })
  }
    updateTechnician() {
      this.TechnicianModelobj.Name_A = this.formvalue.value.Name_A;
      this.TechnicianModelobj.Name_E = this.formvalue.value.Name_E;
      this.TechnicianModelobj.Name_I = this.formvalue.value.Name_I;
      this.TechnicianModelobj.Tel = this.formvalue.value.Tel;
      this.TechnicianModelobj.Mobile = this.formvalue.value.Mobile;
     // this.TechnicianModelobj.Photo = this.formvalue.value.Photo;
      this.TechnicianModelobj.Photo = this.newpath;
      this.TechnicianModelobj.CompanyID = this.formvalue.value.CompanyID;
      this.TechnicianModelobj.CreateBy = String(localStorage.getItem('UserID'));;
//this.TechnicianModelobj.CreateBy = this.formvalue.value.CreateBy;
//this.TechnicianModelobj.CreatedDate = this.formvalue.value.CreatedDate;
this.TechnicianModelobj.Lang = '1';
      this.apiServ.updateTechnician(this.TechnicianModelobj, this.TechnicianModelobj.TechnicianID).subscribe(res => {
        alert(this.translate.instant('UpdateMessage'));

        this.rowNode = this.gridApi.getRowNode(this.TechnicianModelobj.TechnicianID)!;    
      this.rowNode.setData(res[0]);
     // this.formvalue.reset();
    });
  }

  // for ag grid
  
  onGridReady(params: GridReadyEvent) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    }
    // create column of Ag grid
  private GetAgColumns(): ColDef[] {

    return [
        {
        headerName: this.translate.instant('btnlblEdit'),
        cellRendererFramework: ButtonEditRendererComponent,
        cellRendererParams: {
          onClick: this.onBtnEdit_Click.bind(this),
          pk_Name: 'TechnicianID'
       }
      },
{
        headerName: this.translate.instant('btnlblDelete'),
        cellRendererFramework: ButtonDeleteRendererComponent,
        cellRendererParams: {
          onClick: this.onBtnDelet_Click.bind(this),
          pk_Name: 'TechnicianID'
        }
      },
      
      { headerName: this.translate.instant('CompanyID'), field: 'CompanyName', sortable: true, filter: true },
      { headerName: this.translate.instant('Name_A'), field: 'Name_A', sortable: true, filter: true },
      { headerName: this.translate.instant('Mobile'), field: 'Mobile', sortable: true, filter: true },
      { headerName: this.translate.instant('Tel'), field: 'Tel', sortable: true, filter: true },
    ];
  

  }
  // event for button in Ag Grid

  onBtnEdit_Click(e: { rowData: {}; }) {
   
    this.OnEdit(e.rowData); 
  }
  onBtnDelet_Click(e: {
    event: Event,
    rowData: any, pk_value:number
  })
  {
   // alert(JSON.stringify(e.rowData));
    // delete from dataBase 
      if (confirm(this.translate.instant('DeleteConfirm'))) {
        this.apiServ.deleteTechnician(e.pk_value).subscribe((res: any) => {
          alert(this.translate.instant('DeleteMessage'));
          alert(JSON.stringify( e.rowData))
            let deletedRow = e.rowData;
        this.gridApi.updateRowData({ remove: [deletedRow] }) ; });
       
    }
  }
}
