export class TechnicianModel {
  TechnicianID: number = 0;
  Name_A: string = '';
  Name_E: string = '';
  Name_I: string = '';
  Tel: string = '';
  Mobile: string = '';
  Photo: string = '';
  CompanyID: string = '';
  CreateBy: string | null = null;
  CreatedDate: Date = new Date();
  Lang: string = '';

 
   
}
