import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms'
import { ApiService_Customer } from '../../shared/Customer.api.service'
import { Router } from '@angular/router'
import { CustomerModel } from './Customer.model';
import { HttpClient } from '@angular/common/http' 
import { ButtonEditRendererComponent } from '../../renderer/buttonEdit-renderer.component';
import { ButtonDeleteRendererComponent } from '../../renderer/buttonDelete-renderer.component';
import { TranslateService } from '@ngx-translate/core';
import { GlobalConstants } from '../../common/global-constants';
 
import {
  GridOptions,
  ColDef,
  GridReadyEvent,
  ColumnApi,
    GridApi,
    GetRowNodeIdFunc
} from "ag-grid-community";


@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements  OnInit {

  // model 
      CustomerModelobj:
CustomerModel = new CustomerModel(); 
  formvalue!: FormGroup;
  CustomerdataRow: any;

  // button
  Show_BtnInsert!: boolean;
  show_btn_Edit!: boolean;
  // for grid ag
  gridOptions: GridOptions; 
  ColumnDefs: any;
  RowData: any;
  gridApi: any
    gridColumnApi: any
    rowNode: any = [];
    constructor(public translate: TranslateService, private formbuilder: FormBuilder, private router: Router, private apiServ: ApiService_Customer ) {
        translate.addLangs(['en', 'ar']);
        translate.setDefaultLang(this.translate.instant(GlobalConstants.setDefaultLang));
    this.gridOptions = {
      columnDefs: this.GetAgColumns(),
      rowData: [] 
    };

  }

    ngOnInit(): void {

        this.switch_btn(true);
     this.formvalue = this.formbuilder.group({
          FName: [''], LName: [''], Email: [''], Password: [''], MobileNo: [''], MobileSerial: [''], Address: [''], Lang: ['']
     })
    //this.formvalue  = new FormGroup({
    //  name: new FormControl('', [Validators.required, Validators.minLength(3)]),
    //  email: new FormControl('', [Validators.required, Validators.email]),
    //  body: new FormControl('', Validators.required)
    //});
    // for validation
    this.formvalue = new FormGroup({
        FName: new FormControl(''),LName: new FormControl(''),Email: new FormControl(''),Password: new FormControl(''),MobileNo: new FormControl(''),MobileSerial: new FormControl(''),Address: new FormControl(''),Lang: new FormControl(''),
    });
   
    //fill ag grid

      this.getallCustomer();
  }
  get f() {
    return this.formvalue.controls;
    }
    public getRowNodeId: GetRowNodeIdFunc = function (data) {
        return data.CustomerID;
    };

    postCustomer() { 
  this.CustomerModelobj.FName = this.formvalue.value.FName;
  this.CustomerModelobj.LName = this.formvalue.value.LName;
  this.CustomerModelobj.Email = this.formvalue.value.Email;
  this.CustomerModelobj.Password = this.formvalue.value.Password;
  this.CustomerModelobj.MobileNo = this.formvalue.value.MobileNo;
  this.CustomerModelobj.MobileSerial = this.formvalue.value.MobileSerial;
  this.CustomerModelobj.Address = this.formvalue.value.Address;
  this.CustomerModelobj.Lang = this.formvalue.value.Lang;
 this.apiServ.postCustomer(this.CustomerModelobj).subscribe(e => {
      
      alert(this.translate.instant('SuccessMessage')) 
 
      this.gridApi.applyTransaction({ add:  [e[0]] }); 
      
        this.formvalue.reset();

    }, er => { alert(this.translate.instant('WrongMessage')); });
  }


    getallCustomer() {
    this.apiServ.getCustomer().subscribe(

      CustomerdataRow => { 
        this.gridOptions.rowData = CustomerdataRow;
      }) 
  }


    //switch between button add and edit
    switch_btn(Is_add: boolean) {
        if (Is_add) {
            this.Show_BtnInsert = true;
            this.show_btn_Edit = false;
        }
        else {

            this.Show_BtnInsert = false;
            this.show_btn_Edit = true;
        }

    }
  click_btnInsert() {
    this.switch_btn(true);
        // open pop modal
        ($('#exampleModal') as any).modal('show');
      this.formvalue.reset();
    }
    closeModule() {

        ($('#exampleModal') as any).modal('hide');
    }
  OnEdit(row: any) {
 
      this.CustomerModelobj.CustomerID = row.CustomerID;
this.formvalue.controls['FName'].setValue(row.FName);
this.formvalue.controls['LName'].setValue(row.LName);
this.formvalue.controls['Email'].setValue(row.Email);
this.formvalue.controls['Password'].setValue(row.Password);
this.formvalue.controls['MobileNo'].setValue(row.MobileNo);
this.formvalue.controls['MobileSerial'].setValue(row.MobileSerial);
this.formvalue.controls['Address'].setValue(row.Address);
this.formvalue.controls['Lang'].setValue(row.Lang);


          // open pop modal
          ($('#exampleModal') as any).modal('show');
      // swtch buttons
      this.switch_btn(false);

  }
    updateCustomer() {
this.CustomerModelobj.FName = this.formvalue.value.FName;
this.CustomerModelobj.LName = this.formvalue.value.LName;
this.CustomerModelobj.Email = this.formvalue.value.Email;
this.CustomerModelobj.Password = this.formvalue.value.Password;
this.CustomerModelobj.MobileNo = this.formvalue.value.MobileNo;
this.CustomerModelobj.MobileSerial = this.formvalue.value.MobileSerial;
this.CustomerModelobj.Address = this.formvalue.value.Address;
this.CustomerModelobj.Lang = this.formvalue.value.Lang;
this.apiServ.updateCustomer(this.CustomerModelobj, this.CustomerModelobj.CustomerID).subscribe(res => {
        alert(this.translate.instant('UpdateMessage'));

            this.rowNode = this.gridApi.getRowNode(this.CustomerModelobj.CustomerID)!;    
      this.rowNode.setData(res[0]);
     // this.formvalue.reset();
    });
  }

  // for ag grid
  
  onGridReady(params: GridReadyEvent) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    }
    // create column of Ag grid
  private GetAgColumns(): ColDef[] {

    return [
        {
        headerName: this.translate.instant('btnlblEdit'),
        cellRendererFramework: ButtonEditRendererComponent,
        cellRendererParams: {
          onClick: this.onBtnEdit_Click.bind(this),
          pk_Name: 'CustomerID'
       }
      },
{
        headerName: this.translate.instant('btnlblDelete'),
        cellRendererFramework: ButtonDeleteRendererComponent,
        cellRendererParams: {
          onClick: this.onBtnDelet_Click.bind(this),
          pk_Name: 'CustomerID'
        }
      },

    ];
  

  }
  // event for button in Ag Grid

  onBtnEdit_Click(e: { rowData: {}; }) {
   
    this.OnEdit(e.rowData); 
  }
  onBtnDelet_Click(e: {
    event: Event,
    rowData: any, pk_value:number
  })
  {
   // alert(JSON.stringify(e.rowData));
    // delete from dataBase 
      if (confirm(this.translate.instant('DeleteConfirm'))) {
        this.apiServ.deleteCustomer(e.pk_value).subscribe((res: any) => {
            alert(this.translate.instant('DeleteMessage'));  
            let deletedRow = e.rowData;
        this.gridApi.updateRowData({ remove: [deletedRow] }) ; });
       
    }
  }
}
 
