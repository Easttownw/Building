export class CustomerModel {
      CustomerID: number = 0;
 FName: string = '';
 LName: string = '';
 Email: string = '';
 Password: string = '';
 MobileNo: string = '';
 MobileSerial: string = '';
 Address: string = '';
 Lang: string = '';


}
