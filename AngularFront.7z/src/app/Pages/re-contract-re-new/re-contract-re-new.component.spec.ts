import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReContractReNewComponent } from './re-contract-re-new.component';

describe('ReContractReNewComponent', () => {
  let component: ReContractReNewComponent;
  let fixture: ComponentFixture<ReContractReNewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReContractReNewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReContractReNewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
