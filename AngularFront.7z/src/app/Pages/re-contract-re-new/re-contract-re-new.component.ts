import { Component, OnInit, Inject, ViewChild, Input } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms'
import { ApiService_ReContractReNew } from '../../shared/ReContractReNew.api.service'
import { Router } from '@angular/router'
import { ReContractReNewModel } from './ReContractReNew.model';
import { HttpClient } from '@angular/common/http'
import { ButtonEditRendererComponent } from '../../renderer/buttonEdit-renderer.component';
import { ButtonDeleteRendererComponent } from '../../renderer/buttonDelete-renderer.component';
import { TranslateService } from '@ngx-translate/core';
import { GlobalConstants } from '../../common/global-constants';

import {
  GridOptions,
  ColDef,
  GridReadyEvent,
  ColumnApi,
  GridApi,
  GetRowNodeIdFunc
} from "ag-grid-community";


@Component({
  selector: 'app-re-contract-re-new',
  templateUrl: './re-contract-re-new.component.html',
  styleUrls: ['./re-contract-re-new.component.css']
})
export class ReContractReNewComponent implements OnInit {

  // model 
  ReContractReNewModelobj:
    ReContractReNewModel = new ReContractReNewModel();
  formvalue!: FormGroup;
  ReContractReNewdataRow: any;
  // from parent
  @Input() ContractID: number = 0;
  // button
  Show_BtnInsert!: boolean;
  show_btn_Edit!: boolean;
  // for grid ag
  gridOptions: GridOptions;
  ColumnDefs: any;
  RowData: any;
  gridApi: any
  gridColumnApi: any
  rowNode: any = [];
  constructor(public translate: TranslateService, private formbuilder: FormBuilder, private router: Router, private apiServ: ApiService_ReContractReNew) {
    translate.addLangs(['en', 'ar']);
    translate.setDefaultLang(this.translate.instant(GlobalConstants.setDefaultLang));
    this.gridOptions = {
      columnDefs: this.GetAgColumns(),
      rowData: []
    };

  }

  ngOnInit(): void {

    this.switch_btn(true);
    this.formvalue = this.formbuilder.group({
        DateContract: [''], ExpireContract: [''], Rent: [''], PeriodPayed: [''], NotesRenew: ['']
    })
    //this.formvalue  = new FormGroup({
    //  name: new FormControl('', [Validators.required, Validators.minLength(3)]),
    //  email: new FormControl('', [Validators.required, Validators.email]),
    //  body: new FormControl('', Validators.required)
    //});
    // for validation
    this.formvalue = new FormGroup({
  DateContract: new FormControl(''), ExpireContract: new FormControl(''), Rent: new FormControl(''), PeriodPayed: new FormControl(''), NotesRenew: new FormControl(''),
    });

    //fill ag grid

    this.getallReContractReNew();
  }
  get f() {
    return this.formvalue.controls;
  }
  public getRowNodeId: GetRowNodeIdFunc = function (data) {
    return data.ReNewContractID;
  };

  postReContractReNew() {
    this.ReContractReNewModelobj.ContractID = this.ContractID;
    this.ReContractReNewModelobj.DateContract = this.formvalue.value.DateContract;
    this.ReContractReNewModelobj.ExpireContract = this.formvalue.value.ExpireContract;
    this.ReContractReNewModelobj.Rent = this.formvalue.value.Rent;
    this.ReContractReNewModelobj.PeriodPayed = this.formvalue.value.PeriodPayed;
    this.ReContractReNewModelobj.NotesRenew = this.formvalue.value.NotesRenew;
    this.apiServ.postReContractReNew(this.ReContractReNewModelobj).subscribe(e => {

      alert(this.translate.instant('SuccessMessage'))

      this.gridApi.applyTransaction({ add: [e[0]] });

      this.formvalue.reset();

    }, er => { alert(this.translate.instant('WrongMessage')); });
  }


  getallReContractReNew() {
    this.apiServ.getReContractReNew().subscribe(

      ReContractReNewdataRow => {
        this.gridOptions.rowData = ReContractReNewdataRow;
      })
  }


  //switch between button add and edit
  switch_btn(Is_add: boolean) {
    if (Is_add) {
      this.Show_BtnInsert = true;
      this.show_btn_Edit = false;
    }
    else {

      this.Show_BtnInsert = false;
      this.show_btn_Edit = true;
    }

  }
  click_btnInsert() {
    this.switch_btn(true);
    // open pop modal
    ($('#exampleModal') as any).modal('show');
    this.formvalue.reset();
  }
  closeModule() {

    ($('#exampleModal') as any).modal('hide');
  }
  OnEdit(row: any) {

    this.ReContractReNewModelobj.ReNewContractID = row.ReNewContractID;
   // this.formvalue.controls['ContractID'].setValue(row.ContractID);
    this.ContractID = row.ContractID
    this.formvalue.controls['DateContract'].setValue(row.DateContract);
    this.formvalue.controls['ExpireContract'].setValue(row.ExpireContract);
    this.formvalue.controls['Rent'].setValue(row.Rent);
    this.formvalue.controls['PeriodPayed'].setValue(row.PeriodPayed);
    this.formvalue.controls['NotesRenew'].setValue(row.NotesRenew);


    // open pop modal
    ($('#exampleModal') as any).modal('show');
    // swtch buttons
    this.switch_btn(false);

  }
  updateReContractReNew() {
    this.ReContractReNewModelobj.ContractID = this.ContractID;
    this.ReContractReNewModelobj.DateContract = this.formvalue.value.DateContract;
    this.ReContractReNewModelobj.ExpireContract = this.formvalue.value.ExpireContract;
    this.ReContractReNewModelobj.Rent = this.formvalue.value.Rent;
    this.ReContractReNewModelobj.PeriodPayed = this.formvalue.value.PeriodPayed;
    this.ReContractReNewModelobj.NotesRenew = this.formvalue.value.NotesRenew;
    this.apiServ.updateReContractReNew(this.ReContractReNewModelobj, this.ReContractReNewModelobj.ReNewContractID).subscribe(res => {
      alert(this.translate.instant('UpdateMessage'));

      this.rowNode = this.gridApi.getRowNode(this.ReContractReNewModelobj.ReNewContractID)!;
      this.rowNode.setData(res[0]);
      // this.formvalue.reset();
    });
  }

  // for ag grid

  onGridReady(params: GridReadyEvent) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  }
  // create column of Ag grid
  private GetAgColumns(): ColDef[] {

    return [
      {
        headerName: this.translate.instant('btnlblEdit'),
        cellRendererFramework: ButtonEditRendererComponent,
        cellRendererParams: {
          onClick: this.onBtnEdit_Click.bind(this),
          pk_Name: 'ReNewContractID'
        }
      },
      {
        headerName: this.translate.instant('btnlblDelete'),
        cellRendererFramework: ButtonDeleteRendererComponent,
        cellRendererParams: {
          onClick: this.onBtnDelet_Click.bind(this),
          pk_Name: 'ReNewContractID'
        }
      },

    ];


  }
  // event for button in Ag Grid

  onBtnEdit_Click(e: { rowData: {}; }) {

    this.OnEdit(e.rowData);
  }
  onBtnDelet_Click(e: {
    event: Event,
    rowData: any, pk_value: number
  }) {
    // alert(JSON.stringify(e.rowData));
    // delete from dataBase 
    if (confirm(this.translate.instant('DeleteConfirm'))) {
      this.apiServ.deleteReContractReNew(e.pk_value).subscribe((res: any) => {
        alert(this.translate.instant('DeleteMessage'));
        let deletedRow = e.rowData;
        this.gridApi.updateRowData({ remove: [deletedRow] });
      });

    }
  }
}

