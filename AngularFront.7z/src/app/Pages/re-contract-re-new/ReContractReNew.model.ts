export class ReContractReNewModel {
      ReNewContractID: number = 0;
  ContractID: number = 0;
 DateContract: string = '';
 ExpireContract: string = '';
 Rent: string = '';
 PeriodPayed: string = '';
 NotesRenew: string = '';


}
