import { Component, OnInit, Inject, ViewChild, Input, SimpleChanges } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms'
import { ApiService_RePayment } from '../../shared/RePayment.api.service'
import { Router } from '@angular/router'
import { RePaymentModel } from './RePayment.model';
import { HttpClient } from '@angular/common/http'
import { ButtonEditRendererComponent } from '../../renderer/buttonEdit-renderer.component';
import { ButtonDeleteRendererComponent } from '../../renderer/buttonDelete-renderer.component';
import { TranslateService } from '@ngx-translate/core';
import { GlobalConstants } from '../../common/global-constants';

import {
  GridOptions,
  ColDef,
  GridReadyEvent,
  ColumnApi,
  GridApi,
  GetRowNodeIdFunc
} from "ag-grid-community";

@Component({
  selector: 'app-re-payment',
  templateUrl: './re-payment.component.html',
  styleUrls: ['./re-payment.component.css']
})
export class RePaymentComponent implements OnInit {

  // model 
  RePaymentModelobj:
    RePaymentModel = new RePaymentModel();
  formvalue!: FormGroup;
  RePaymentdataRow: any;
  // from parent
  @Input() RentDateID: number = 0;
  // button
  Show_BtnInsert!: boolean;
  show_btn_Edit!: boolean;
  // for grid ag
  gridOptions: GridOptions;
  ColumnDefs: any;
  RowData: any;
  gridApi: any
  gridColumnApi: any
  rowNode: any = [];
  constructor(public translate: TranslateService, private formbuilder: FormBuilder, private router: Router, private apiServ: ApiService_RePayment) {
    translate.addLangs(['en', 'ar']);
    translate.setDefaultLang(this.translate.instant(GlobalConstants.setDefaultLang));
    this.gridOptions = {
      columnDefs: this.GetAgColumns(),
      rowData: []
    };

  }

  ngOnInit(): void {

    this.switch_btn(true);
    this.formvalue = this.formbuilder.group({
      RentDateID: [''], Date: [''], TypePayed: [''], Value: [''],
      Notes: [''], DateCollection: [''], BankName: [''], CheckNo: [''], Name: ['']
      , Status: [''], RejectReason: [''], Notes_Check:['']
    })
    //this.formvalue  = new FormGroup({
    //  name: new FormControl('', [Validators.required, Validators.minLength(3)]),
    //  email: new FormControl('', [Validators.required, Validators.email]),
    //  body: new FormControl('', Validators.required)
    //});
    // for validation
    this.formvalue = new FormGroup({
      RentDateID: new FormControl(''), Date: new FormControl(''), TypePayed: new FormControl(''), Value: new FormControl(''), 
      Notes: new FormControl(''), DateCollection: new FormControl(''), BankName: new FormControl(''), CheckNo: new FormControl(''),
      Name: new FormControl(''), Status: new FormControl(''), RejectReason: new FormControl(''), Notes_Check: new FormControl(''),
    });

    //fill ag grid

    this.getallRePayment();
  }
  get f() {
    return this.formvalue.controls;
  }
  public getRowNodeId: GetRowNodeIdFunc = function (data) {
    return data.PaymentID;
  };
  ngOnChanges(changes: SimpleChanges) {
    // only run when property "data" changed

     this.getallRePayment();
  }
  postRePayment() {
    this.RePaymentModelobj.RentDateID = this.RentDateID;
    this.RePaymentModelobj.Date = this.formvalue.value.Date;
    this.RePaymentModelobj.TypePayed = this.formvalue.value.TypePayed;
    this.RePaymentModelobj.Value = this.formvalue.value.Value;
    this.RePaymentModelobj.CreatedBy = this.formvalue.value.CreatedBy;
    this.RePaymentModelobj.CreatedDate = this.formvalue.value.CreatedDate;
    this.RePaymentModelobj.Notes = this.formvalue.value.Notes;
 
    this.RePaymentModelobj.DateCollection = this.formvalue.value.DateCollection;
    this.RePaymentModelobj.BankName = this.formvalue.value.BankName;
    this.RePaymentModelobj.CheckNo = this.formvalue.value.CheckNo;
    this.RePaymentModelobj.Name = this.formvalue.value.Name;
    this.RePaymentModelobj.Status = this.formvalue.value.Status;
    this.RePaymentModelobj.RejectReason = this.formvalue.value.RejectReason;
    this.RePaymentModelobj.Notes_Check = this.formvalue.value.Notes;
 
    this.formvalue.controls['Notes'].setValue(JSON.stringify(this.RePaymentModelobj));
    this.apiServ.postRePayment(this.RePaymentModelobj).subscribe(e => {

      alert(this.translate.instant('SuccessMessage'))

      this.gridApi.applyTransaction({ add: [e[0]] });

      this.formvalue.reset();

    }, er => { alert(this.translate.instant('WrongMessage')); });
  }


  getallRePayment() {
    
    this.apiServ.getRePayment(this.RentDateID).subscribe(

      RePaymentdataRow => {
        if (RePaymentdataRow.length > 0) {
          this.OnEdit(RePaymentdataRow)
        }
      
      //  this.gridOptions.rowData = RePaymentdataRow;
      })
  }


  //switch between button add and edit
  switch_btn(Is_add: boolean) {
    if (Is_add) {
      this.Show_BtnInsert = true;
      this.show_btn_Edit = false;
    }
    else {

      this.Show_BtnInsert = false;
      this.show_btn_Edit = true;
    }

  }
  click_btnInsert() {
    this.switch_btn(true);
    // open pop modal
    ($('#exampleModal') as any).modal('show');
    this.formvalue.reset();
  }
  closeModule() {

    ($('#exampleModal') as any).modal('hide');
  }
  change_TypePayed(TypePayed:string) {
    if (TypePayed == '1') {
      $("#field_CheckPament").hide()
    }
    else if (TypePayed =='2') {
      $("#field_CheckPament").show()
    }
  }
  OnEdit(row: any) { 
    this.RePaymentModelobj.PaymentID = row[0].PaymentID;
    this.formvalue.controls['RentDateID'].setValue(row[0].RentDateID);
    this.formvalue.controls['Date'].setValue(row[0].Date);
    this.formvalue.controls['TypePayed'].setValue(row[0].TypePayed);
    this.formvalue.controls['Value'].setValue(row[0].Value); 
    this.formvalue.controls['Notes'].setValue(row[0].Notes);
    this.change_TypePayed(row[0].TypePayed);
    if (row[0].TypePayed == 2) {
      this.formvalue.controls['DateCollection'].setValue(row[0].RePaymentChecks[0].DateCollection);
      this.formvalue.controls['BankName'].setValue(row[0].RePaymentChecks[0].BankName);
      this.formvalue.controls['CheckNo'].setValue(row[0].RePaymentChecks[0].CheckNo);
      this.formvalue.controls['Name'].setValue(row[0].RePaymentChecks[0].Name);
      this.formvalue.controls['Status'].setValue(row[0].RePaymentChecks[0].Status);
      this.formvalue.controls['RejectReason'].setValue(row[0].RePaymentChecks[0].RejectReason);
      this.formvalue.controls['Notes'].setValue(row[0].RePaymentChecks[0].Notes);
    }
    // open pop modal
 
    // swtch buttons
    this.switch_btn(false);

  }
  updateRePayment() {
    this.RePaymentModelobj.RentDateID = this.formvalue.value.RentDateID;
    this.RePaymentModelobj.Date = this.formvalue.value.Date;
    this.RePaymentModelobj.TypePayed = this.formvalue.value.TypePayed;
    this.RePaymentModelobj.Value = this.formvalue.value.Value;
    this.RePaymentModelobj.CreatedBy = this.formvalue.value.CreatedBy;
    this.RePaymentModelobj.CreatedDate = this.formvalue.value.CreatedDate;
    this.RePaymentModelobj.Notes = this.formvalue.value.Notes;
  
    this.apiServ.updateRePayment(this.RePaymentModelobj, this.RePaymentModelobj.PaymentID).subscribe(res => {
      alert(this.translate.instant('UpdateMessage'));

      this.rowNode = this.gridApi.getRowNode(this.RePaymentModelobj.PaymentID)!;
      this.rowNode.setData(res[0]);
      // this.formvalue.reset();
    });
  }

  // for ag grid

  onGridReady(params: GridReadyEvent) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  }
  // create column of Ag grid
  private GetAgColumns(): ColDef[] {

    return [
      {
        headerName: this.translate.instant('btnlblEdit'),
        cellRendererFramework: ButtonEditRendererComponent,
        cellRendererParams: {
          onClick: this.onBtnEdit_Click.bind(this),
          pk_Name: 'PaymentID'
        }
      },
      {
        headerName: this.translate.instant('btnlblDelete'),
        cellRendererFramework: ButtonDeleteRendererComponent,
        cellRendererParams: {
          onClick: this.onBtnDelet_Click.bind(this),
          pk_Name: 'PaymentID'
        }
      },

    ];


  }
  // event for button in Ag Grid

  onBtnEdit_Click(e: { rowData: {}; }) {

    this.OnEdit(e.rowData);
  }
  onBtnDelet_Click(e: {
    event: Event,
    rowData: any, pk_value: number
  }) {
    // alert(JSON.stringify(e.rowData));
    // delete from dataBase 
    if (confirm(this.translate.instant('DeleteConfirm'))) {
      this.apiServ.deleteRePayment(e.pk_value).subscribe((res: any) => {
        alert(this.translate.instant('DeleteMessage'));
        let deletedRow = e.rowData;
        this.gridApi.updateRowData({ remove: [deletedRow] });
      });

    }
  }
}

