import { data } from "jquery";

export class RePaymentModel {
      PaymentID: number = 0;
  RentDateID: number = 0;
 Date :Date= new  Date();
 TypePayed: string = '';
 Value: string = '';
 CreatedBy: string = '';
 CreatedDate: string = '';
 Notes: string = '';

  PaymentcheckID: number = 0;
 
  DateCollection: string = '';
  BankName: string = '';
  CheckNo: string = '';
  Name: string = '';
  Status: string = '';
  RejectReason: string = '';
  Notes_Check: string = '';



}
