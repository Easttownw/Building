import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RebuildingAttachComponent } from './rebuilding-attach.component';

describe('RebuildingAttachComponent', () => {
  let component: RebuildingAttachComponent;
  let fixture: ComponentFixture<RebuildingAttachComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RebuildingAttachComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RebuildingAttachComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
