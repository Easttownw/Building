export class RebuildingAttachModel {
      BuildingAttachID: number = 0;

  BuildingID: number = 0;

 FileName: string = '';
 Path: string = '';


}
