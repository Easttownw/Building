export class GroupServiceModel {
      GroupServiceID: number = 0;
 GroupName_A: string = '';
 GroupName_E: string|null = '';
  GroupName_I: string = '';
  Photo: string = '';
 IS_Show: boolean = false;
  Notes_A: string | null = '';
  Notes_E: string | null = '';
  Notes_I: string | null = '';


}
