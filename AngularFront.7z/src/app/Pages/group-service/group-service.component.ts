import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms'
import { ApiService_GroupService } from '../../shared/GroupService.api.service'
import { Router } from '@angular/router'
import { GroupServiceModel } from './GroupService.model'; 
import { ButtonEditRendererComponent } from '../../renderer/buttonEdit-renderer.component';
import { ButtonDeleteRendererComponent } from '../../renderer/buttonDelete-renderer.component';
import { TranslateService } from '@ngx-translate/core';
import { GlobalConstants } from '../../common/global-constants';

import {
  GridOptions,
  ColDef,
  GridReadyEvent,
  ColumnApi,
  GridApi,
  GetRowNodeIdFunc
} from "ag-grid-community";

@Component({
  selector: 'app-group-service',
  templateUrl: './group-service.component.html',
  styleUrls: ['./group-service.component.css']
})
export class GroupServiceComponent implements OnInit {

  // model 
  GroupServiceModelobj:
    GroupServiceModel = new GroupServiceModel();
  formvalue!: FormGroup;
  GroupServicedataRow: any;

  newpath: string = ''
  imageSrc:string=''
  // button
  Show_BtnInsert!: boolean;
  show_btn_Edit!: boolean;
  // for grid ag
  gridOptions: GridOptions;
  ColumnDefs: any;
  RowData: any;
  gridApi: any
  gridColumnApi: any
  rowNode: any = [];
  constructor(public translate: TranslateService, private formbuilder: FormBuilder, private router: Router, private apiServ: ApiService_GroupService) {
    translate.addLangs(['en', 'ar']);
    translate.setDefaultLang(this.translate.instant(GlobalConstants.setDefaultLang));
    this.gridOptions = {
      columnDefs: this.GetAgColumns(),
      rowData: []
    };

  }

  ngOnInit(): void {

    this.switch_btn(true);
    this.formvalue = this.formbuilder.group({
      GroupName_A: [''], GroupName_E: [''], GroupName_I: [''], IS_Show: [''], Notes_A: [''], Notes_E: [''], Notes_I: ['']
    })
    //this.formvalue  = new FormGroup({
    //  name: new FormControl('', [Validators.required, Validators.minLength(3)]),
    //  email: new FormControl('', [Validators.required, Validators.email]),
    //  body: new FormControl('', Validators.required)
    //});
    // for validation
    this.formvalue = new FormGroup({
      GroupName_A: new FormControl(''), GroupName_E: new FormControl(''), GroupName_I: new FormControl(''), IS_Show: new FormControl(''),
      Notes_A: new FormControl(''), Notes_E: new FormControl(''), Notes_I: new FormControl(''), Photo: new FormControl(''),
    });

    //fill ag grid

    this.getallGroupService();
  }
  get f() {
    return this.formvalue.controls;
  }
  uploadFile(files: any) {

    // let fileToUpload = <File>files[0];
    const fileToUpload = files.target.files[0];
    const formData = new FormData();
    formData.append('file', fileToUpload, fileToUpload.name);
    
    this.apiServ.UploadPhoto(formData).subscribe(

      Row => {
        this.newpath = Row;

        this.imageSrc = GlobalConstants.apiURL + 'Photo/' + Row
        //this.gridOptions.rowData = MedHospitaldataRow;
      })
  }

  public getRowNodeId: GetRowNodeIdFunc = function (data) {
    return data.GroupServiceID;
  };

  postGroupService() {
    this.GroupServiceModelobj.GroupName_A = this.formvalue.value.GroupName_A;
    this.GroupServiceModelobj.GroupName_E = this.formvalue.value.GroupName_E;
    this.GroupServiceModelobj.GroupName_I = this.formvalue.value.GroupName_I;
    this.GroupServiceModelobj.IS_Show = $("#InputIS_Show").prop('checked');//this.formvalue.value.IS_Show;
    this.GroupServiceModelobj.Photo = this.newpath;
    this.GroupServiceModelobj.Notes_A = this.formvalue.value.Notes_A;
    this.GroupServiceModelobj.Notes_E = this.formvalue.value.Notes_E;
    this.GroupServiceModelobj.Notes_I = this.formvalue.value.Notes_I;
    console.log(JSON.stringify(this.GroupServiceModelobj))
    this.apiServ.postGroupService(this.GroupServiceModelobj).subscribe(e => {

      alert(this.translate.instant('SuccessMessage'))

      this.gridApi.applyTransaction({ add: [e[0]] });

      this.formvalue.reset();

    }, er => { alert(this.translate.instant('WrongMessage')); });
  }


  getallGroupService() {
    this.apiServ.getGroupService().subscribe(

      GroupServicedataRow => {
  
        this.gridOptions.rowData = GroupServicedataRow;
      })
  }


  //switch between button add and edit
  switch_btn(Is_add: boolean) {
    if (Is_add) {
      this.Show_BtnInsert = true;
      this.show_btn_Edit = false;
    }
    else {

      this.Show_BtnInsert = false;
      this.show_btn_Edit = true;
    }

  }
  click_btnInsert() {
    this.switch_btn(true);
    // open pop modal
    ($('#exampleModal') as any).modal('show');
    this.formvalue.reset();
  }
  closeModule() {

    ($('#exampleModal') as any).modal('hide');
  }
  OnEdit(row: any) {

    this.GroupServiceModelobj.GroupServiceID = row.GroupServiceID;
    this.formvalue.controls['GroupName_A'].setValue(row.GroupName_A);
    this.formvalue.controls['GroupName_E'].setValue(row.GroupName_E);
    this.formvalue.controls['GroupName_I'].setValue(row.GroupName_I);
    this.imageSrc = GlobalConstants.apiURL + "Photo/" + row.Photo
    this.newpath = row.Photo;
    this.formvalue.controls['IS_Show'].setValue(row.IS_Show);
    this.formvalue.controls['Notes_A'].setValue(row.Notes_A);
    this.formvalue.controls['Notes_E'].setValue(row.Notes_E);
    this.formvalue.controls['Notes_I'].setValue(row.Notes_I);

    
    // open pop modal
    ($('#exampleModal') as any).modal('show');
    // swtch buttons
    this.switch_btn(false);

  }
  updateGroupService() { 
    //this.GroupServiceModelobj.GroupServiceID = this.GroupServiceModelobj.GroupServiceID
    //this.GroupServiceModelobj.GroupServiceID = this.formvalue.value.GroupName_A;
    this.GroupServiceModelobj.GroupName_A = this.formvalue.value.GroupName_A;
    this.GroupServiceModelobj.GroupName_E = this.formvalue.value.GroupName_E;
    this.GroupServiceModelobj.GroupName_I = this.formvalue.value.GroupName_I;
    this.GroupServiceModelobj.Photo = this.newpath;
    this.GroupServiceModelobj.IS_Show = $("#InputIS_Show").prop('checked');//this.formvalue.value.IS_Show;
    this.GroupServiceModelobj.Notes_A = this.formvalue.value.Notes_A;
    this.GroupServiceModelobj.Notes_E = this.formvalue.value.Notes_E;
    this.GroupServiceModelobj.Notes_I = this.formvalue.value.Notes_I;
    console.log(JSON.stringify(this.GroupServiceModelobj))
    this.apiServ.updateGroupService(this.GroupServiceModelobj, this.GroupServiceModelobj.GroupServiceID).subscribe(res => {
      alert(this.translate.instant('UpdateMessage'));

      this.rowNode = this.gridApi.getRowNode(this.GroupServiceModelobj.GroupServiceID)!;
      this.rowNode.setData(res[0]);
      // this.formvalue.reset();
    });
  }

  // for ag grid

  onGridReady(params: GridReadyEvent) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  }
  // create column of Ag grid
  private GetAgColumns(): ColDef[] {

    return [
      {
        headerName: this.translate.instant('BtnEdit'),
        cellRendererFramework: ButtonEditRendererComponent,
        cellRendererParams: {
          onClick: this.onBtnEdit_Click.bind(this),
          pk_Name: 'GroupServiceID'
        }
      },
      {
        headerName: this.translate.instant('btnlblDelete'),
        cellRendererFramework: ButtonDeleteRendererComponent,
        cellRendererParams: {
          onClick: this.onBtnDelet_Click.bind(this),
          pk_Name: 'GroupServiceID'
        }
      },
      { headerName: this.translate.instant('GroupName_A'), field: 'GroupName_A', sortable: true, filter: true },
    ];


  }
  // event for button in Ag Grid

  onBtnEdit_Click(e: { rowData: {}; }) {

    this.OnEdit(e.rowData);
  }
  onBtnDelet_Click(e: {
    event: Event,
    rowData: any, pk_value: number
  }) {
    // alert(JSON.stringify(e.rowData));
    // delete from dataBase 
    if (confirm(this.translate.instant('DeleteConfirm'))) {
      this.apiServ.deleteGroupService(e.pk_value).subscribe((res: any) => {
        alert(this.translate.instant('DeleteMessage'));
        let deletedRow = e.rowData;
        this.gridApi.updateRowData({ remove: [deletedRow] });
      });

    }
  }
}

