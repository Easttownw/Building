export class ReOwnerModel {
      OwnerID: number = 0;
 OwnerName: string = '';
 IDNumber: string = '';
 Mobile: string = '';
 Tel: string = '';
 Notes: string = '';
 CreatedBy: string = '1';
 CreateDate:  Date = new Date;


}
