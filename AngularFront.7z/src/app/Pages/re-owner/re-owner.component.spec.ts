import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReOwnerComponent } from './re-owner.component';

describe('ReOwnerComponent', () => {
  let component: ReOwnerComponent;
  let fixture: ComponentFixture<ReOwnerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReOwnerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReOwnerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
