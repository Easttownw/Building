import { Component, OnInit, Inject, ViewChild, Input, SimpleChanges, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms'
import { ApiService_ReOwner } from '../../shared/ReOwner.api.service'
import { Router } from '@angular/router'
import { ReOwnerModel } from './ReOwner.model';
import { HttpClient } from '@angular/common/http'
import { ButtonEditRendererComponent } from '../../renderer/buttonEdit-renderer.component';
import { ButtonDeleteRendererComponent } from '../../renderer/buttonDelete-renderer.component';
import { TranslateService } from '@ngx-translate/core';
import { GlobalConstants } from '../../common/global-constants';

import {
  GridOptions,
  ColDef,
  GridReadyEvent,
  ColumnApi,
  GridApi,
  GetRowNodeIdFunc
} from "ag-grid-community";

@Component({
  selector: 'app-re-owner',
  templateUrl: './re-owner.component.html',
  styleUrls: ['./re-owner.component.css']
})
export class ReOwnerComponent implements OnInit {

  // model 
  ReOwnerModelobj:
    ReOwnerModel = new ReOwnerModel();
  formvalue!: FormGroup;
  ReOwnerdataRow: any;
  // from parent
  @Input() BuildingID: number = 0;


  // event for button in Ag Grid
  @Output() EventFromChilde: EventEmitter<string> = new EventEmitter<string>();
  // button
  Show_BtnInsert!: boolean;
  show_btn_Edit!: boolean;
  // for grid ag
  gridOptions: GridOptions;
  ColumnDefs: any;
  RowData: any;
  gridApi: any
  gridColumnApi: any
  rowNode: any = [];
  constructor(public translate: TranslateService, private formbuilder: FormBuilder, private router: Router, private apiServ: ApiService_ReOwner) {
    translate.addLangs(['en', 'ar']);
    translate.setDefaultLang(this.translate.instant(GlobalConstants.setDefaultLang));
    this.gridOptions = {
      columnDefs: this.GetAgColumns(),
      rowData: []
    };

  }

  ngOnInit(): void {
     
    this.formvalue = this.formbuilder.group({
      OwnerName: ['', Validators.required], IDNumber: ['', Validators.required], Mobile: [''], Tel: [''], Notes: [''] 
    })
    //this.formvalue  = new FormGroup({
    //  name: new FormControl('', [Validators.required, Validators.minLength(3)]),
    //  email: new FormControl('', [Validators.required, Validators.email]),
    //  body: new FormControl('', Validators.required)
    //});
    // for validation
    this.formvalue = new FormGroup({
      OwnerName: new FormControl(''), IDNumber: new FormControl(''), Mobile: new FormControl(''), Tel: new FormControl(''), Notes: new FormControl(''),  
    });
    // get detail owner
    this.getOwnerByBuilding()
    //fill ag grid
   
   // this.getallReOwner();
  }
  ngOnChanges(changes: SimpleChanges) {

    this.getOwnerByBuilding()
    //console.log(changes)
  }
  get f() {
    return this.formvalue.controls;
  }
  public getRowNodeId: GetRowNodeIdFunc = function (data) {
    return data.OwnerID;
  };
  
  postReOwner() {
    this.ReOwnerModelobj.OwnerName = this.formvalue.value.OwnerName;
    this.ReOwnerModelobj.IDNumber = this.formvalue.value.IDNumber;
    this.ReOwnerModelobj.Mobile = this.formvalue.value.Mobile;
    this.ReOwnerModelobj.Tel = this.formvalue.value.Tel;
    this.ReOwnerModelobj.Notes = this.formvalue.value.Notes;
    console.log(JSON.stringify(this.ReOwnerModelobj))
    this.apiServ.postReOwner(this.ReOwnerModelobj).subscribe(e => {

      alert(this.translate.instant('SuccessMessage'))

      this.gridApi.applyTransaction({ add: [e[0]] });

      this.EventFromChilde.emit(e[0].OwnerID);
     // this.formvalue.reset();
      this.formvalue.controls['OwnerName'].setValue(e[0].OwnerName);
      this.formvalue.controls['IDNumber'].setValue(e[0].IDNumber);
      this.formvalue.controls['Mobile'].setValue(e[0].Mobile);
      this.formvalue.controls['Tel'].setValue(e[0].Tel);
      this.formvalue.controls['Notes'].setValue(e[0].Notes); 
    }, er => { alert(this.translate.instant('WrongMessage')); });
  }


  getallReOwner() {
    this.apiServ.getReOwner().subscribe(

      ReOwnerdataRow => {
        this.gridOptions.rowData = ReOwnerdataRow;
      })
  };
  getOwnerByBuilding() {
 
    if (this.BuildingID != 0) {
      
      this.apiServ.getOwnerByBuilding(this.BuildingID).subscribe(

        ReOwnerdataRow => { 
          //view detail of owner
          if (ReOwnerdataRow != 0) {
            this.OnEdit(ReOwnerdataRow);
          }
          else {
           
            this.switch_btn(true)
          }
        })
    }
};

  //switch between button add and edit
  switch_btn(Is_add: boolean) {
    if (Is_add) {
      this.Show_BtnInsert = true;
      this.show_btn_Edit = false;
    }
    else {

      this.Show_BtnInsert = false;
      this.show_btn_Edit = true;
    }

  }
  click_btnInsert() {
    this.switch_btn(true);
    // open pop modal
  //  ($('#exampleModal') as any).modal('show');
    this.formvalue.reset();
  }
  closeModule() {

    ($('#exampleModal') as any).modal('hide');
  }
  OnEdit(row: any) {
  
    this.ReOwnerModelobj.OwnerID = row[0].OwnerID;
 
    this.formvalue.controls['OwnerName'].setValue(row[0].OwnerName);
    this.formvalue.controls['IDNumber'].setValue(row[0].IDNumber);
    this.formvalue.controls['Mobile'].setValue(row[0].Mobile);
    this.formvalue.controls['Tel'].setValue(row[0].Tel);
    this.formvalue.controls['Notes'].setValue(row[0].Notes); 


    // open pop modal
    ($('#exampleModal') as any).modal('show');
    // swtch buttons
    this.switch_btn(false);

  }
  updateReOwner() {
    this.ReOwnerModelobj.OwnerName = this.formvalue.value.OwnerName;
    this.ReOwnerModelobj.IDNumber = this.formvalue.value.IDNumber;
    this.ReOwnerModelobj.Mobile = this.formvalue.value.Mobile;
    this.ReOwnerModelobj.Tel = this.formvalue.value.Tel;
    this.ReOwnerModelobj.Notes = this.formvalue.value.Notes;
    this.ReOwnerModelobj.CreatedBy = '1';
    this.ReOwnerModelobj.CreateDate = this.formvalue.value.CreateDate;
    this.apiServ.updateReOwner(this.ReOwnerModelobj, this.ReOwnerModelobj.OwnerID).subscribe(res => {
      alert(this.translate.instant('UpdateMessage'));

      //this.rowNode = this.gridApi.getRowNode(this.ReOwnerModelobj.OwnerID)!;
      //this.rowNode.setData(res[0]);
      // this.formvalue.reset();
    });
  }

  // for ag grid

  onGridReady(params: GridReadyEvent) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  }
  // create column of Ag grid
  private GetAgColumns(): ColDef[] {

    return [
      {
        headerName: this.translate.instant('btnlblEdit'),
        cellRendererFramework: ButtonEditRendererComponent,
        cellRendererParams: {
          onClick: this.onBtnEdit_Click.bind(this),
          pk_Name: 'OwnerID'
        }
      },
      {
        headerName: this.translate.instant('btnlblDelete'),
        cellRendererFramework: ButtonDeleteRendererComponent,
        cellRendererParams: {
          onClick: this.onBtnDelet_Click.bind(this),
          pk_Name: 'OwnerID'
        }
      },

    ];


  }
  // event for button in Ag Grid

  onBtnEdit_Click(e: { rowData: {}; }) {

    this.OnEdit(e.rowData);
  }
  onBtnDelet_Click(e: {
    event: Event,
    rowData: any, pk_value: number
  }) {
    // alert(JSON.stringify(e.rowData));
    // delete from dataBase 
    if (confirm(this.translate.instant('DeleteConfirm'))) {
      this.apiServ.deleteReOwner(e.pk_value).subscribe((res: any) => {
        alert(this.translate.instant('DeleteMessage'));
        let deletedRow = e.rowData;
        this.gridApi.updateRowData({ remove: [deletedRow] });
      });

    }
  }
}

