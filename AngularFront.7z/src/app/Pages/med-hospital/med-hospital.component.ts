import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms'
import { ApiService_MedHospital } from '../../shared/MedHospital.api.service'
import { Router } from '@angular/router'
import { MedHospitalModel, PictureModel } from './MedHospital.model';
import { ButtonEditRendererComponent } from '../../renderer/buttonEdit-renderer.component';
import { ButtonDeleteRendererComponent } from '../../renderer/buttonDelete-renderer.component';
import { TranslateService } from '@ngx-translate/core';
import { GlobalConstants } from '../../common/global-constants';

import { HttpClient, HttpClientModule, HttpErrorResponse, HttpEventType, HttpHeaders } from '@angular/common/http'
import { map } from 'rxjs/operators'
import {
  GridOptions,
  ColDef,
  GridReadyEvent,
  ColumnApi,
    GridApi,
    GetRowNodeIdFunc
} from "ag-grid-community";
import { Reference } from '@angular/compiler/src/render3/r3_ast';

@Component({
  selector: 'app-med-hospital',
  templateUrl: './med-hospital.component.html',
  styleUrls: ['./med-hospital.component.css']
})
export class MedHospitalComponent implements OnInit {

  // model 
      MedHospitalModelobj:
MedHospitalModel = new MedHospitalModel(); 
  formvalue!: FormGroup;
  MedHospitaldataRow: any;

  // button
  Show_BtnInsert!: boolean;
  show_btn_Edit!: boolean;
  // for grid ag
  gridOptions: GridOptions; 
  ColumnDefs: any;
  RowData: any;
  gridApi: any
    gridColumnApi: any
    rowNode: any = [];
  constructor(public translate: TranslateService, private formbuilder: FormBuilder,
    private router: Router, private apiServ: ApiService_MedHospital,private http: HttpClient) {
        translate.addLangs(['en', 'ar']);
        translate.setDefaultLang(this.translate.instant(GlobalConstants.setDefaultLang));
    this.gridOptions = {
      columnDefs: this.GetAgColumns(),
      rowData: [] 
    };

  }

    ngOnInit(): void {

        this.switch_btn(true);
     this.formvalue = this.formbuilder.group({
          HospitalName_A: [''], HospitalName_E: [''], HospitalName_I: [''], Address: [''], Photo: [''], Tel: [''], Mobile: ['']
     })
    //this.formvalue  = new FormGroup({
    //  name: new FormControl('', [Validators.required, Validators.minLength(3)]),
    //  email: new FormControl('', [Validators.required, Validators.email]),
    //  body: new FormControl('', Validators.required)
    //});
    // for validation
    this.formvalue = new FormGroup({
      HospitalName_A: new FormControl(''), HospitalName_E: new FormControl(''), HospitalName_I: new FormControl(''),
      Address: new FormControl(''), Photo: new FormControl(''), Tel: new FormControl(''), Mobile: new FormControl(''),
    });
   
    //fill ag grid

      this.getallMedHospital();
  }
  get f() {
    return this.formvalue.controls;
    }
    public getRowNodeId: GetRowNodeIdFunc = function (data) {
        return data.HospitalID;
    };

    postMedHospital() { 
  this.MedHospitalModelobj.HospitalName_A = this.formvalue.value.HospitalName_A;
  this.MedHospitalModelobj.HospitalName_E = this.formvalue.value.HospitalName_E;
  this.MedHospitalModelobj.HospitalName_I = this.formvalue.value.HospitalName_I;
  this.MedHospitalModelobj.Address = this.formvalue.value.Address;
      this.MedHospitalModelobj.Photo = this.newpath;// this.formvalue.value.Photo;
  this.MedHospitalModelobj.Tel = this.formvalue.value.Tel;
  this.MedHospitalModelobj.Mobile = this.formvalue.value.Mobile;
 this.apiServ.postMedHospital(this.MedHospitalModelobj).subscribe(e => {
      
      alert(this.translate.instant('SuccessMessage')) 
 
      this.gridApi.applyTransaction({ add:  [e[0]] }); 
      
        this.formvalue.reset();

    }, er => { alert(this.translate.instant('WrongMessage')); });
  }


    getallMedHospital() {
    this.apiServ.getMedHospital().subscribe(

      MedHospitaldataRow => { 
        this.gridOptions.rowData = MedHospitaldataRow;
      }) 
  }


    //switch between button add and edit
    switch_btn(Is_add: boolean) {
        if (Is_add) {
            this.Show_BtnInsert = true;
            this.show_btn_Edit = false;
        }
        else {

            this.Show_BtnInsert = false;
            this.show_btn_Edit = true;
        }

    }
  click_btnInsert() {
    this.switch_btn(true);
        // open pop modal
        ($('#exampleModal') as any).modal('show');
      this.formvalue.reset();
    }
    closeModule() {

        ($('#exampleModal') as any).modal('hide');
    }
  OnEdit(row: any) {
 
      this.MedHospitalModelobj.HospitalID = row.HospitalID;
this.formvalue.controls['HospitalName_A'].setValue(row.HospitalName_A);
this.formvalue.controls['HospitalName_E'].setValue(row.HospitalName_E);
this.formvalue.controls['HospitalName_I'].setValue(row.HospitalName_I);
this.formvalue.controls['Address'].setValue(row.Address);
//this.formvalue.controls['Photo'].setValue(row.Photo);
    this.imageSrc = GlobalConstants.apiURL + "Photo/" + row.Photo
    this.newpath = row.Photo;
this.formvalue.controls['Tel'].setValue(row.Tel);
this.formvalue.controls['Mobile'].setValue(row.Mobile);


          // open pop modal
          ($('#exampleModal') as any).modal('show');
      // swtch buttons
      this.switch_btn(false);

  }
    updateMedHospital() {
this.MedHospitalModelobj.HospitalName_A = this.formvalue.value.HospitalName_A;
this.MedHospitalModelobj.HospitalName_E = this.formvalue.value.HospitalName_E;
this.MedHospitalModelobj.HospitalName_I = this.formvalue.value.HospitalName_I;
this.MedHospitalModelobj.Address = this.formvalue.value.Address;
      this.MedHospitalModelobj.Photo = this.newpath;// this.formvalue.value.Photo;
this.MedHospitalModelobj.Tel = this.formvalue.value.Tel;
this.MedHospitalModelobj.Mobile = this.formvalue.value.Mobile;
this.apiServ.updateMedHospital(this.MedHospitalModelobj, this.MedHospitalModelobj.HospitalID).subscribe(res => {
        alert(this.translate.instant('UpdateMessage'));

            this.rowNode = this.gridApi.getRowNode(this.MedHospitalModelobj.HospitalID)!;    
      this.rowNode.setData(res[0]);
     // this.formvalue.reset();
    });
    }

  newpath: string = '';
  imageSrc: string = '';

  onFileChange(event: any) {
    const reader = new FileReader();

    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      
      this.apiServ.uploadPhoto(file).subscribe(e => {
        this.newpath = e;
         alert(e);
        //alert(this.translate.instant('SuccessMessage'))
        reader.readAsDataURL(file);

        reader.onload = () => {
          //alert(reader.result)
          this.imageSrc =  reader.result as string;

          this.formvalue.patchValue({
            fileSource: reader.result
          });

        };


      }, er => { alert(JSON.stringify(er)); });

    }
    
  }
   
  uploadFile(files: any) {

    // let fileToUpload = <File>files[0];
    const fileToUpload = files.target.files[0];
    const formData = new FormData();
    formData.append('file', fileToUpload, fileToUpload.name);
   // alert('ffffffffff')
    this.apiServ.exce(formData).subscribe(

      Row => {
        this.newpath = Row;
       
        this.imageSrc = GlobalConstants.apiURL + 'Photo/' + Row
        //this.gridOptions.rowData = MedHospitaldataRow;
      }) 
  }
  // for ag grid
  
  onGridReady(params: GridReadyEvent) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    }
    // create column of Ag grid
  private GetAgColumns(): ColDef[] {

    return [
        {
        headerName: this.translate.instant('BtnEdit'),
        cellRendererFramework: ButtonEditRendererComponent,
        cellRendererParams: {
          onClick: this.onBtnEdit_Click.bind(this),
          pk_Name: 'HospitalID'
       }
      },
{
        headerName: this.translate.instant('btnlblDelete'),
        cellRendererFramework: ButtonDeleteRendererComponent,
        cellRendererParams: {
          onClick: this.onBtnDelet_Click.bind(this),
          pk_Name: 'HospitalID'
        }
      }
      ,
      { headerName: this.translate.instant('HospitalName_A'), field: 'HospitalName_A', sortable: true, filter: true }
    ];
  

  }
  // event for button in Ag Grid

  onBtnEdit_Click(e: { rowData: {}; }) {
   
    this.OnEdit(e.rowData); 
  }
  onBtnDelet_Click(e: {
    event: Event,
    rowData: any, pk_value:number
  })
  {
   // alert(JSON.stringify(e.rowData));
    // delete from dataBase 
      if (confirm(this.translate.instant('DeleteConfirm'))) {
        this.apiServ.deleteMedHospital(e.pk_value).subscribe((res: any) => {
            alert(this.translate.instant('DeleteMessage'));  
            let deletedRow = e.rowData;
        this.gridApi.updateRowData({ remove: [deletedRow] }) ; });
       
    }
  }
}
 
