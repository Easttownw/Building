import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MedHospitalComponent } from './med-hospital.component';

describe('MedHospitalComponent', () => {
  let component: MedHospitalComponent;
  let fixture: ComponentFixture<MedHospitalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MedHospitalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MedHospitalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
