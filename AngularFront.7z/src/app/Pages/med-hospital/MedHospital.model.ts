export class MedHospitalModel {
      HospitalID: number = 0;
 HospitalName_A: string = '';
 HospitalName_E: string = '';
 HospitalName_I: string = '';
 Address: string = '';
 Photo: string = '';
 Tel: string = '';
 Mobile: string = '';


}
export class PictureModel {
  picture: FormData|null=null
}
