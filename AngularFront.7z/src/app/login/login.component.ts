import { Component, NgZone, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms'
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService_User } from '../shared/User.api.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  // model 
  LogUser_Modelobj:
    LogUser = new LogUser(); 
  formvalue!: FormGroup;
  constructor(private apiServ: ApiService_User, private router: Router,private route: ActivatedRoute, private zone: NgZone) { }

  ngOnInit(): void {
    this.formvalue = new FormGroup({
      userName: new FormControl(), Password: new FormControl(), lang: new FormControl(),
    });

  }
  AllowLogingUser() {
   // alert(this.formvalue.value.Password);
    this.LogUser_Modelobj.Name = this.formvalue.value.userName;

    this.LogUser_Modelobj.Password = this.formvalue.value.Password;

    this.LogUser_Modelobj.lang = this.formvalue.value.lang;

    this.apiServ.AccessUser(this.LogUser_Modelobj).subscribe(e => {
      //alert(JSON.stringify(e));
      //alert(e[0].UserID);
      
      if(e==0) { alert('wrong user or password'); }
      else {
        
        localStorage.setItem('UserID', e[0].UserID);

        localStorage.setItem('AccessType', e[0].AccessType);

        localStorage.setItem('Name', e[0].Name);
       // alert('SuccessMessage')
        //alert(localStorage.getItem('Name'));
        this.zone.run(() => {
          this.router.navigate(['/PlanStudy/'] );
          // { queryParams: { order: 'popular', 'price-range': 'not-cheap' } });
        });
      }
 

    }, er => { alert('wrong user or password'); });

  }
}

export class LogUser {
  Name: string = '';
  Password: string = '';
  lang: string = '';


}
