export class OccuAssessmentsModel {
  AssesmentID: number = 0; 
 StudentID: number = 0;
 Date: Date= new Date() ;
 Notes: string = '';
 IS_FirstAssement: boolean = false;
 SessionID: string = '1';
 CreateBy: string = '';
 CreateDate: string = '';
 Action: string = '';
 AssementFirstID: boolean = false;
 QualityDelivery: string = '';
 AnyOtherDiseases: string = '';
 Edema: string = '';
 TherapistSessionsPtOt: string = '';
 beginSymptoms: string = '';
 PainDuringRest: string = '';
 Drugs: string = '';
 Period: string = '';
 NotesFirstAssement: string = '';


}
export class AssesmentEvaluation {
  RomAssementID:number=0;

  Evaluation:string = '';
}
