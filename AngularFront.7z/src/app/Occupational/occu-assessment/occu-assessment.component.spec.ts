import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OccuAssessmentComponent } from './occu-assessment.component';

describe('OccuAssessmentComponent', () => {
  let component: OccuAssessmentComponent;
  let fixture: ComponentFixture<OccuAssessmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OccuAssessmentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OccuAssessmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
