import { Component, OnInit, Inject, ViewChild, ViewContainerRef } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators, FormsModule } from '@angular/forms'
import { ApiService_OccuAssessments } from '../../shared/OccuAssessments.api.service'
import { Router } from '@angular/router'
import { AssesmentEvaluation, OccuAssessmentsModel } from './OccuAssessments.model';
import { HttpClient } from '@angular/common/http'
import { ButtonEditRendererComponent } from '../../renderer/buttonEdit-renderer.component';
import { ButtonDeleteRendererComponent } from '../../renderer/buttonDelete-renderer.component';
import { TranslateService } from '@ngx-translate/core';
import { GlobalConstants } from '../../common/global-constants';  
import { TabsetComponent, TabDirective } from 'ngx-bootstrap/tabs';

import {
  GridOptions,
  ColDef,
  GridReadyEvent,
  ColumnApi,
  GridApi
} from "ag-grid-community";
import { jsDocComment } from '@angular/compiler';
import { Content } from '@angular/compiler/src/render3/r3_ast';

@Component({
  selector: 'app-occu-assessment',
  templateUrl: './occu-assessment.component.html',
  styleUrls: ['./occu-assessment.component.css']
})
export class OccuAssessmentComponent implements OnInit {
 
  // model 
  OccuAssessmentsModelobj:
    OccuAssessmentsModel = new OccuAssessmentsModel();

  AssesmentEvaluationModel_Obj :AssesmentEvaluation = new AssesmentEvaluation();
  formvalue!: FormGroup;
  OccuAssessmentsdataRow: any;

  // button
  Show_BtnInsert!: boolean;
  show_btn_Edit!: boolean;
  // for grid ag
  gridOptions: GridOptions;
  ColumnDefs: any;
  RowData: any;
  gridApi: any
  gridColumnApi: any
  AssesmentID: number = 0;

  studentIDfrmChild: number = 0;
  // Rom List
  ROM_List: any = []; 
   


  EvaluationList: any = [];
  ReEvaluationList: any = [];

  constructor(public translate: TranslateService, private formbuilder: FormBuilder, private router: Router, private apiServ: ApiService_OccuAssessments, private http: HttpClient) {
    translate.addLangs(['en', 'ar']);
    translate.setDefaultLang(this.translate.instant(GlobalConstants.setDefaultLang));
    this.gridOptions = {
      columnDefs: this.GetAgColumns(),
      rowData: []
    };

  }
 // get the studentID from parent AG Grid
  ReceiveStudentID($event: string) {
    ($('#exampleModal') as any).modal('show');
    // assign studentID from Childe control to this variable
    this.studentIDfrmChild =Number( $event);

   // localStorage.setItem("user_id", "1");
    //return !!localStorage.getItem('user_id');

    //fill ag grid

    this.getallOccuAssessments();
    //fill ROM
    this.tadIndex = 0;
    this.Rom_Shoulder.active = true;
    this.Fill_ROM_Grid(31);

    this.Switch_DIV(false);

  }
  //ROM tabs
  @ViewChild('tabset') tabset: TabsetComponent | any;
  @ViewChild('Rom_Shoulder') Rom_Shoulder: TabDirective | any;
  @ViewChild('Rom_Elbow') Rom_Elbow: TabDirective | any;
  @ViewChild('Rom_Wrist') Rom_Wrist: TabDirective | any;
  @ViewChild('Rom_Fingers') Rom_Fingers: TabDirective | any;

  @ViewChild('Rom_Thumb') Rom_Thumb: TabDirective | any;

  tadIndex: number = 100;
  SelectTab_ROM($event: any ) {
   // alert(JSON.stringify(index));

    //const activeTab = this.tabset.tabs.filter((tab: { active: any; }) => tab.active);
    //alert(activeTab[0].active);

    if (this.Rom_Shoulder.active && this.tadIndex != 0) {
      this.tadIndex = 0
      this.Fill_ROM_MMt_Grid(31);
    }
    else if (this.Rom_Elbow.active && this.tadIndex != 1) {

      this.Fill_ROM_MMt_Grid(32);
      this.tadIndex = 1;
    }
    else if (this.Rom_Wrist.active && this.tadIndex != 2) {

      this.Fill_ROM_MMt_Grid(33);
      this.tadIndex = 2;
    }
    else if (this.Rom_Fingers.active && this.tadIndex != 3) {

      this.Fill_ROM_MMt_Grid(34);
      this.tadIndex = 3;
    }
    else if (this.Rom_Thumb.active && this.tadIndex != 4) {

      this.Fill_ROM_MMt_Grid(35);
      this.tadIndex = 4;
    }
    //else if (this.Rom_Wrist.active)
    //  this.Fill_ROM_Grid(33);

    //else if (this.Rom_Fingers.active)
    //  this.Fill_ROM_Grid(34);

    //else if (this.Rom_Thumb.active)
    //  this.Fill_ROM_Grid(35);
  }
  // end tas ROM
  // Tab MMT

  @ViewChild('MMT_Shoulder') MMT_Shoulder: TabDirective | any;
  @ViewChild('MMT_Elbow') MMT_Elbow: TabDirective | any;
  @ViewChild('MMT_Wrist') MMT_Wrist: TabDirective | any;
  @ViewChild('MMT_Fingers') MMT_Fingers: TabDirective | any;

  @ViewChild('MMT_Thumb') MMT_Thumb: TabDirective | any;
 
  SelectTab_MMT($event: any) {
    if (this.MMT_Shoulder.active)
      this.Fill_ROM_MMt_Grid(38);

    else if (this.MMT_Elbow.active)
      this.Fill_ROM_MMt_Grid(39);

    else if (this.MMT_Wrist.active)
      this.Fill_ROM_MMt_Grid(40);

    else if (this.MMT_Fingers.active)
      this.Fill_ROM_MMt_Grid(41);

    else if (this.MMT_Thumb.active)
      this.Fill_ROM_MMt_Grid(42);
  }
  //end tab MMT
  // Basic Tab
  @ViewChild('Fine_motorskills') Fine_motorskills: TabDirective | any;

  @ViewChild('ADL') ADL: TabDirective | any;

  @ViewChild('Pre_Writing_Skill') Pre_Writing_Skill: TabDirective | any;

  @ViewChild('Motor_Items') Motor_Items: TabDirective | any;

  @ViewChild('Sensory_integration') Sensory_integration: TabDirective | any;

  @ViewChild('Comun_psychosocial') Comun_psychosocial: TabDirective | any;

  TabBasic_index: number = 70;
  Select_BasicTab($event: any) {

    if (this.Fine_motorskills.active && this.TabBasic_index != 0) {
      this.TabBasic_index = 0;
      this.Fill_ROM_Grid(43);
      this.Fill_DDlist_Evaluations();
    }
    else if (this.ADL.active && this.TabBasic_index != 1) {
      this.TabBasic_index = 1;
      this.Fill_ROM_Grid(44);
      this.Fill_DDlist_Evaluations();
    }
    else if (this.Pre_Writing_Skill && this.TabBasic_index != 2) {
      this.TabBasic_index = 2;
      this.Fill_ROM_Grid(45);
      this.Fill_DDlist_Evaluations();
    }
    else if (this.Motor_Items && this.TabBasic_index != 3) {
      this.TabBasic_index = 3;
      this.Fill_ROM_Grid(46);
      this.Fill_DDlist_Evaluations();
    }
    else if (this.Sensory_integration && this.TabBasic_index != 4) {
      this.TabBasic_index = 4;
      this.Fill_ROM_Grid(47);
      this.Fill_DDlist_Evaluations();
    }
    else if (this.Comun_psychosocial && this.TabBasic_index != 5) {
      this.TabBasic_index = 5;
      this.Fill_ROM_Grid(48);
      this.Fill_DDlist_Evaluations();
    }
  }

  ngOnInit(): void { 
    this.selectedLevel = '4';
    this.switch_btn(true);
    this.formvalue = this.formbuilder.group({
      AssesmentID: [''],   StudentID: [''], Date: [''], Notes: [''], IS_FirstAssement: [''], SessionID: [''], CreateBy: [''], CreateDate: [''], Action: [''], AssementFirstID: [''], QualityDelivery: [''], AnyOtherDiseases: [''], Edema: [''], TherapistSessionsPtOt: [''], beginSymptoms: [''], PainDuringRest: [''], Drugs: [''], Period: [''],
      NotesFirstAssement: ['']
    })
    //this.formvalue  = new FormGroup({
    //  name: new FormControl('', [Validators.required, Validators.minLength(3)]),
    //  email: new FormControl('', [Validators.required, Validators.email]),
    //  body: new FormControl('', Validators.required)
    //});
    // for validation
    this.formvalue = new FormGroup({
      AssesmentID: new FormControl(''),  StudentID: new FormControl(''), Date: new FormControl(''), Notes: new FormControl(''), IS_FirstAssement: new FormControl(''), SessionID: new FormControl(''), CreateBy: new FormControl(''), CreateDate: new FormControl(''), Action: new FormControl(''), AssementFirstID: new FormControl(''), QualityDelivery: new FormControl(''), AnyOtherDiseases: new FormControl(''), Edema: new FormControl(''), TherapistSessionsPtOt: new FormControl(''), beginSymptoms: new FormControl(''), PainDuringRest: new FormControl(''), Drugs: new FormControl(''), Period: new FormControl(''), NotesFirstAssement: new FormControl(''),
    });

  }
  get f() {
    return this.formvalue.controls;
  }
  postOccuAssessments() {

    localStorage.setItem('langid','1'); 
    this.OccuAssessmentsModelobj.StudentID = this.studentIDfrmChild;
    this.OccuAssessmentsModelobj.Date = this.formvalue.value.Date;
    this.OccuAssessmentsModelobj.Notes = this.formvalue.value.Notes;
    this.OccuAssessmentsModelobj.IS_FirstAssement = this.formvalue.value.IS_FirstAssement;
    this.OccuAssessmentsModelobj.SessionID =String( localStorage.getItem('langid'));// this.formvalue.value.SessionID;
    this.OccuAssessmentsModelobj.CreateBy ='1';// this.formvalue.value.CreateBy;
    this.OccuAssessmentsModelobj.CreateDate ='12/12/2021'  ;// this.formvalue.value.CreateDate;
    this.OccuAssessmentsModelobj.Action = '1';//this.formvalue.value.Action;
    this.OccuAssessmentsModelobj.AssementFirstID = this.formvalue.value.AssementFirstID;
    this.OccuAssessmentsModelobj.QualityDelivery = this.formvalue.value.QualityDelivery;
    this.OccuAssessmentsModelobj.AnyOtherDiseases = this.formvalue.value.AnyOtherDiseases;
    this.OccuAssessmentsModelobj.Edema = this.formvalue.value.Edema;
    this.OccuAssessmentsModelobj.TherapistSessionsPtOt = this.formvalue.value.TherapistSessionsPtOt;
    this.OccuAssessmentsModelobj.beginSymptoms = this.formvalue.value.beginSymptoms;
    this.OccuAssessmentsModelobj.PainDuringRest = this.formvalue.value.PainDuringRest;
    this.OccuAssessmentsModelobj.Drugs = this.formvalue.value.Drugs;
    this.OccuAssessmentsModelobj.Period = this.formvalue.value.Period;
    this.OccuAssessmentsModelobj.NotesFirstAssement = this.formvalue.value.NotesFirstAssement;
    this.apiServ.postOccuAssessments(this.OccuAssessmentsModelobj).subscribe(e => {

      alert(this.translate.instant('SuccessMessage'))
     // alert(JSON.stringify(e[0]));
      this.AssesmentID = e[0].AssesmentID;
      this.gridApi.applyTransaction({ add: [e[0]] });
      this.Fill_ROM_Grid(31)

      //let ref = document.getElementById('btn_cancel')
      //ref?.click();
      //this.formvalue.reset();

    }, er => { alert(this.translate.instant('WrongMessage')); });
  }
   
  getallOccuAssessments() {
    this.apiServ.getOccuAssessments().subscribe(

      OccuAssessmentsdataRow => {
        this.gridOptions.rowData = OccuAssessmentsdataRow;
      })
  }
  selectedLevel: string = '2';
  getValue(v:string) {
    alert(v);
  }
  updateEvluationValue(item: any, value: string) {
 
    this.AssesmentEvaluationModel_Obj.RomAssementID = item.RomAssementID;

    this.AssesmentEvaluationModel_Obj.Evaluation = value;

    this.apiServ.updateAssesmentRomEvaluation(this.AssesmentEvaluationModel_Obj).subscribe(res => {
      //alert(this.translate.instant('UpdateMessage'));
      
    });
  }
  update_RE_Evaluation(item: any, value: string) {
    
    this.AssesmentEvaluationModel_Obj.RomAssementID = item.RomAssementID;

    this.AssesmentEvaluationModel_Obj.Evaluation = value;

    this.apiServ.updateAssesmentRom_RE_Evaluation(this.AssesmentEvaluationModel_Obj).subscribe(res => {
    //  alert(this.translate.instant('UpdateMessage'));

    });
  }
  Fill_DDlist_Evaluations() {
    this.apiServ.getEvaluations().subscribe(

      row => {
        this.EvaluationList = row;
        this.ReEvaluationList = row;
      })
  }
  // section to fill grid
  Fill_ROM_Grid(  ROMID: number) {

    this.apiServ.Fill_AssessmentsItemRom(this.AssesmentID,ROMID).subscribe(

      OccuAssessmentsdataRow => {
        this.ROM_List = OccuAssessmentsdataRow;
      })
    this.Fill_DDlist_Evaluations();
  }
  Fill_ROM_MMt_Grid(ROMID: number) {

    this.apiServ.Fill_AssessmentsItemRom(this.AssesmentID, ROMID).subscribe(

      OccuAssessmentsdataRow => {
        this.ROM_List = OccuAssessmentsdataRow;
      }) 
  }

  // end section fill Grid
  // swtich div for add and search
  Switch_DIV(IS_Add: boolean) {
    if (IS_Add) {
      $("#div_container").show();
      $("#div_search").hide();
    }
    else {
      $("#div_container").hide();
      $("#div_search").show();
    }

  }
  //switch between button add and edit
  switch_btn(Is_add: boolean) {
    if (Is_add) {
      this.Show_BtnInsert = true;
      this.show_btn_Edit = false;
    }
    else {

      this.Show_BtnInsert = false;
      this.show_btn_Edit = true;
    }

  }
  click_btnInsert() {
    // open pop modal
   // ($('#exampleModal') as any).modal('show');
    this.Switch_DIV(true);
    this.switch_btn(true);
    this.formvalue.reset();
  }
  closepop(){
  ($('#exampleModal') as any).modal('hide');
  }
  
  showAll() {
    this.Switch_DIV(false);
  }
  showDetail(is_Show: boolean) { 
    if (is_Show)
      $("#Div_isfrst").show();
    else
      $("#Div_isfrst").hide();
  }
  OnEdit(row: any) {

    this.OccuAssessmentsModelobj.AssesmentID = row.AssesmentID;
    this.AssesmentID = row.AssesmentID;
    this.formvalue.controls['StudentID'].setValue(row.StudentID);
    this.formvalue.controls['Date'].setValue(row.Date);
    this.formvalue.controls['Notes'].setValue(row.Notes);
    this.formvalue.controls['IS_FirstAssement'].setValue(row.IS_FirstAssement);
    this.showDetail(row.IS_FirstAssement);
    this.formvalue.controls['SessionID'].setValue(row.SessionID);
    this.formvalue.controls['CreateBy'].setValue(row.CreateBy);
    this.formvalue.controls['CreateDate'].setValue(row.CreateDate);
    this.formvalue.controls['Action'].setValue(row.Action);
    this.formvalue.controls['AssementFirstID'].setValue(row.AssementFirstID);
    this.formvalue.controls['QualityDelivery'].setValue(row.QualityDelivery);
    this.formvalue.controls['AnyOtherDiseases'].setValue(row.AnyOtherDiseases);
    this.formvalue.controls['Edema'].setValue(row.Edema);
    this.formvalue.controls['TherapistSessionsPtOt'].setValue(row.TherapistSessionsPtOt);
    this.formvalue.controls['beginSymptoms'].setValue(row.beginSymptoms);
    this.formvalue.controls['PainDuringRest'].setValue(row.PainDuringRest);
    this.formvalue.controls['Drugs'].setValue(row.Drugs);
    this.formvalue.controls['Period'].setValue(row.Period);
    this.formvalue.controls['NotesFirstAssement'].setValue(row.NotesFirstAssement);

     
    // swtch buttons
    this.switch_btn(false);
    this.Switch_DIV(true);

  }
  updateOccuAssessments() {
    this.OccuAssessmentsModelobj.AssesmentID = this.formvalue.value.AssesmentID;
    this.OccuAssessmentsModelobj.AssesmentID = this.formvalue.value.AssesmentID;
    this.OccuAssessmentsModelobj.StudentID = this.formvalue.value.StudentID;
    this.OccuAssessmentsModelobj.Date = this.formvalue.value.Date;
    this.OccuAssessmentsModelobj.Notes = this.formvalue.value.Notes;
    this.OccuAssessmentsModelobj.IS_FirstAssement = this.formvalue.value.IS_FirstAssement;
    this.OccuAssessmentsModelobj.SessionID = this.formvalue.value.SessionID;
    this.OccuAssessmentsModelobj.CreateBy = this.formvalue.value.CreateBy;
    this.OccuAssessmentsModelobj.CreateDate = this.formvalue.value.CreateDate;
    this.OccuAssessmentsModelobj.Action = this.formvalue.value.Action;
    this.OccuAssessmentsModelobj.AssementFirstID = this.formvalue.value.AssementFirstID;
    this.OccuAssessmentsModelobj.QualityDelivery = this.formvalue.value.QualityDelivery;
    this.OccuAssessmentsModelobj.AnyOtherDiseases = this.formvalue.value.AnyOtherDiseases;
    this.OccuAssessmentsModelobj.Edema = this.formvalue.value.Edema;
    this.OccuAssessmentsModelobj.TherapistSessionsPtOt = this.formvalue.value.TherapistSessionsPtOt;
    this.OccuAssessmentsModelobj.beginSymptoms = this.formvalue.value.beginSymptoms;
    this.OccuAssessmentsModelobj.PainDuringRest = this.formvalue.value.PainDuringRest;
    this.OccuAssessmentsModelobj.Drugs = this.formvalue.value.Drugs;
    this.OccuAssessmentsModelobj.Period = this.formvalue.value.Period;
    this.OccuAssessmentsModelobj.NotesFirstAssement = this.formvalue.value.NotesFirstAssement;
    this.apiServ.updateOccuAssessments(this.OccuAssessmentsModelobj, this.OccuAssessmentsModelobj.AssesmentID).subscribe(res => {
      alert(this.translate.instant('UpdateMessage'));
      let ref = document.getElementById('btn_cancel')
      ref?.click();
      this.formvalue.reset();
    });
  }

  // for ag grid

  onGridReady(params: GridReadyEvent) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  }
  // create column of Ag grid
  private GetAgColumns(): ColDef[] {

    return [
      {
        headerName: this.translate.instant('btnlblEdit'),
        cellRendererFramework: ButtonEditRendererComponent,
        cellRendererParams: {
          onClick: this.onBtnEdit_Click.bind(this),
          pk_Name: 'RequestIssueDetID'
        }
      },
      {
        headerName: this.translate.instant('btnlblDelete'),
        cellRendererFramework: ButtonDeleteRendererComponent,
        cellRendererParams: {
          onClick: this.onBtnDelet_Click.bind(this),
          pk_Name: 'RequestIssueDetID'
        }
      },
      

      { headerName: 'ملاحظات   ', field: 'Notes', sortable: true, filter: true, width: 450 },


      { headerName: 'التاريخ   ', field: 'Date', sortable: true, filter: true, width: 150 },
    ];


  }
  // event for button in Ag Grid

  onBtnEdit_Click(e: { rowData: {}; }) {

    this.OnEdit(e.rowData);
  }
  onBtnDelet_Click(e: {
    event: Event,
    rowData: any, pk_value: number
  }) {
    // alert(JSON.stringify(e.rowData));
    // delete from dataBase 
    if (confirm(this.translate.instant('DeleteConfirm'))) {
      this.apiServ.deleteOccuAssessments(e.pk_value).subscribe((res: any) => {
        alert(this.translate.instant('DeleteMessage'));
        let deletedRow = e.rowData;
        this.gridApi.updateRowData({ remove: [deletedRow] });
      });

    }
  }
  deletAssestmentRom(item:any) {
    if (confirm(this.translate.instant('DeleteConfirm'))) {
      this.apiServ.deleteOccuAssessmentsROM(item.RomAssementID).subscribe((res: any) => {
        alert(this.translate.instant('DeleteMessage'));
      
      });

    }
  }
}
