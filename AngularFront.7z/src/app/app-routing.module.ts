import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AgGridComponent } from './ag-grid/ag-grid.component';
 
import { LoginComponent } from './login/login.component';
import { UserComponent } from './security/user/user.component';

import { OccuAssessmentComponent } from './Occupational/occu-assessment/occu-assessment.component';
 
import { RebuildingComponent } from './Pages/rebuilding/rebuilding.component';
import { ReTenantComponent } from './Pages/re-tenant/re-tenant.component';
import { DelayPaymentComponent } from './Pages/delay-payment/delay-payment.component';
import { DashhomeComponent } from './dashhome/dashhome.component';
const routes: Routes = [{ path: 'ag-grid', component: AgGridComponent } 

  , { path: 'login', component: LoginComponent},
  

  { path: 'user', component: UserComponent },


  { path: 'OccuAssessment', component: OccuAssessmentComponent },
  

  { path: 'building', component: RebuildingComponent },
  { path: 'Tenant', component: ReTenantComponent },
  { path: 'DelayPayment', component: DelayPaymentComponent },
  { path: 'dash', component: DashhomeComponent }
];
//'LongTarget/:id'
//const routes: Routes = [{ path: 'ag-grid', component: AgGridComponent },
//  { path: 'employee-dash', component: EmployeeDashBoardComponent }
//  //, { path: 'dasheasttown', component: DasheasttownComponent }
////,{
////  path: 'BaseOffer', component: BaseOfferComponent,
////  children: [{
////    path: 'BaseOffer/#v-pills-messages',
////    component: BaseOfferComponent
////  },
////  {
////    path: 'BaseOffer/#v-pills-messages',
////    component: BaseOfferComponent
////  },
////  {
////    path: 'tabname1',
////    component: BaseOfferComponent
////  }
@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }

export const routingComponent = [AgGridComponent,  LoginComponent, UserComponent,  OccuAssessmentComponent]

//export const routingComponent = [EmployeeDashBoardComponent, AgGridComponent]
