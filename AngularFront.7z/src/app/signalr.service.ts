import { Injectable } from '@angular/core';
import { HubConnection } from '@aspnet/signalr';

import * as signalR from '@microsoft/signalr';
import * as jquery from 'jquery';
import { GlobalConstants } from './common/global-constants';

@Injectable({
  providedIn: 'root'
})
export class SignalrService {
   

  private connection: any;
  private proxy: any;
  constructor() { }
  public initializeSignalRConnection(): void {

    // Host address with port (url) of domain where hub is published  
    const signalRServerEndPoint = GlobalConstants.apiURL;

    // Initialize Connection to hubConnection by assign end url 
    this.connection = $.hubConnection(signalRServerEndPoint);

    // Create Hub Proxy By assign name of Hub in CreateHubProxy Methord
    //TestNotify
    //this.proxy = this.connection.createHubProxy('SendNotificationHub');

    this.proxy = this.connection.createHubProxy('TestNotify');

    // After Proxy Create "messageRecive" method of Hub(server) Get Response of other Client Notificaiton and "serverMessage" is variable hold message and assign to other method  Name is "onMessageRecived" method
    this.proxy.on('messageReceived', (serverMessage: string) => this.onMessageReceived(serverMessage));

    // Now Here Connect stablish and if application is  Connected to Hub 
    //You Can Send Notification To Other User by This Method "broadcastMessage"
    this.connection.start().done((data: any) => {
      console.log('Connected to Notification Hub');
      this.broadcastMessage();
    }).catch((error: any) => {
      console.log('Notification Hub error -> ' + error);
    });
  }
  public initiateSignalrConnectionR(): Promise<void> {
    return new Promise((resolve, reject) => {
      
      this.connection = new signalR.HubConnectionBuilder()
      //  .withUrl('ws://' + GlobalConstants.WSapiURL + '/WsTestNotify', {
    
        .withUrl('ws://'+GlobalConstants.apiURL + '/GetMessages', {    
         skipNegotiation: true,
         transport: signalR.HttpTransportType.WebSockets
       }) // the SignalR server url
        .build();

      this.connection
        .start()
        .then(() => {
          alert('success');
          console.log(`SignalR connection success! connectionId: ${this.connection.connectionId} `);
          resolve();
        })
        .catch((error: any) => {
          console.log(`SignalR connection error: ${error}`);
          reject();
        });
    });
  }
  test() { }
  // this method send message to Hub For Other Client
  public broadcastMessage(): void {
    this.proxy.invoke('notificationService', 'Welcome to Dashboard')
      .catch((error: any) => {
        console.log('broadcastMessage error -> ' + error);
      });
  }

  // This method Recived Message from Hub send by other client
  private onMessageReceived(serverMessage: string) {
    console.log('New message received from Server: ' + serverMessage);
  }
}
