import { Component, OnInit, AfterViewInit } from '@angular/core';
 

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  ColumnDefs: any;
  RowData: any;
  AgLoad: boolean | undefined;
  constructor() {
    //this.gridOptions = <GridOptions>{};
    //this.columnDefinitions = [

    //];

    //this.gridOptions = {
    //  columnDefs: this.columnDefinitions,
    //  enableFilter: true,
    //  enableSorting: true,
    //  pagination: true
    //};

    //this.rowSelection = 'single';
  }
  ngAfterViewInit()
  
  {
    console.log('after ngAfterViewInit');
    (<any>$('#side-menu')).metisMenu();
  }


  ngOnInit() {
   // this.GetAgColumns();
   // this.GetGiftVoucherList();
  }
 
}
