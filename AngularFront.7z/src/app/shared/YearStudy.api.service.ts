import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http'
import { map } from 'rxjs/operators' 
import { GlobalConstants } from '../common/global-constants';

@Injectable({
  providedIn: 'root'
})
export class ApiService_YearStudy {

    url: string = GlobalConstants.apiURL;
 
    constructor(private http: HttpClient) { 
    }
   
 
    postYearStudy(data: any) {
   
      return this.http.post<any>(this.url +"CreateYearStudy/", data).pipe(map((res: any) => {
      return res;
    }))
  }

    getYearStudy() {
      return this.http.get<any>(this.url +"YearStudyList").pipe(map((res: any) => { return  res;}))
  }
    updateYearStudy(data: any, id: number) {
        return this.http.post<any>(this.url +"EditInYearStudy" + id, data).pipe(map((res: any) => { return res;}))

  }

    deleteYearStudy(id: number) {
      return this.http.delete<any>(this.url +"YearStudy/delete/" + id).pipe(map((res: any) => { return res;}))
  }
}
