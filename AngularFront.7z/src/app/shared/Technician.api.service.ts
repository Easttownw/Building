import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http'
import { map } from 'rxjs/operators' 
import { GlobalConstants } from '../common/global-constants';

@Injectable({
  providedIn: 'root'
})
export class ApiService_Technician {

    url: string = GlobalConstants.apiURL;
 
    constructor(private http: HttpClient) { 
    }
   
 
    postTechnician(data: any) {
  console.log(JSON.stringify(data))
      return this.http.post<any>(this.url +"Technician/CreateTechnician/", data).pipe(map((res: any) => {
      return res;
    }))
  }
  uploadPhoto(formData: any) {
    return this.http.post(GlobalConstants.apiURL + 'MedHospital/Uploadccc'
      , formData, { reportProgress: false, responseType: 'text' })
       
      .pipe(map(data => { return data; }));



  }
    getTechnician() {
      return this.http.get<any>(this.url +"Technician/TechnicianList").pipe(map((res: any) => { return  res;}))
  }
  updateTechnician(data: any, id: number) {
    alert(JSON.stringify(data))
    return this.http.put<any>(this.url +"Technician/EditInTechnician" , data).pipe(map((res: any) => { return res;}))

  }

  deleteTechnician(id: number) {
      alert(id)
      return this.http.delete<any>(this.url +"Technician/Delete/" + id).pipe(map((res: any) => { return res;}))
  }
}
