import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http'
import { map } from 'rxjs/operators' 
import { GlobalConstants } from '../common/global-constants';

@Injectable({
  providedIn: 'root'
})
export class ApiService_RebuildingAttach {

    url: string = GlobalConstants.apiURL;
 
    constructor(private http: HttpClient) { 
    }
   
 
    postRebuildingAttach(data: any) {
   
      return this.http.post<any>(this.url +"RebuildingAttach/CreateRebuildingAttach/", data).pipe(map((res: any) => {
      return res;
    }))
  }

  getRebuildingAttach(BuildingID:number) {
    return this.http.get<any>(this.url + "RebuildingAttach/RebuildingAttachList/" + BuildingID ).pipe(map((res: any) => { return  res;}))
  }
    updateRebuildingAttach(data: any, id: number) {
      return this.http.post<any>(this.url +"RebuildingAttach/EditInRebuildingAttach" , data).pipe(map((res: any) => { return res;}))

  }

    deleteRebuildingAttach(id: number) {
      return this.http.delete<any>(this.url +"RebuildingAttach/DeleteRebuildingAttach/" + id).pipe(map((res: any) => { return res;}))
  }
  uploadFile(data: any) {
    return this.http.post<any>(this.url + "RebuildingAttach/Upload", data).pipe(map((res: any) => { return res; }))
  }
}
