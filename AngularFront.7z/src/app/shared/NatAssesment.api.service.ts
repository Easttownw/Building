import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http'
import { map } from 'rxjs/operators' 
import { GlobalConstants } from '../common/global-constants';

@Injectable({
  providedIn: 'root'
})
export class ApiService_NatAssesment {

    url: string = GlobalConstants.apiURL;
 
    constructor(private http: HttpClient) { 
    }
   
 
    postNatAssesment(data: any) {
   
      return this.http.post<any>(this.url +"CreateNatAssesment/", data).pipe(map((res: any) => {
      return res;
    }))
  }
  Post_Assessment_ROM(data: any) {
    return this.http.post<any>(this.url + "CreateNatAssesmentROM/", data).pipe(map((res: any) => {
      return res;
    }))
  }
  getNatAssesmentROM(AssesmentID: Number, ROMID:string) {
    return this.http.get<any>(this.url + "NatAssesmentROMList/" + AssesmentID + "/" + ROMID).pipe(map((res: any) => { return res; }))
  }
  deleteNatAssesmentROM(id: number) {
    return this.http.delete<any>(this.url + "NatAssesmentROM/delete/" + id).pipe(map((res: any) => { return res; }))
  }
    getNatAssesment() {
      return this.http.get<any>(this.url +"NatAssesmentList").pipe(map((res: any) => { return  res;}))
  }
  FillItemAssement(GrpID:number) {
    return this.http.get<any>(this.url + "NatItemList/"+GrpID).pipe(map((res: any) => { return res; }))
  }
  Fill_ddlist_ItemsValue(GrpID: number) {
    return this.http.get<any>(this.url + "NatItemValuelist/" + GrpID).pipe(map((res: any) => { return res; }))
  }
  Fill_ddlist_RomItemsValue(ROMID: number) {
     
    return this.http.get<any>(this.url + "getNaTItemtROMValueList/" + ROMID).pipe(map((res: any) => { return res; }))
  }
    updateNatAssesment(data: any, id: number) {
        return this.http.post<any>(this.url +"EditInNatAssesment" + id, data).pipe(map((res: any) => { return res;}))

  }

    deleteNatAssesment(id: number) {
      return this.http.delete<any>(this.url +"NatAssesment/delete/" + id).pipe(map((res: any) => { return res;}))
  }
}
