import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http'
import { map } from 'rxjs/operators' 
import { GlobalConstants } from '../common/global-constants';

@Injectable({
  providedIn: 'root'
})
export class ApiService_Rebuilding {

    url: string = GlobalConstants.apiURL;
 
    constructor(private http: HttpClient) { 
    }
   
 
    postRebuilding(data: any) {
   
      return this.http.post<any>(this.url +"Rebuilding/CreateRebuilding/", data).pipe(map((res: any) => {
      return res;
    }))
  }

    getRebuilding() {
      return this.http.get<any>(this.url +"Rebuilding/RebuildingList").pipe(map((res: any) => { return  res;}))
  }
  Get_Available_building() {

    return this.http.get<any>(this.url + "Rebuilding/Get_Available_building").pipe(map((res: any) => { return res; }))
  }
    updateRebuilding(data: any, id: number) {
      return this.http.put<any>(this.url +"Rebuilding/EditInRebuilding" , data).pipe(map((res: any) => { return res;}))

  }

    deleteRebuilding(id: number) {
      return this.http.delete<any>(this.url +"Rebuilding/deleteRebuilding/" + id).pipe(map((res: any) => { return res;}))
  }
}
