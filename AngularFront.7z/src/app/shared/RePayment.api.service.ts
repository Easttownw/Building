import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http'
import { map } from 'rxjs/operators' 
import { GlobalConstants } from '../common/global-constants';

@Injectable({
  providedIn: 'root'
})
export class ApiService_RePayment {

    url: string = GlobalConstants.apiURL;
 
    constructor(private http: HttpClient) { 
    }
   
 
    postRePayment(data: any) {

      return this.http.post<any>(this.url +"RePayment/CreateRePayment/", data).pipe(map((res: any) => {
      return res;
    }))
  }

  getRePayment(RentDateID:number) {
    return this.http.get<any>(this.url + "RePayment/RePaymentList/" + RentDateID).pipe(map((res: any) => { return  res;}))
  }
    updateRePayment(data: any, id: number) {
      return this.http.post<any>(this.url +"RePayment/EditInRePayment" , data).pipe(map((res: any) => { return res;}))

  }

  deleteRePayment(id: number) {

      return this.http.delete<any>(this.url +"RePayment/DeleteRePayment/" + id).pipe(map((res: any) => { return res;}))
  }
}
