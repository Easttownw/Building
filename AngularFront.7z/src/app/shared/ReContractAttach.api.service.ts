import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http'
import { map } from 'rxjs/operators' 
import { GlobalConstants } from '../common/global-constants';

@Injectable({
  providedIn: 'root'
})
export class ApiService_ReContractAttach {

    url: string = GlobalConstants.apiURL;
 
    constructor(private http: HttpClient) { 
    }
   
 
    postReContractAttach(data: any) {
   
      return this.http.post<any>(this.url +"ReContractAttach/CreateReContractAttach/", data).pipe(map((res: any) => {
      return res;
    }))
  }

  getReContractAttach(ContractID:number) {
    return this.http.get<any>(this.url + "ReContractAttach/ReContractAttachList/" + ContractID).pipe(map((res: any) => { return  res;}))
  }
    updateReContractAttach(data: any, id: number) {
      return this.http.put<any>(this.url +"ReContractAttach/EditInReContractAttach" , data).pipe(map((res: any) => { return res;}))

  }

    deleteReContractAttach(id: number) {
      return this.http.delete<any>(this.url +"ReContractAttach/DeleteReContractAttach/" + id).pipe(map((res: any) => { return res;}))
  }
  uploadFile(data: any) {
    return this.http.post<any>(this.url + "RebuildingAttach/Upload", data).pipe(map((res: any) => { return res; }))
  }
}
