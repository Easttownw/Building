import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http'
import { map } from 'rxjs/operators' 
import { GlobalConstants } from '../common/global-constants';

@Injectable({
  providedIn: 'root'
})
export class ApiService_ReBuildingFlat {

    url: string = GlobalConstants.apiURL;
 
    constructor(private http: HttpClient) { 
    }
   
 
    postReBuildingFlat(data: any) {
   console.log(JSON.stringify(data))
      return this.http.post<any>(this.url +"ReBuildingFlat/CreateReBuildingFlat/", data).pipe(map((res: any) => {
      return res;
    }))
  }

  getReBuildingFlat(buildingID:number) {
    return this.http.get<any>(this.url + "ReBuildingFlat/ReBuildingFlatList/" + buildingID).pipe(map((res: any) => { return  res;}))
  }
    updateReBuildingFlat(data: any, id: number) {
      return this.http.post<any>(this.url +"ReBuildingFlat/EditInReBuildingFlat" , data).pipe(map((res: any) => { return res;}))

  }

    deleteReBuildingFlat(id: number) {
      return this.http.delete<any>(this.url +"ReBuildingFlat/DeleteReBuildingFlat/" + id).pipe(map((res: any) => { return res;}))
  }
}
