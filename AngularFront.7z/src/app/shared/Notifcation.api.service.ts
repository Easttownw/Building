import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule, HttpErrorResponse, HttpHeaders } from '@angular/common/http'
import { catchError, map } from 'rxjs/operators'
import { GlobalConstants } from '../common/global-constants';
import { Notification, Observable, throwError } from 'rxjs';
import { NotifcationModel } from '../notifcation/Notifcation.model';
 

@Injectable({
  providedIn: 'root'
})
export class ApiService_Notifcation {


  url: string = GlobalConstants.apiURL;
  url_service: string = GlobalConstants.URLNotificationServ;

  // private url = 'http://localhost:62769/' + 'api/employees';
  constructor(private http: HttpClient) {
  }

  newUrl: string = ''

  postNotifcation(data: any) {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });

    //const employee: Employee = { id: "0", name: "dddddddddddddd" };
    //alert('in')
    //return this.http.post<Employee>("http://gpioneer.easttowns.net/", employee).pipe(map((res: any) => { return alert(res); }, (er:any) => { alert(er)}))
   // return this.http.post("http://localhost:62769/api/Employees777", employee, { headers: headers }).pipe(catchError(this.errorHandler));

    //return this.http.post<Employee>(this.url_service + 'api/Employees', employee, { headers: headers })
    //  .pipe(
    //  //  map((res: any) => { })
    //   catchError(this.handleError)
    //  );
  }
  errorHandler(error: HttpErrorResponse) {
    alert('errrrr')
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${error.error}`);
    }
    // return an observable with a user-facing error message
    return throwError(
      'Something bad happened; please try again later.');
  }
  postNotifcation444(data: any) {
    alert('test');

    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });

    return this.http.post<any>(this.url_service + 'api/Notifications/CreateNotifcation/', data, { headers: headers }).pipe(catchError(this.errorHandler));
    //return this.http.post<any>(this.url_service + 'api/employees', data )
    //  .pipe(
    //    catchError(this.handleError)
    //  );
  }
  private handleError(err: any) {
    let errorMessage: string;
    if (err.error instanceof ErrorEvent) {
      errorMessage = `An error occurred: ${err.error.message}`;
    } else {
      errorMessage = `Backend returned code ${err.status}: ${err.body.error}`;
    }
    console.error(err);
    return throwError(errorMessage);
  }
  getNotificationCount() {
    //const url = `${this.notificationsUrl}/notificationcount`;
   // alert('count');
    return this.http.get<any>(this.url_service + "api/Notifications/NotifcationList").pipe(map((res: any) => { return res; }))
  }
  getNotifcation() { 
    return this.http.get<any>(this.url + "NotifcationByuserList/" + localStorage.getItem('DepartmentID') + "/" + localStorage.getItem('EmployeeID')).pipe(map((res: any) => { return res; }))
  }
  getNotifcationToDep() {
    return this.http.get<any>(this.url + "NotifcationFromDep/" + localStorage.getItem('DepartmentID')  ).pipe(map((res: any) => { return res; }))
  }
  getNotifcationFrom_ToDep(fromDep:number) {
    return this.http.get<any>(this.url + "NotifcationFrom_ToDep/" + localStorage.getItem('DepartmentID') + "/" + fromDep).pipe(map((res: any) => { return res; }))
  }
  //  getNotifcation() {
  // this.http.get<any>(this.url +"NotifcationList").pipe(map((res: any) => { return  res;}))
  //}
  updateNotifcation(data: any, id: number) {
    return this.http.post<any>(this.url + "EditInNotifcation", data).pipe(map((res: any) => { return res; }))

  }

  deleteNotifcation(id: number) {
    return this.http.delete<any>(this.url + "Notifcation/delete/" + id).pipe(map((res: any) => { return res; }))
  }
}
