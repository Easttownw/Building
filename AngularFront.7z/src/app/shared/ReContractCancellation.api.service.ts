import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http'
import { map } from 'rxjs/operators' 
import { GlobalConstants } from '../common/global-constants';

@Injectable({
  providedIn: 'root'
})
export class ApiService_ReContractCancellation {

    url: string = GlobalConstants.apiURL;
 
    constructor(private http: HttpClient) { 
    }
   
 
    postReContractCancellation(data: any) {
   
      return this.http.post<any>(this.url +"CreateReContractCancellation/", data).pipe(map((res: any) => {
      return res;
    }))
  }

    getReContractCancellation() {
      return this.http.get<any>(this.url +"ReContractCancellationList").pipe(map((res: any) => { return  res;}))
  }
    updateReContractCancellation(data: any, id: number) {
        return this.http.post<any>(this.url +"EditInReContractCancellation" , data).pipe(map((res: any) => { return res;}))

  }

    deleteReContractCancellation(id: number) {
      return this.http.delete<any>(this.url +"ReContractCancellation/delete/" + id).pipe(map((res: any) => { return res;}))
  }
  uploadFile(data: any) {
    return this.http.post<any>(this.url + "RebuildingAttach/Upload", data).pipe(map((res: any) => { return res; }))
  }
}
