import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http'
import { map } from 'rxjs/operators' 
import { GlobalConstants } from '../common/global-constants';

@Injectable({
  providedIn: 'root'
})
export class ApiService_Nationality {

    url: string = GlobalConstants.apiURL;
 
    constructor(private http: HttpClient) { 
    }
   
 
    postNationality(data: any) {
   
      return this.http.post<any>(this.url +"CreateNationality/", data).pipe(map((res: any) => {
      return res;
    }))
  }

    getNationality() {
      return this.http.get<any>(this.url +"NationalityList").pipe(map((res: any) => { return  res;}))
  }
    updateNationality(data: any, id: number) {
        return this.http.post<any>(this.url +"EditInNationality" , data).pipe(map((res: any) => { return res;}))

  }

    deleteNationality(id: number) {
      return this.http.delete<any>(this.url +"Nationality/delete/" + id).pipe(map((res: any) => { return res;}))
  }
}
