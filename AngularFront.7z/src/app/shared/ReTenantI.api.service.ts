import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http'
import { map } from 'rxjs/operators' 
import { GlobalConstants } from '../common/global-constants';

@Injectable({
  providedIn: 'root'
})
export class ApiService_ReTenantI {

    url: string = GlobalConstants.apiURL;
 
    constructor(private http: HttpClient) { 
    }
   
 
    postReTenantI(data: any) {
   
      return this.http.post<any>(this.url +"ReTenantI/CreateReTenantI/", data).pipe(map((res: any) => {
      return res;
    }))
  }

  getReTenantI(BuildingID:number) {
    return this.http.get<any>(this.url + "ReTenantI/ReTenantIList/" + BuildingID).pipe(map((res: any) => { return  res;}))
  }
  getAllReTenant( ) {
    return this.http.get<any>(this.url + "ReTenantI/GetListALLTenantI/" ).pipe(map((res: any) => { return res; }))
  }
    updateReTenantI(data: any, id: number) {
      return this.http.put<any>(this.url +"ReTenantI/EditInReTenantI" , data).pipe(map((res: any) => { return res;}))

  }

    deleteReTenantI(id: number) {
      return this.http.delete<any>(this.url +"ReTenantI/deleteReTenantI/" + id).pipe(map((res: any) => { return res;}))
  }
}
