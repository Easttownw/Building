import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http'
import { map } from 'rxjs/operators' 
import { GlobalConstants } from '../common/global-constants';

@Injectable({
  providedIn: 'root'
})
export class ApiService_ReContractReNew {

    url: string = GlobalConstants.apiURL;
 
    constructor(private http: HttpClient) { 
    }
   
 
    postReContractReNew(data: any) {
   
      return this.http.post<any>(this.url +"CreateReContractReNew/", data).pipe(map((res: any) => {
      return res;
    }))
  }

    getReContractReNew() {
      return this.http.get<any>(this.url +"ReContractReNewList").pipe(map((res: any) => { return  res;}))
  }
    updateReContractReNew(data: any, id: number) {
        return this.http.post<any>(this.url +"EditInReContractReNew" , data).pipe(map((res: any) => { return res;}))

  }

    deleteReContractReNew(id: number) {
      return this.http.delete<any>(this.url +"ReContractReNew/delete/" + id).pipe(map((res: any) => { return res;}))
  }
}
