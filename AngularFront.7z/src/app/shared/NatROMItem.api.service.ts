import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http'
import { map } from 'rxjs/operators' 
import { GlobalConstants } from '../common/global-constants';

@Injectable({
  providedIn: 'root'
})
export class ApiService_NatROMItem {

    url: string = GlobalConstants.apiURL;
 
    constructor(private http: HttpClient) { 
    }
   
 
    postNatROMItem(data: any) {
   
      return this.http.post<any>(this.url +"CreateNatROMItem/", data).pipe(map((res: any) => {
      return res;
    }))
  }

    getNatROMItem() {
      return this.http.get<any>(this.url +"NatROMItemList").pipe(map((res: any) => { return  res;}))
  }
  Fill_ROM() {
    return this.http.get<any>(this.url + "NatROMList").pipe(map((res: any) => { return res; }))
  }
    updateNatROMItem(data: any, id: number) {
        return this.http.post<any>(this.url +"EditInNatROMItem" + id, data).pipe(map((res: any) => { return res;}))

  }

    deleteNatROMItem(id: number) {
      return this.http.delete<any>(this.url +"NatROMItem/delete/" + id).pipe(map((res: any) => { return res;}))
  }
}
