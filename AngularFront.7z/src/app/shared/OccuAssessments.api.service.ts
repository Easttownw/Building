import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http'
import { map } from 'rxjs/operators' 
import { GlobalConstants } from '../common/global-constants';

@Injectable({
  providedIn: 'root'
})
export class ApiService_OccuAssessments {

    url: string = GlobalConstants.apiURL;
 
    constructor(private http: HttpClient) { 
    }
   
 
    postOccuAssessments(data: any) {
      alert(JSON.stringify(data));
      return this.http.post<any>(this.url +"CreateOccuAssessments/", data).pipe(map((res: any) => {
      return res;
    }))
  }

    getOccuAssessments() {
      return this.http.get<any>(this.url +"OccuAssessmentsList").pipe(map((res: any) => { return  res;}))
  }
  updateAssesmentRomEvaluation(data:any) {
    return this.http.post<any>(this.url + "updateAssesRomEvaluation" , data  ).pipe(map((res: any) => { return res; }))
  }
  updateAssesmentRom_RE_Evaluation(data: any) {
    return this.http.post<any>(this.url + "updateAssesRom_RE_Evaluation", data).pipe(map((res: any) => { return res; }))
  }
  Fill_AssessmentsItemRom(AssesmentID: number, ROMID:number) {
    return this.http.get<any>(this.url + "OccuAssessmentItembyRomsList/" + AssesmentID +"/"+ROMID).pipe(map((res: any) => { return res; }))
  }
  getEvaluations() {
    return this.http.get<any>(this.url + "OccuEvaluationList" ).pipe(map((res: any) => { return res; }))
  }
  
    updateOccuAssessments(data: any, id: number) {
        return this.http.post<any>(this.url +"EditInOccuAssessments" + id, data).pipe(map((res: any) => { return res;}))

  }

    deleteOccuAssessments(id: number) {
      return this.http.delete<any>(this.url +"OccuAssessments/delete/" + id).pipe(map((res: any) => { return res;}))
  }
  deleteOccuAssessmentsROM(id: number) {
    return this.http.delete<any>(this.url + "OccuAssessmentsROM/delete/" + id).pipe(map((res: any) => { return res; }))
  }
}
