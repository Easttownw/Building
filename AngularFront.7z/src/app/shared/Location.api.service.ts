import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http'
import { map } from 'rxjs/operators' 
import { GlobalConstants } from '../common/global-constants';

@Injectable({
  providedIn: 'root'
})
export class ApiService_Location {

    url: string = GlobalConstants.apiURL;
 
    constructor(private http: HttpClient) { 
    }
   
 
    postLocation(data: any) {
   
      return this.http.post<any>(this.url +"Location/CreateLocation/", data).pipe(map((res: any) => {
      return res;
    }))
  }

    getLocation() { 
      return this.http.get<any>(this.url + "Location/LocationList").pipe(map((res: any) => { return res; }))
  }
    updateLocation(data: any, id: number) {
      return this.http.put<any>(this.url +"Location/EditInLocation" , data).pipe(map((res: any) => { return res;}))

  }

    deleteLocation(id: number) {
      return this.http.delete<any>(this.url +"Location/DeleteCity/" + id).pipe(map((res: any) => { return res;}))
  }
}
