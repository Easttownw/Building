import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http'
import { map } from 'rxjs/operators' 
import { GlobalConstants } from '../common/global-constants';

@Injectable({
  providedIn: 'root'
})
export class ApiService_Service {

    url: string = GlobalConstants.apiURL;
 
    constructor(private http: HttpClient) { 
    }
   
 
    postService(data: any) {
   
      return this.http.post<any>(this.url +"Service/CreateService/", data).pipe(map((res: any) => {
      return res;
    }))
  }

    getService() {
      return this.http.get<any>(this.url +"Service/ServiceList").pipe(map((res: any) => { return  res;}))
  }
  getParentService() {
    return this.http.get<any>(this.url + "Service/ParentServiceList").pipe(map((res: any) => { return res; }))
  }
  
    updateService(data: any, id: number) {
      return this.http.put<any>(this.url +"Service/EditInService" , data).pipe(map((res: any) => { return res;}))

  }

    deleteService(id: number) {
      return this.http.delete<any>(this.url +"Service/DeleteService/" + id).pipe(map((res: any) => { return res;}))
  }
  UploadPhoto(formData: any) {
    return this.http.post(GlobalConstants.apiURL + 'GroupService/UploadPhoto'
      , formData, { reportProgress: false, responseType: 'text' })

      .pipe(map(data => { return data; }));



  }
}
