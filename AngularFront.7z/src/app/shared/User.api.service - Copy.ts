import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http'
import { map } from 'rxjs/operators' 
import { GlobalConstants } from '../common/global-constants';

@Injectable({
  providedIn: 'root'
})
export class ApiService_User {

    url: string = GlobalConstants.apiURL;
 
    constructor(private http: HttpClient) { 
    }
   
 
    postUser(data: any) {
   
      return this.http.post<any>(this.url +"CreateUser/", data).pipe(map((res: any) => {
      return res;
    }))
  }
  AccessUser(data: any) {
    //alert(JSON.stringify(data));
    return this.http.post<any>(this.url + "AccessUser/", data).pipe(map((res: any) => {
      return res;
    }))
  }
  uploadPhoto(data: any) {
    //alert(JSON.stringify(data));
    const formData = new FormData();
    formData.append('files', data);

    return this.http.post<any>(this.url + "uploadphoto/", formData).pipe(map((res: any) => {
      return res;
    }))
  }
    getUser() {
      return this.http.get<any>(this.url +"UserList").pipe(map((res: any) => { return  res;}))
  }
    updateUser(data: any, id: number) {
        return this.http.post<any>(this.url +"EditInUser" , data).pipe(map((res: any) => { return res;}))

  }

    deleteUser(id: number) {
      return this.http.delete<any>(this.url +"User/delete/" + id).pipe(map((res: any) => { return res;}))
  }
}
