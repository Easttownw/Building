import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http'
import { map } from 'rxjs/operators' 
import { GlobalConstants } from '../common/global-constants';

@Injectable({
  providedIn: 'root'
})
export class ApiService_RentDatePayment {

    url: string = GlobalConstants.apiURL;
 
    constructor(private http: HttpClient) { 
    }
   
 
    postRentDatePayment(data: any) {
   
      return this.http.post<any>(this.url +"RentDatePayment/CreateRentDatePayment/", data).pipe(map((res: any) => {
      return res;
    }))
  }

  getRentDatePayment(ContractID:number) {
    return this.http.get<any>(this.url + "RentDatePayment/RentDatePaymentList/" + ContractID).pipe(map((res: any) => { return  res;}))
  }
  geDelayPayment( ) {
    return this.http.get<any>(this.url + "RentDatePayment/GetAllDelayPayment/").pipe(map((res: any) => { return res; }))
  }
    updateRentDatePayment(data: any, id: number) {
      return this.http.put<any>(this.url +"RentDatePayment/EditInRentDatePayment" , data).pipe(map((res: any) => { return res;}))

  }

    deleteRentDatePayment(id: number) {
      return this.http.delete<any>(this.url +"RentDatePayment/DeleteRentDatePayment/" + id).pipe(map((res: any) => { return res;}))
  }
}
