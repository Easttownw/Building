import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http'
import { map } from 'rxjs/operators'
//import { observable, Observer } from 'rxjs';
//import { Subscriber } from 'rxjs';
//import { employeeModel } from '../employee-dash-board/employee-dash-board.model';
//import { EmployeeDashBoardComponent } from '../employee-dash-board/employee-dash-board.component';
 
@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(private http: HttpClient) { }


  postEmployee(data: any) {
   
    return this.http.post<any>("http://localhost:50971/CreateEmployee/", data).pipe(map((res: any) => {
      return res;
    }))
  }

  getEmployee() {
    return this.http.get<any>("http://localhost:50971/EmployeeList").pipe(map((res: any) => { return  res;}))
  }
  updateEmployee(data: any, id: number) {
    return this.http.put<any>("" + id, data).pipe(map((res: any) => { return res;}))

  }

  deleteEmployee(id: number) {
    return this.http.delete<any>("http://localhost:50971/deleteEmployee/" + id).pipe(map((res: any) => { return res;}))
  }
}
