import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http'
import { map } from 'rxjs/operators' 
import { GlobalConstants } from '../common/global-constants';

@Injectable({
  providedIn: 'root'
})
export class ApiService_ReOwner {

    url: string = GlobalConstants.apiURL;
 
    constructor(private http: HttpClient) { 
    }
   
 
    postReOwner(data: any) {
   
      return this.http.post<any>(this.url +"ReOwner/CreateReOwner/", data).pipe(map((res: any) => {
      return res;
    }))
  }

    getReOwner() {
      return this.http.get<any>(this.url +"ReOwner/ReOwnerList").pipe(map((res: any) => { return  res;}))
  }
  getOwnerByBuilding(buildingID: number) {
 
    return this.http.get<any>(this.url + "ReOwner/GetOwnerByBuilding/" + buildingID).pipe(map((res: any) => { return res; }))
  }
  updateReOwner(data: any, id: number) {
      console.log(JSON.stringify( data))
      return this.http.put<any>(this.url +"ReOwner/EditInReOwner" , data).pipe(map((res: any) => { return res;}))

  }

    deleteReOwner(id: number) {
      return this.http.delete<any>(this.url +"ReOwner/deleteReOwner/" + id).pipe(map((res: any) => { return res;}))
  }
}
