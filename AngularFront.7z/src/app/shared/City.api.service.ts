import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http'
import { map } from 'rxjs/operators' 
import { GlobalConstants } from '../common/global-constants';

@Injectable({
  providedIn: 'root'
})
export class ApiService_City {

    url: string = GlobalConstants.apiURL;
 
    constructor(private http: HttpClient) { 
    }
   
 
    postCity(data: any) {
   
      return this.http.post<any>(this.url +"City/CreateCity/", data).pipe(map((res: any) => {
      return res;
    }))
  }

    getCity() {
      return this.http.get<any>(this.url +"City/CityList").pipe(map((res: any) => { return  res;}))
  }
    updateCity(data: any, id: number) {
        return this.http.put<any>(this.url +"City/EditInCity" , data).pipe(map((res: any) => { return res;}))

  }

    deleteCity(id: number) {
      return this.http.delete<any>(this.url +"City/delete/" + id).pipe(map((res: any) => { return res;}))
  }
}
