import { Component } from '@angular/core';
import { ICellRendererParams } from 'ag-grid-community';
import { ICellRendererAngularComp } from 'ag-grid-angular';

@Component({
  selector: 'app-gender-renderer',
  template: ` <span> <img [src]="imageSource" />{{ value }} </span> `,
})
export class GenderRendererComponent implements ICellRendererAngularComp  {
  public imageSource: string | undefined;
  public value: any;

  agInit(params: ICellRendererParams): void {
    const image = params.value === 'Male' ? 'male.png' : 'female.png';
    this.imageSource = `https://www.ag-grid.com/example-assets/genders/${image}`;
    this.value = params.value;
  }
  constructor() { }
    refresh(params: ICellRendererParams): boolean {
        throw new Error('Method not implemented.');
    }

   

}
