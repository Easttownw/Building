import { Component, OnInit } from '@angular/core';
import { ChartDataSets, ChartOptions, ChartType, ChartColor } from 'chart.js';
import { Color , ChartsModule, Label, SingleDataSet, monkeyPatchChartJsTooltip, monkeyPatchChartJsLegend, MultiDataSet} from 'ng2-charts'; 
@Component({
  selector: 'app-dashhome',
  templateUrl: './dashhome.component.html',
  styleUrls: ['./dashhome.component.css']
})
export class DashhomeComponent implements OnInit {
  lineChartData: ChartDataSets[] = [{ data: [10, 17, 1, 25, 27, 9, 15], label: 'Series A' },];
  lineChartLabels: Label[] = ['  فبراير', '     يناير', '   ديسمبر    ', '  نوفمبر    ', 'اكتوبر'];
  lineChartOptions = {
    responsive: true,
  };
  lineChartColors: Color[] = [
    {
      borderColor: 'black',
      backgroundColor: 'rgba(255,0,0,0.3)',
    },
  ];
  lineChartLegend = true;
  lineChartType: string = 'line';
  lineChartPlugins = [];
  chart: any;
  ///******************** pieChartData
  pieChartOptions: ChartOptions = {
    responsive: true,
  };
  pieChartLabels: Label[] = [['سعيد البلوشى'],[' بيت الاصيل'], [' حمد سالم '], [' صالح البورسعيدى   '], [' بيت الهجن ' ]]//, ['In', 'Store', 'Sales'], 'Mail Sales'];

  pieChartData: SingleDataSet = [300, 500, 100, 20];
  pieChartData_ReNew: SingleDataSet = [2, 5, 4, 0];
  pieChartType: ChartType = 'pie';
  pieChartLegend = true;
  pieChartPlugins = [];
  
  ///* End PieChartData

  //********************* BarChart
  barChartOptions: ChartOptions = {
    responsive: true,
  };
  barChartLabels: Label[] = ['   بيت الاصيل', '   حمد سالم  ', '  صالح البورسعيدى  ' ];
  barChartType: ChartType = 'bar';
  barChartLegend = true;
  barChartPlugins = [];
  barChartData: ChartDataSets[] = [
    //{ data: [65, 59, 80, 81, 56, 55, 40], label: 'Female A' },
    { data: [18600, 8700, 3900], label: 'المبالغ المتاخرة' }
  ];
  //////**************doughnutChartLabels
  doughnutChartLabels: Label[] = ['  شاغر ', '     متاح  ', '  محجوز    '];
  doughnutChartData: MultiDataSet = [
    [33, 5, 2],
    [25, 8, 4],
    [34, 17, 3],
  ];
  doughnutChartType: ChartType = 'doughnut';
  //************ END doughnutChartLabels
  //************ end BarChart
  //public lineChartData: ChartDataSets[] = [
  //  { data: [61, 59, 80, 65, 45], label: 'توحد' },
  //  //{ data: [57, 50, 75, 87, 43, 46, 37, 48, 67, 56, 70, 50], label: 'Mi' },
  //];

  //public lineChartLabels: any[] = ['توحد', 'متلازمة داون', 'شلل دماغى', 'اعاقة ذهنية', 'اخرى' ];

  //public lineChartOptions = {
  //  responsive: true,
  //};
  //// Define colors of chart segments
  //lineChartColors   = [

  //  { // dark grey

  //    backgroundColor: 'rgba(0,0,96,0.2)',
  //    borderColor: 'rgba(77,0,0,1)',
  //  },
  //  { // red
  //    backgroundColor: 'rgba(255,0,0,0.9)',
  //    borderColor: 'red',
  //  }
  //];

  //public lineChartLegend = true;
  //public lineChartType = 'line';
  //public lineChartPlugins = [];

  //public ChartType = 'line';
  public barChartLabels_H: Label[] = ['اكتوبر', 'نوفمبر', 'ديسمبر', 'يناير', 'فبراير' ];
  public barChartType_H: ChartType = 'bar';
  public barChartLegend_H = true;
  public barChartPlugins_H = [];
   
  public barChartData_CHECK: ChartDataSets[] = [
    //{ data: [65, 59, 80, 81, 56, 55, 40], label: 'Female A' },
    { data: [10,5, 7], label: '  عدد الشيكات المطلوب تحصيلها' }
  ];
  public barChartData_H: ChartDataSets[] = [
    { data: [5, 7, 8, 0, 2, 3], label: 'بيت الاصيل' },
    { data: [1, 7, 9, 3, 6, 4], label: '.صالح البورسعيدى' },
    { data: [0, 2, 7, 4, 2, 5], label: 'حمد صالح' },
  ];

  public barChartLabels_P: Label[] = ['ديسمبر', 'يناير', 'فبراير'];

  public barChartData_P: ChartDataSets[] = [
    { data: [1, 3, 4 ], label: 'بيت الاصيل' },
    { data: [1,0, 5 ], label: '.صالح البورسعيدى' },
    { data: [0, 2, 7 ], label: 'حمد صالح' },
  ];
  constructor() {

    monkeyPatchChartJsTooltip();
    monkeyPatchChartJsLegend();

  }

  ngOnInit(): void {
  }
  
   
}
