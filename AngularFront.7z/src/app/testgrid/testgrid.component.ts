import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-testgrid',
  templateUrl: './testgrid.component.html',
  styleUrls: ['./testgrid.component.css']
})
export class TestgridComponent implements OnInit {
  ColumnDefs: any;
  RowData: any;
  AgLoad: boolean | undefined;
  constructor() { }

  ngOnInit() {
    //this.GetAgColumns();
    //this.GetGiftVoucherList();
  }
  //GetAgColumns() {
  //  this.ColumnDefs = [
  //    { headerName: 'InvoiceNO', field: 'ArtNo', sortable: true, filter: true },
  //    { headerName: 'Serial', field: 'Provider', sortable: true, filter: true },
  //    { headerName: 'CustomerName', field: 'CustomerName', sortable: true, filter: true },
  //    { headerName: 'Date', field: 'Brand', sortable: true, filter: true },
  //    { headerName: 'Price', field: 'Price', sortable: true, filter: true },
  //    { headerName: 'BuyAccount', field: 'BuyAccount', sortable: true, filter: true }
  //  ];

  //}
  //GetGiftVoucherList() {
  //  this.AgLoad = true;
  //  this.RowData = [
  //    {
  //      ArtNo: "100",
  //      Provider: "11",
  //      CustomerName: "1Yu",
  //      Brand: "Apple",
  //      Price: 7810.23,
  //      BuyAccount: "123",
  //    },
  //    {
  //      ArtNo: "101",
  //      Provider: "Samsung galaxy",
  //      CustomerName: "1Yu",
  //      Brand: "Samsung",
  //      Price: 2310.23,
  //      BuyAccount: "123",
  //    },
  //    {
  //      ArtNo: "102",
  //      Provider: "Iphone 11 Pro",
  //      CustomerName: "1Yu",
  //      Brand: "Apple",
  //      Price: 7810.23,
  //      BuyAccount: "123",
  //    },
  //    {
  //      ArtNo: "103",
  //      Provider: "Intex",
  //      CustomerName: "1Yu",
  //      Brand: "Intex",
  //      Price: 5810.23,
  //      BuyAccount: "123",
  //    },
  //    {
  //      ArtNo: "100",
  //      Provider: "IPhone 11",
  //      CustomerName: "1Yu",
  //      Brand: "Apple",
  //      Price: 7810.23,
  //      BuyAccount: "123",
  //    },
  //    {
  //      ArtNo: "101",
  //      Provider: "Samsung galaxy",
  //      CustomerName: "1Yu",
  //      Brand: "Samsung",
  //      Price: 2310.23,
  //      BuyAccount: "123",
  //    },
  //    {
  //      ArtNo: "102",
  //      Provider: "Iphone 11 Pro",
  //      CustomerName: "1Yu",
  //      Brand: "Apple",
  //      Price: 7810.23,
  //      BuyAccount: "123",
  //    },
  //    {
  //      ArtNo: "103",
  //      Provider: "Intex",
  //      CustomerName: "1Yu",
  //      Brand: "Intex",
  //      Price: 5810.23,
  //      BuyAccount: "123",
  //    }
  //  ];
  //}

}
