 
import { NgModule, NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
//import { AgGridComponent } from './ag-grid/ag-grid.component'; 
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { NgSelectModule } from '@ng-select/ng-select';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TabsModule } from 'ngx-tabset';

// Datepicker module 
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';

import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';

import { AgGridModule } from 'ag-grid-angular';
import { AgGridComponent } from './ag-grid/ag-grid.component';
import { TestgridComponent } from './testgrid/testgrid.component'; 
import { AppRoutingModule, routingComponent } from './app-routing.module';
import { ButtonRendererComponent } from './renderer/button-renderer.component';
import { GenderRendererComponent } from './gender-renderer.component'; 
import { BtnCellRenderer} from './button-cell-renderer.component';
import { ButtonEditRendererComponent } from './renderer/buttonEdit-renderer.component';
import { ButtonDeleteRendererComponent } from './renderer/buttonDelete-renderer.component';
 
import { GridtransgComponent } from './gridtransg/gridtransg.component'; 
  
  
import { MenuheaderComponent } from './menuheader/menuheader.component';
 
import { AngularEditorModule } from '@kolkov/angular-editor';
  
import { TesteditorComponent } from './testeditor/testeditor.component'; 
 
import { LoginComponent } from './login/login.component';
import { UserComponent } from './security/user/user.component';
import { OccuAssessmentComponent } from './Occupational/occu-assessment/occu-assessment.component';
  
import { RebuildingComponent } from './Pages/rebuilding/rebuilding.component';
import { ReOwnerComponent } from './Pages/re-owner/re-owner.component';
import { ReTenantComponent } from './Pages/re-tenant/re-tenant.component';
import { RebuildingAttachComponent } from './Pages/rebuilding-attach/rebuilding-attach.component';
import { ReContractAttachComponent } from './Pages/re-contract-attach/re-contract-attach.component';
import { RentDatePaymentComponent } from './Pages/rent-date-payment/rent-date-payment.component';
import { RePaymentComponent } from './Pages/re-payment/re-payment.component';
import { DelayPaymentComponent } from './Pages/delay-payment/delay-payment.component';
import { ChartsModule } from 'ng2-charts';
import { DashhomeComponent } from './dashhome/dashhome.component';
import { ReBuildingFlatComponent } from './Pages/re-building-flat/re-building-flat.component';
import { ReContractReNewComponent } from './Pages/re-contract-re-new/re-contract-re-new.component';
import { CancelContractComponent } from './Pages/cancel-contract/cancel-contract.component';
//import { CKEditorModule } from '@ckeditor/ckeditor5-angular';./
 

@NgModule({
  declarations: [
    AppComponent,
    AgGridComponent,
    TestgridComponent, 
    routingComponent, ButtonRendererComponent, ButtonEditRendererComponent, ButtonDeleteRendererComponent,
    GenderRendererComponent, BtnCellRenderer,  GridtransgComponent 
    ,   MenuheaderComponent//,   
, TesteditorComponent,  LoginComponent, UserComponent, OccuAssessmentComponent,   RebuildingComponent, ReOwnerComponent, ReTenantComponent, RebuildingAttachComponent, ReContractAttachComponent, RentDatePaymentComponent, RePaymentComponent, DelayPaymentComponent, DashhomeComponent, ReBuildingFlatComponent, ReContractReNewComponent, CancelContractComponent
    // ,bootstrap: [AppComponent] EduPlanLongTargetComponent, EduPlanStudyComponent,
   // AgGridComponent
  ],
  imports: [
    BrowserModule, NgSelectModule, ChartsModule,
    BrowserAnimationsModule, FormsModule,
    BsDatepickerModule.forRoot(), NgMultiSelectDropDownModule.forRoot(),
    AgGridModule.withComponents([]),
    TabsModule.forRoot(),
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: httpTranslateLoader,
        deps: [HttpClient]
      }
    }),
    NgbModule,
    AppRoutingModule, HttpClientModule, ReactiveFormsModule, BrowserAnimationsModule, AngularEditorModule

  ],
  exports: [AgGridComponent,routingComponent],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA,
    NO_ERRORS_SCHEMA
  ],
  providers: [HttpClient],
  bootstrap: [AppComponent]
})
export class AppModule {
  constructor(private httpclient: HttpClient) { }
}
export function httpTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http);
}
