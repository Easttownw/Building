import { DATE } from "ngx-bootstrap/chronos/units/constants";

export class NotifcationModel {
      NotifcationId: number = 0;
 NotificationType: string = '';
  Date: Date = new Date();
 FromUserID: string = '';
 fromDepID: string = '';
  ToUserID: number = 0;
  ToDep: number = 0;
 Title: string = '';
 Details: string = '';
 IS_read: boolean = false;
  Session: string = '';
 IS_Deleted : boolean = false;


}
