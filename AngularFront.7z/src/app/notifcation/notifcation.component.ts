import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms'
import { ApiService_Notifcation } from '../shared/Notifcation.api.service'
import { Router } from '@angular/router'
import { NotifcationModel } from './Notifcation.model';
import { HttpClient } from '@angular/common/http'
import { ButtonEditRendererComponent } from '../renderer/buttonEdit-renderer.component';
import { ButtonDeleteRendererComponent } from '../renderer/buttonDelete-renderer.component';
import { TranslateService } from '@ngx-translate/core';
import { GlobalConstants } from '../common/global-constants';

import {
  GridOptions,
  ColDef,
  GridReadyEvent,
  ColumnApi,
  GridApi
} from "ag-grid-community";
import { Employee } from './employee';
@Component({
  selector: 'app-notifcation',
  templateUrl: './notifcation.component.html',
  styleUrls: ['./notifcation.component.css']
})
export class NotifcationComponent implements OnInit {
  
  // model 
  NotifcationModelobj:
    NotifcationModel = new NotifcationModel();
  EmployeeModelobj:
    Employee|any  ;
  formvalue!: FormGroup;
  NotifcationdataRow: any;

  // button
  Show_BtnInsert!: boolean;
  show_btn_Edit!: boolean;
  // for grid ag
  gridOptions: GridOptions;
  ColumnDefs: any;
  RowData: any;
  gridApi: any
  gridColumnApi: any
  constructor(public translate: TranslateService, private formbuilder: FormBuilder, private router: Router, private apiServ: ApiService_Notifcation) {
    translate.addLangs(['en', 'ar']);
    translate.setDefaultLang(this.translate.instant(GlobalConstants.setDefaultLang));
    this.gridOptions = {
      columnDefs: this.GetAgColumns(),
      rowData: []
    };

  }

  ngOnInit(): void {

    this.switch_btn(true);
    this.formvalue = this.formbuilder.group({
      NotificationType: [''], Date: [''], FromUserID: [''], fromDepID: [''], ToUserID: [''], ToDep: [''], Title: [''], Details: [''], IS_read: [''], IS_Deleted: [''], Session: ['']
    })
    //this.formvalue  = new FormGroup({
    //  name: new FormControl('', [Validators.required, Validators.minLength(3)]),
    //  email: new FormControl('', [Validators.required, Validators.email]),
    //  body: new FormControl('', Validators.required)
    //});
    // for validation
    this.formvalue = new FormGroup({
      NotificationType: new FormControl(''), Date: new FormControl(''), FromUserID: new FormControl(''), fromDepID: new FormControl(''), ToUserID: new FormControl(''), ToDep: new FormControl(''), Title: new FormControl(''), Details: new FormControl(''), IS_read: new FormControl(''), IS_Deleted: new FormControl(''), Session: new FormControl(''),
    });

    //fill ag grid

    this.getallNotifcation();
  }
  get f() {
    return this.formvalue.controls;
  }
  postNotifcation() {
    this.NotifcationModelobj.NotificationType = this.formvalue.value.NotificationType;
    this.NotifcationModelobj.Date = this.formvalue.value.Date;
    this.NotifcationModelobj.FromUserID = this.formvalue.value.FromUserID;
    this.NotifcationModelobj.fromDepID = this.formvalue.value.fromDepID;
    this.NotifcationModelobj.ToUserID = this.formvalue.value.ToUserID;
    this.NotifcationModelobj.ToDep = this.formvalue.value.ToDep;
    this.NotifcationModelobj.Title = this.formvalue.value.Title;
    this.NotifcationModelobj.Details = this.formvalue.value.Details;
    this.NotifcationModelobj.IS_read = this.formvalue.value.IS_read;
    this.NotifcationModelobj.IS_Deleted = this.formvalue.value.IS_Deleted;
    this.NotifcationModelobj.Session = String(localStorage.getItem('langID'));
 
    this.apiServ.postNotifcation(this.NotifcationModelobj)
    //  .subscribe(e => {

    //  alert(this.translate.instant('SuccessMessage'))

    //  //this.gridApi.applyTransaction({ add: [e[0]] });

    //  this.formvalue.reset();

    //}, er => { alert(this.translate.instant('WrongMessage')); });
  }


  getallNotifcation() {
    this.apiServ.getNotifcationToDep().subscribe(

      NotifcationdataRow => {
        this.gridOptions.rowData = NotifcationdataRow;
      })
  }


  //switch between button add and edit
  switch_btn(Is_add: boolean) {
    if (Is_add) {
      this.Show_BtnInsert = true;
      this.show_btn_Edit = false;
    }
    else {

      this.Show_BtnInsert = false;
      this.show_btn_Edit = true;
    }

  }
  click_btnInsert() {
    // open pop modal
    ($('#exampleModal') as any).modal('show');
    this.formvalue.reset();
  }
  closeModule() {

    ($('#exampleModal') as any).modal('hide');
  }
  OnEdit(row: any) {

    this.NotifcationModelobj.NotifcationId = row.NotifcationId;
    this.formvalue.controls['NotificationType'].setValue(row.NotificationType);
    this.formvalue.controls['Date'].setValue(row.Date);
    this.formvalue.controls['FromUserID'].setValue(row.FromUserID);
    this.formvalue.controls['fromDepID'].setValue(row.fromDepID);
    this.formvalue.controls['ToUserID'].setValue(row.ToUserID);
    this.formvalue.controls['ToDep'].setValue(row.ToDep);
    this.formvalue.controls['Title'].setValue(row.Title);
    this.formvalue.controls['Details'].setValue(row.Details);
    this.formvalue.controls['IS_read'].setValue(row.IS_read);
    this.formvalue.controls['IS_Deleted'].setValue(row.IS_Deleted);
    this.formvalue.controls['Session'].setValue(row.Session);


    // open pop modal
    ($('#exampleModal') as any).modal('show');
    // swtch buttons
    this.switch_btn(false);

  }
  updateNotifcation() {
    this.NotifcationModelobj.NotificationType = this.formvalue.value.NotificationType;
    this.NotifcationModelobj.Date = this.formvalue.value.Date;
    this.NotifcationModelobj.FromUserID = this.formvalue.value.FromUserID;
    this.NotifcationModelobj.fromDepID = this.formvalue.value.fromDepID;
    this.NotifcationModelobj.ToUserID = this.formvalue.value.ToUserID;
    this.NotifcationModelobj.ToDep = this.formvalue.value.ToDep;
    this.NotifcationModelobj.Title = this.formvalue.value.Title;
    this.NotifcationModelobj.Details = this.formvalue.value.Details;
    this.NotifcationModelobj.IS_read = this.formvalue.value.IS_read;
    this.NotifcationModelobj.IS_Deleted = this.formvalue.value.IS_Deleted;
    this.NotifcationModelobj.Session = this.formvalue.value.Session;
    this.apiServ.updateNotifcation(this.NotifcationModelobj, this.NotifcationModelobj.NotifcationId).subscribe(res => {
      alert(this.translate.instant('UpdateMessage'));

      this.formvalue.reset();
    });
  }

  // for ag grid

  onGridReady(params: GridReadyEvent) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  }
  // create column of Ag grid
  private GetAgColumns(): ColDef[] {

    return [
      {
        headerName: this.translate.instant('btnlblEdit'),
        cellRendererFramework: ButtonEditRendererComponent,
        cellRendererParams: {
          onClick: this.onBtnEdit_Click.bind(this),
          pk_Name: 'NotifcationId', title:'تفاصيل'
        }
      },
      //{
      //  headerName: this.translate.instant('btnlblDelete'),
      //  cellRendererFramework: ButtonDeleteRendererComponent,
      //  cellRendererParams: {
      //    onClick: this.onBtnDelet_Click.bind(this),
      //    pk_Name: 'NotifcationId'
      //  }
      //},
      { headerName: 'من قسم', field: 'fromdepName' },
      { headerName: 'العنوان ', field: 'Title' }, { headerName: ' المحتوى', field: 'Details' }

    ];


  }
  // event for button in Ag Grid

  onBtnEdit_Click(e: { rowData: {}; }) {

    this.OnEdit(e.rowData);
  }
  onBtnDelet_Click(e: {
    event: Event,
    rowData: any, pk_value: number
  }) {
    // alert(JSON.stringify(e.rowData));
    // delete from dataBase 
    if (confirm(this.translate.instant('DeleteConfirm'))) {
      this.apiServ.deleteNotifcation(e.pk_value).subscribe((res: any) => {
        alert(this.translate.instant('DeleteMessage'));
        let deletedRow = e.rowData;
        this.gridApi.updateRowData({ remove: [deletedRow] });
      });

    }
  }
}

