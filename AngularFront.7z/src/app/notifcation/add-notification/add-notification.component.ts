import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-notification',
  templateUrl: './add-notification.component.html',
  styleUrls: ['./add-notification.component.css']
})
export class AddNotificationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
