"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserModel = void 0;
var UserModel = /** @class */ (function () {
    function UserModel() {
        this.UserID = 0;
        this.EmployeeID = 0;
        this.Name = '';
        this.AccessType = '';
        this.Email = '';
        this.Password = '';
        this.IS_Active = true;
        this.Notes = '';
    }
    return UserModel;
}());
exports.UserModel = UserModel;
//# sourceMappingURL=User.model.js.map