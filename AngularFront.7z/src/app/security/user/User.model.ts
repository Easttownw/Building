export class UserModel {
      UserID: number = 0; 
  EmployeeID: number | null | undefined;
 Name: string = '';
 AccessType: string = '';
 Email: string = '';
 Password: string = '';
 IS_Active: boolean = true;
 Notes: string = '';


}
