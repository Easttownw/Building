import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms'
import { ApiService_User } from '../../shared/User.api.service'
import { Router } from '@angular/router'
import { UserModel } from './User.model';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { ButtonEditRendererComponent } from '../../renderer/buttonEdit-renderer.component';
import { ButtonDeleteRendererComponent } from '../../renderer/buttonDelete-renderer.component';
import { TranslateService } from '@ngx-translate/core'; 

import {
  GridOptions,
  ColDef,
  GridReadyEvent,
  ColumnApi,
  GridApi
} from "ag-grid-community";

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  // model 
  UserModelobj:
    UserModel = new UserModel();
  formvalue!: FormGroup;
  UserdataRow: any;

  // button
  Show_BtnInsert!: boolean;
  show_btn_Edit!: boolean;
  // for grid ag
  gridOptions: GridOptions;
  ColumnDefs: any;
  RowData: any;
  gridApi: any
  gridColumnApi: any
  constructor(  public translate: TranslateService,
    private formbuilder: FormBuilder, private router: Router, private apiServ: ApiService_User ) {
    translate.addLangs(['en', 'ar']);
    translate.setDefaultLang('en');
    this.gridOptions = {
      columnDefs: this.GetAgColumns(),
      rowData: []
    };

  }

  ngOnInit(): void {

    this.switch_btn(true);
    this.formvalue = this.formbuilder.group({
       EmployeeID: [''], Name: [''], AccessType: [''], Email: [''], Password: [''], IS_Active: [''], Notes: ['']
    })
    //this.formvalue  = new FormGroup({
    //  name: new FormControl('', [Validators.required, Validators.minLength(3)]),
    //  email: new FormControl('', [Validators.required, Validators.email]),
    //  body: new FormControl('', Validators.required)
    //});
    // for validation
    this.formvalue = new FormGroup({
      UserID: new FormControl(''), EmployeeID: new FormControl(''), Name: new FormControl(''), AccessType: new FormControl(''), Email: new FormControl(''), Password: new FormControl(''), IS_Active: new FormControl(''), Notes: new FormControl(''),
    });

    //fill ag grid

    this.getallUser();
  }
  get f() {
    return this.formvalue.controls;
  }
  postUser() { 
    //this.UserModelobj.EmployeeID =  this.formvalue.value.EmployeeID;
    this.UserModelobj.Name = this.formvalue.value.Name;
    this.UserModelobj.AccessType = this.formvalue.value.AccessType;
    this.UserModelobj.Email = this.formvalue.value.Email;
    this.UserModelobj.Password = this.formvalue.value.Password;
    this.UserModelobj.IS_Active = this.formvalue.value.IS_Active;
    this.UserModelobj.Notes = this.formvalue.value.Notes;
    this.apiServ.postUser(this.UserModelobj).subscribe(e => {

      alert(this.translate.instant('SuccessMessage'))

      this.gridApi.applyTransaction({ add: [this.UserModelobj] });
      let ref = document.getElementById('btn_cancel')
      ref?.click();
      this.formvalue.reset();

    }, er => { alert(this.translate.instant('WrongMessage')); });
  }


  getallUser() {
    this.apiServ.getUser().subscribe(

      UserdataRow => {
        this.gridOptions.rowData = UserdataRow;
      })
  }


  //switch between button add and edit
  switch_btn(Is_add: boolean) {
    if (Is_add) {
      this.Show_BtnInsert = true;
      this.show_btn_Edit = false;
    }
    else {

      this.Show_BtnInsert = false;
      this.show_btn_Edit = true;
    }

  }
  click_btnInsert() {
    this.switch_btn(true);
    // open pop modal
    ($('#exampleModal') as any).modal('show');
    this.formvalue.reset();
  }
  OnEdit(row: any) {

    this.UserModelobj.UserID = row.UserID;
    this.formvalue.controls['UserID'].setValue(row.UserID);
    this.formvalue.controls['EmployeeID'].setValue(row.EmployeeID);
    this.formvalue.controls['Name'].setValue(row.Name);
    this.formvalue.controls['AccessType'].setValue(row.AccessType);
    this.formvalue.controls['Email'].setValue(row.Email);
    this.formvalue.controls['Password'].setValue(row.Password);
    this.formvalue.controls['IS_Active'].setValue(row.IS_Active);
    this.formvalue.controls['Notes'].setValue(row.Notes);


    // open pop modal
    ($('#exampleModal') as any).modal('show');
    // swtch buttons
    this.switch_btn(false);

  }
  updateUser() {
    this.UserModelobj.UserID = this.formvalue.value.UserID;
    this.UserModelobj.EmployeeID = this.formvalue.value.EmployeeID;
    this.UserModelobj.Name = this.formvalue.value.Name;
    this.UserModelobj.AccessType = this.formvalue.value.AccessType;
    this.UserModelobj.Email = this.formvalue.value.Email;
    this.UserModelobj.Password = this.formvalue.value.Password;
    this.UserModelobj.IS_Active = this.formvalue.value.IS_Active;
    this.UserModelobj.Notes = this.formvalue.value.Notes;
    this.apiServ.updateUser(this.UserModelobj, this.UserModelobj.UserID).subscribe(res => {
      alert(this.translate.instant('UpdateMessage'));
      let ref = document.getElementById('btn_cancel')
      ref?.click();
      this.formvalue.reset();
    });
  }

  // for ag grid

  onGridReady(params: GridReadyEvent) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  }
  // create column of Ag grid
  private GetAgColumns(): ColDef[] {

    return [
      {
      headerName: this.translate.instant('btnlblDelete'),
      cellRendererFramework: ButtonDeleteRendererComponent,
      cellRendererParams: {
        onClick: this.onBtnDelet_Click.bind(this),
        pk_Name: 'UserID'
      }
    },
      {
        headerName: this.translate.instant('btnlblEdit'),
        cellRendererFramework: ButtonEditRendererComponent,
        cellRendererParams: {
          onClick: this.onBtnEdit_Click.bind(this),
          pk_Name: 'UserID'
        }
      },

      { headerName: 'الاسم', field: 'Name', sortable: true, filter: true },

      { headerName: 'الايميل', field: 'Email', sortable: true, filter: true },
     

    ];


  }
  // event for button in Ag Grid

  onBtnEdit_Click(e: { rowData: {}; }) {

    this.OnEdit(e.rowData);
  }
  onBtnDelet_Click(e: {
    event: Event,
    rowData: any, pk_value: number
  }) {
    // alert(JSON.stringify(e.rowData));
    // delete from dataBase 
    if (confirm(this.translate.instant('DeleteConfirm'))) {
      this.apiServ.deleteUser(e.pk_value).subscribe((res: any) => {
        alert(this.translate.instant('DeleteMessage'));
        let deletedRow = e.rowData;
        this.gridApi.updateRowData({ remove: [deletedRow] });
      });

    }
  }
}

