export class GlobalConstants {
   //public static apiURL: string = "https://localhost:7008/"
 public static apiURL: string = "http://buidlingback.buschcranes.com/";
 // public static apiURL: string = "http://pioneer.easttowns.net/";
  
  public static siteTitle: string = "This is example of ItSolutionStuff.com";
  public static setDefaultLang: string = "en";
  public static convertdate(date: string) {

    if (date.length >= 8) {
      var splitted = date.split("/", 3);
      alert(splitted[1] + "/" + splitted[0])
      return splitted[1] + "/" + splitted[0] + "/" + splitted[2];
    }
    else { return date };
  }
}

